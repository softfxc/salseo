import { Capacitor } from "@capacitor/core";
import { FirebaseAuthentication } from "@capacitor-firebase/authentication";
import { getApp, getApps, initializeApp, type FirebaseApp } from "firebase/app";
import {
  createUserWithEmailAndPassword,
  deleteUser,
  EmailAuthProvider,
  getAuth,
  GoogleAuthProvider,
  reauthenticateWithCredential,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithCredential,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  type Auth,
} from "firebase/auth";
import type {
  ChatMessage,
  CommunityPost,
  Language,
  SalseoNotification,
  UserProfile,
} from "./types";

export type FirebaseConfig = {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket?: string;
  messagingSenderId?: string;
  appId: string;
};

type FirebaseBundle = {
  app: FirebaseApp;
  auth: Auth;
  config: FirebaseConfig;
};

type FirestoreRestDocument = {
  name?: string;
  fields?: Record<string, FirestoreRestValue>;
  createTime?: string;
  updateTime?: string;
};

type FirestoreRestValue = {
  nullValue?: null;
  booleanValue?: boolean;
  integerValue?: string;
  doubleValue?: number;
  stringValue?: string;
  timestampValue?: string;
  arrayValue?: { values?: FirestoreRestValue[] };
  mapValue?: { fields?: Record<string, FirestoreRestValue> };
};

type FirestoreQueryResponseItem = {
  document?: FirestoreRestDocument;
};

const CONFIG_URL = "/firebase-config.json";
let bundlePromise: Promise<FirebaseBundle> | null = null;

declare global {
  interface Window {
    SALSEO_FIREBASE_CONFIG?: FirebaseConfig;
  }
}

export async function firebaseReady() {
  try {
    await getFirebase();
    return true;
  } catch {
    return false;
  }
}

export async function registerFirebaseAccount(input: {
  username: string;
  email: string;
  password: string;
  preferredLanguage: Language;
}): Promise<UserProfile> {
  const firebase = await getFirebase();
  firebase.auth.languageCode = input.preferredLanguage;
  const username = normalizeUsername(input.username);
  const email = normalizeEmail(input.email);

  const credentials = await createUserWithEmailAndPassword(
    firebase.auth,
    email,
    input.password,
  );
  const user = credentials.user;
  const profile = {
    ...profileFromUsername(username, input.preferredLanguage),
    uid: user.uid,
  };

  try {
    await reserveUsername(firebase, username, user.uid);

    await updateProfile(user, {
      displayName: profile.alias || profile.username,
    });

    await setRestDocument(firebase, "users", user.uid, {
      ...profile,
      uid: user.uid,
      updatedAtMs: Date.now(),
    });

    await sendEmailVerification(user);
  } catch (error) {
    const reservation = await getRestDocument(firebase, "usernames", username).catch(() => null);
    if (String(reservation?.data.uid || "") === user.uid) {
      await deleteRestDocument(firebase, "usernames", username).catch(() => undefined);
    }
    await deleteUser(user).catch(() => undefined);
    throw error;
  }

  return profile;
}

export async function signInFirebaseAccount(input: {
  email: string;
  password: string;
}): Promise<string> {
  const firebase = await getFirebase();
  const email = normalizeEmail(input.email);
  const credentials = await signInWithEmailAndPassword(
    firebase.auth,
    email,
    input.password,
  );
  return credentials.user.uid;
}

export async function signInGoogleAccount(): Promise<string> {
  const firebase = await getFirebase();

  if (Capacitor.isNativePlatform()) {
    const nativeResult = await FirebaseAuthentication.signInWithGoogle();
    const idToken = nativeResult.credential?.idToken;
    const accessToken = nativeResult.credential?.accessToken;

    if (!idToken && !accessToken) {
      throw new Error("No se pudo completar el acceso con Google.");
    }

    const credential = GoogleAuthProvider.credential(idToken, accessToken);
    const result = await signInWithCredential(firebase.auth, credential);
    return result.user.uid;
  }

  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: "select_account" });
  const result = await signInWithPopup(firebase.auth, provider);
  return result.user.uid;
}

export async function readCurrentProfile(uid: string): Promise<UserProfile> {
  const firebase = await getFirebase();
  const document = await getRestDocument(firebase, "users", uid);
  if (document) return userProfileFromData({ ...document.data, uid });

  return createProfileForExistingFirebaseUser(firebase, uid);
}

export async function saveCloudProfile(profile: UserProfile) {
  const firebase = await getFirebase();
  const uid = firebase.auth.currentUser?.uid;
  if (!uid) throw new Error("Inicia sesión para guardar el perfil.");
  const nextUsername = normalizeUsername(profile.username);
  const previousProfile = await getRestDocument(firebase, "users", uid).catch(() => null);
  const previousUsername = normalizeUsername(String(previousProfile?.data.username || ""));

  if (nextUsername && nextUsername !== previousUsername) {
    await reserveUsername(firebase, nextUsername, uid);
    if (previousUsername) await deleteRestDocument(firebase, "usernames", previousUsername).catch(() => undefined);
  }

  await setRestDocument(firebase, "users", uid, {
    ...profile,
    username: nextUsername || previousUsername || profile.username,
    uid,
    updatedAtMs: Date.now(),
  });
}

export async function publishChatMessage(message: ChatMessage) {
  const firebase = await getFirebase();
  const uid = firebase.auth.currentUser?.uid;
  if (!uid) throw new Error("Inicia sesión para chatear.");
  await setRestDocument(firebase, "publicChat", message.id, {
    id: message.id,
    author: message.author,
    authorUid: uid,
    body: message.body,
    mediaUrl: message.mediaUrl || "",
    createdAt: message.createdAt,
    createdAtMs: Date.now(),
  });
}

export async function publishDirectChatMessage(
  message: ChatMessage,
  recipientProfile: UserProfile,
) {
  const firebase = await getFirebase();
  const uid = firebase.auth.currentUser?.uid;
  if (!uid) throw new Error("Inicia sesión para enviar mensajes.");
  const recipientUid = recipientProfile.uid;
  const recipientUsername = normalizeUsername(recipientProfile.username);
  if (!recipientUid || !recipientUsername) {
    throw new Error("No se pudo identificar el perfil de destino.");
  }
  const authorUsername = normalizeUsername(message.author);
  await setRestDocument(firebase, "directChat", message.id, {
    id: message.id,
    author: authorUsername,
    authorUid: uid,
    recipientUsername,
    recipientUid,
    conversationKey: directConversationKey(uid, recipientUid),
    direct: true,
    body: message.body,
    mediaUrl: message.mediaUrl || "",
    createdAt: message.createdAt,
    createdAtMs: Date.now(),
  });
}

export async function publishCommunityPost(post: CommunityPost) {
  const firebase = await getFirebase();
  const uid = firebase.auth.currentUser?.uid;
  if (!uid) throw new Error("Inicia sesión para publicar.");
  await setRestDocument(firebase, "posts", post.id, {
    ...post,
    authorUid: uid,
    createdAtMs: Date.now(),
  });
}

export function subscribeToCloudChat(
  onChange: (items: ChatMessage[]) => void,
  onNewRemoteMessage?: (message: ChatMessage) => void,
) {
  let previousIds = new Set<string>();
  let firstSnapshot = true;
  let closed = false;
  let timer: number | undefined;

  const load = async () => {
    try {
      const firebase = await getFirebase();
      if (closed) return;
      const currentUid = firebase.auth.currentUser?.uid || "";
      const documents = await runCollectionQuery(firebase, "publicChat", {
        orderBy: [{ field: { fieldPath: "createdAtMs" }, direction: "ASCENDING" }],
        limit: 200,
      });
      const messages = documents.map((document) =>
        chatMessageFromData(document.id, document.data, currentUid),
      );
      onChange(messages);
      if (!firstSnapshot && onNewRemoteMessage) {
        messages.forEach((message) => {
          if (!previousIds.has(message.id) && !message.mine)
            onNewRemoteMessage(message);
        });
      }
      previousIds = new Set(messages.map((message) => message.id));
      firstSnapshot = false;
    } catch (error) {
      console.warn("Salseo chat no disponible", error);
    }
  };

  void load();
  timer = window.setInterval(load, 4500);

  return () => {
    closed = true;
    if (timer) window.clearInterval(timer);
  };
}

export function subscribeToDirectChat(
  onChange: (items: ChatMessage[]) => void,
  onNewRemoteMessage?: (message: ChatMessage) => void,
) {
  let previousIds = new Set<string>();
  let firstSnapshot = true;
  let closed = false;
  let timer: number | undefined;

  const load = async () => {
    try {
      const firebase = await getFirebase();
      if (closed) return;
      const currentUid = firebase.auth.currentUser?.uid;
      if (!currentUid) return;
      const [sent, received] = await Promise.all([
        runCollectionQuery(firebase, "directChat", {
          where: fieldFilter("authorUid", "EQUAL", stringValue(currentUid)),
          limit: 120,
        }),
        runCollectionQuery(firebase, "directChat", {
          where: fieldFilter("recipientUid", "EQUAL", stringValue(currentUid)),
          limit: 120,
        }),
      ]);
      const byId = new Map([...sent, ...received].map((document) => [document.id, document]));
      const messages = [...byId.values()]
        .map((document) => chatMessageFromData(document.id, document.data, currentUid))
        .sort((a, b) => Number(a.createdAtMs || 0) - Number(b.createdAtMs || 0));
      onChange(messages);
      if (!firstSnapshot && onNewRemoteMessage) {
        messages.forEach((message) => {
          if (!previousIds.has(message.id) && !message.mine) onNewRemoteMessage(message);
        });
      }
      previousIds = new Set(messages.map((message) => message.id));
      firstSnapshot = false;
    } catch (error) {
      console.warn("Salseo mensajes directos no disponible", error);
    }
  };

  void load();
  timer = window.setInterval(load, 4500);

  return () => {
    closed = true;
    if (timer) window.clearInterval(timer);
  };
}

export function subscribeToCloudPosts(
  onChange: (items: CommunityPost[]) => void,
) {
  let closed = false;
  let timer: number | undefined;

  const load = async () => {
    try {
      const firebase = await getFirebase();
      if (closed) return;
      const documents = await runCollectionQuery(firebase, "posts", {
        orderBy: [{ field: { fieldPath: "createdAtMs" }, direction: "DESCENDING" }],
        limit: 100,
      });
      onChange(
        documents.map((document) =>
          communityPostFromData(document.id, document.data),
        ),
      );
    } catch (error) {
      console.warn("Salseo posts no disponible", error);
    }
  };

  void load();
  timer = window.setInterval(load, 6000);

  return () => {
    closed = true;
    if (timer) window.clearInterval(timer);
  };
}

export async function readUserProfileByUsername(
  username: string,
): Promise<UserProfile | null> {
  const firebase = await getFirebase();
  const clean = normalizeUsername(username);
  if (!clean) return null;
  const documents = await runCollectionQuery(firebase, "users", {
    where: fieldFilter("username", "EQUAL", stringValue(clean)),
    limit: 1,
  });
  const first = documents[0];
  if (!first) return null;
  return userProfileFromData({ ...first.data, uid: first.id });
}

export async function searchUserProfilesByPrefix(
  value: string,
): Promise<UserProfile[]> {
  const firebase = await getFirebase();
  const clean = normalizeUsername(value.replace(/^@+/, ""));
  if (!clean) return [];
  const documents = await runCollectionQuery(firebase, "users", {
    where: {
      compositeFilter: {
        op: "AND",
        filters: [
          fieldFilter("username", "GREATER_THAN_OR_EQUAL", stringValue(clean)),
          fieldFilter("username", "LESS_THAN_OR_EQUAL", stringValue(`${clean}\uf8ff`)),
        ],
      },
    },
    orderBy: [{ field: { fieldPath: "username" }, direction: "ASCENDING" }],
    limit: 20,
  });

  const profiles = documents.map((document) =>
    userProfileFromData({ ...document.data, uid: document.id }),
  );
  return [...new Map(profiles.map((item) => [item.username, item])).values()];
}

export async function readProfileSocialCounts(
  profile: Pick<UserProfile, "username" | "followingUsers">,
): Promise<{ followers: number; following: number }> {
  const firebase = await getFirebase();
  const username = normalizeUsername(profile.username);
  const following = uniqueUsernames(profile.followingUsers || []).length;
  if (!username) return { followers: 0, following };
  const followers = await runCollectionQuery(firebase, "users", {
    where: fieldFilter("followingUsers", "ARRAY_CONTAINS", stringValue(username)),
    limit: 500,
  });
  return { followers: followers.length, following };
}

export async function readProfileFriendList(
  profile: Pick<UserProfile, "username" | "followingUsers">,
  kind: "followers" | "following",
): Promise<UserProfile[]> {
  const firebase = await getFirebase();
  const username = normalizeUsername(profile.username);
  if (kind === "followers") {
    if (!username) return [];
    const documents = await runCollectionQuery(firebase, "users", {
      where: fieldFilter("followingUsers", "ARRAY_CONTAINS", stringValue(username)),
      limit: 500,
    });
    return documents
      .map((document) => userProfileFromData({ ...document.data, uid: document.id }))
      .sort((a, b) => a.username.localeCompare(b.username));
  }

  const usernames = uniqueUsernames(profile.followingUsers || []);
  const users = await Promise.all(
    usernames.map((item) => readUserProfileByUsername(item).catch(() => null)),
  );
  return users
    .filter((item): item is UserProfile => Boolean(item))
    .sort((a, b) => a.username.localeCompare(b.username));
}

export async function notifyUserByUsername(
  targetUsername: string,
  notification: Omit<
    SalseoNotification,
    "id" | "targetUid" | "targetUsername" | "createdAt" | "createdAtMs"
  >,
) {
  const target = await readUserProfileByUsername(targetUsername);
  if (!target?.uid) return;
  await createNotification(target.uid, target.username, notification);
}

export async function notifyFollowersOfProfile(
  actorProfile: UserProfile,
  notification: Omit<
    SalseoNotification,
    | "id"
    | "targetUid"
    | "targetUsername"
    | "createdAt"
    | "createdAtMs"
    | "actor"
    | "actorUsername"
  >,
  options: { mutualOnly?: boolean } = {},
) {
  const firebase = await getFirebase();
  const actorUsername = normalizeUsername(actorProfile.username);
  if (!actorUsername) return;

  const documents = await runCollectionQuery(firebase, "users", {
    where: fieldFilter("followingUsers", "ARRAY_CONTAINS", stringValue(actorUsername)),
    limit: 200,
  });
  const actorFollowing = new Set(
    (actorProfile.followingUsers || []).map(normalizeUsername).filter(Boolean),
  );

  const recipients = documents
    .map((document) => userProfileFromData({ ...document.data, uid: document.id }))
    .filter((target) => {
      const targetUsername = normalizeUsername(target.username);
      if (!target.uid || !targetUsername || targetUsername === actorUsername)
        return false;
      if (options.mutualOnly && !actorFollowing.has(targetUsername))
        return false;
      return true;
    });

  await Promise.all(
    recipients.map((target) =>
      createNotification(target.uid || "", target.username, {
        ...notification,
        actor: actorProfile.alias || actorProfile.username,
        actorUsername,
      }),
    ),
  );
}

export function subscribeToUserNotifications(
  onChange: (items: SalseoNotification[]) => void,
  onNewNotification?: (notification: SalseoNotification) => void,
) {
  let previousIds = new Set<string>();
  let firstSnapshot = true;
  let closed = false;
  let timer: number | undefined;

  const load = async () => {
    try {
      const firebase = await getFirebase();
      if (closed) return;
      const uid = firebase.auth.currentUser?.uid;
      if (!uid) return;
      const documents = await runCollectionQuery(firebase, "notifications", {
        where: fieldFilter("targetUid", "EQUAL", stringValue(uid)),
        limit: 60,
      });
      const items = documents
        .map((document) => salseoNotificationFromData(document.id, document.data))
        .sort((a, b) => b.createdAtMs - a.createdAtMs);
      onChange(items);
      if (!firstSnapshot && onNewNotification) {
        items.forEach((item) => {
          if (!previousIds.has(item.id)) onNewNotification(item);
        });
      }
      previousIds = new Set(items.map((item) => item.id));
      firstSnapshot = false;
    } catch (error) {
      console.warn("Salseo notifications no disponible", error);
    }
  };

  void load();
  timer = window.setInterval(load, 5000);

  return () => {
    closed = true;
    if (timer) window.clearInterval(timer);
  };
}

async function createNotification(
  targetUid: string,
  targetUsername: string,
  notification: Omit<
    SalseoNotification,
    "id" | "targetUid" | "targetUsername" | "createdAt" | "createdAtMs"
  >,
) {
  if (!targetUid) return;
  const firebase = await getFirebase();
  const actorUid = firebase.auth.currentUser?.uid || "";
  const createdAtMs = Date.now();
  await createRestDocument(firebase, "notifications", {
    targetUid,
    targetUsername: normalizeUsername(targetUsername),
    type: notification.type,
    title: notification.title,
    body: notification.body,
    actor: notification.actor,
    actorUsername: normalizeUsername(notification.actorUsername),
    actorUid,
    entityId: notification.entityId || "",
    createdAt: new Date(createdAtMs).toLocaleString("es-ES", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    }),
    createdAtMs,
  });
}

export async function sendPasswordResetLink(email: string) {
  const firebase = await getFirebase();
  firebase.auth.languageCode = currentAuthLanguageCode();
  await sendPasswordResetEmail(firebase.auth, normalizeEmail(email));
}

export async function deleteDirectChatMessage(messageId: string) {
  const firebase = await getFirebase();
  const uid = firebase.auth.currentUser?.uid;
  if (!uid) throw new Error("Inicia sesión para eliminar mensajes.");
  const cleanId = String(messageId || "").trim();
  if (!cleanId) throw new Error("Mensaje no válido.");

  const document = await getRestDocument(firebase, "directChat", cleanId);
  if (!document) return;
  if (String(document.data.authorUid || "") !== uid) {
    throw new Error("Solo puedes eliminar mensajes enviados por ti.");
  }

  await deleteRestDocument(firebase, "directChat", cleanId);
}

export async function deleteFirebaseAccount(password?: string) {
  const firebase = await getFirebase();
  const user = firebase.auth.currentUser;
  if (!user) throw new Error("No hay una sesión iniciada.");

  if (user.email && password) {
    const credential = EmailAuthProvider.credential(user.email, password);
    await reauthenticateWithCredential(user, credential);
  }

  const uid = user.uid;
  const profileDocument = await getRestDocument(firebase, "users", uid).catch(() => null);
  const username = normalizeUsername(String(profileDocument?.data.username || user.displayName || ""));

  await deleteOwnedFirestoreData(firebase, uid, username);
  if (username) await deleteRestDocument(firebase, "usernames", username).catch(() => undefined);
  await deleteRestDocument(firebase, "users", uid).catch(() => undefined);
  await deleteUser(user);
}

async function deleteOwnedFirestoreData(
  firebase: FirebaseBundle,
  uid: string,
  username: string,
) {
  const uniqueDocuments = (documents: Array<{ id: string; data: Record<string, unknown> }>) =>
    [...new Map(documents.map((document) => [document.id, document])).values()];

  const [targetNotifications, actorNotifications, publicMessages, directSent, directReceived, posts] =
    await Promise.all([
      runCollectionQuery(firebase, "notifications", {
        where: fieldFilter("targetUid", "EQUAL", stringValue(uid)),
        limit: 500,
      }),
      runCollectionQuery(firebase, "notifications", {
        where: fieldFilter("actorUid", "EQUAL", stringValue(uid)),
        limit: 500,
      }),
      runCollectionQuery(firebase, "publicChat", {
        where: fieldFilter("authorUid", "EQUAL", stringValue(uid)),
        limit: 500,
      }),
      runCollectionQuery(firebase, "directChat", {
        where: fieldFilter("authorUid", "EQUAL", stringValue(uid)),
        limit: 500,
      }),
      runCollectionQuery(firebase, "directChat", {
        where: fieldFilter("recipientUid", "EQUAL", stringValue(uid)),
        limit: 500,
      }),
      runCollectionQuery(firebase, "posts", {
        where: fieldFilter("authorUid", "EQUAL", stringValue(uid)),
        limit: 500,
      }),
    ]);

  const notificationIds = uniqueDocuments([...targetNotifications, ...actorNotifications]);
  const chatIds = uniqueDocuments([...publicMessages, ...directSent, ...directReceived]);

  await Promise.all([
    ...notificationIds.map((item) => deleteRestDocument(firebase, "notifications", item.id)),
    ...chatIds.map((item) =>
      deleteRestDocument(firebase, item.data.direct ? "directChat" : "publicChat", item.id),
    ),
    ...posts.map((item) => deleteRestDocument(firebase, "posts", item.id)),
  ]);

  if (username) {
    const followers = await runCollectionQuery(firebase, "users", {
      where: fieldFilter("followingUsers", "ARRAY_CONTAINS", stringValue(username)),
      limit: 500,
    });
    await Promise.all(
      followers
        .filter((item) => item.id !== uid)
        .map((item) => {
          const followingUsers = Array.isArray(item.data.followingUsers)
            ? item.data.followingUsers.map(String).filter((value) => normalizeUsername(value) !== username)
            : [];
          return setRestDocument(firebase, "users", item.id, {
            ...item.data,
            followingUsers,
            updatedAtMs: Date.now(),
          });
        }),
    );
  }
}

export async function signOutFirebase() {
  const firebase = await getFirebase();
  await FirebaseAuthentication.signOut().catch(() => undefined);
  await signOut(firebase.auth);
}

function currentAuthLanguageCode(): Language {
  const value = (typeof document !== "undefined" ? document.documentElement.lang : "") || "es";
  return value === "en" || value === "fr" ? value : "es";
}

async function createProfileForExistingFirebaseUser(
  firebase: FirebaseBundle,
  uid: string,
): Promise<UserProfile> {
  const currentUser = firebase.auth.currentUser;
  if (!currentUser || currentUser.uid !== uid) throw new Error("Perfil no encontrado.");

  const base = sanitizeUsername(
    currentUser.displayName || currentUser.email?.split("@")[0] || "usuario",
  );
  const username = await uniqueUsername(firebase, base);
  const profile = {
    ...profileFromUsername(username, "es"),
    uid,
  } satisfies UserProfile;

  await updateProfile(currentUser, {
    displayName: profile.alias || profile.username,
  }).catch(() => undefined);
  await setRestDocument(firebase, "users", uid, {
    ...profile,
    uid,
    updatedAtMs: Date.now(),
  });
  return profile;
}

async function uniqueUsername(firebase: FirebaseBundle, baseUsername: string) {
  const base = sanitizeUsername(baseUsername) || "usuario";
  const uid = firebase.auth.currentUser?.uid;
  if (!uid) throw new Error("Inicia sesión.");
  for (let index = 0; index < 50; index += 1) {
    const candidate = index === 0 ? base : `${base}-${index + 1}`;
    try {
      await reserveUsername(firebase, candidate, uid);
      return candidate;
    } catch (error) {
      const message = error instanceof Error ? error.message.toLowerCase() : "";
      if (!message.includes("usuario ya está en uso")) throw error;
    }
  }
  const fallback = `${base}-${crypto.randomUUID().slice(0, 6)}`;
  await reserveUsername(firebase, fallback, uid);
  return fallback;
}

async function reserveUsername(
  firebase: FirebaseBundle,
  username: string,
  uid: string,
) {
  const clean = sanitizeUsername(username);
  if (!clean || !uid) throw new Error("Introduce un usuario válido.");
  const existing = await getRestDocument(firebase, "usernames", clean).catch(() => null);
  if (existing) {
    if (String(existing.data.uid || "") === uid) return;
    throw new Error("Ese usuario ya está en uso.");
  }

  const response = await restFetch(
    firebase,
    `${documentUrl(firebase, "usernames", clean)}&currentDocument.exists=false`,
    {
      method: "PATCH",
      body: JSON.stringify({
        fields: objectToFields({ uid, username: clean, createdAtMs: Date.now() }),
      }),
    },
  );
  if (!response.ok) {
    const error = await firestoreRestError(response);
    if (error.message.toLowerCase().includes("exist")) {
      throw new Error("Ese usuario ya está en uso.");
    }
    throw error;
  }
}

function uniqueUsernames(values: string[]) {
  return [...new Set(values.map(normalizeUsername).filter(Boolean))];
}

function sanitizeUsername(value: string) {
  return normalizeUsername(value)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 32) || "usuario";
}

async function getFirebase(): Promise<FirebaseBundle> {
  if (!bundlePromise) bundlePromise = createFirebaseBundle();
  return bundlePromise;
}

async function createFirebaseBundle(): Promise<FirebaseBundle> {
  const config = await loadFirebaseConfig();
  if (!isConfigComplete(config)) {
    throw new Error(
      "Firebase no está configurado. Completa public/firebase-config.json con los datos del proyecto Salseo.",
    );
  }

  const readyConfig = config as FirebaseConfig;
  const app = getApps().length ? getApp() : initializeApp(readyConfig);
  const auth = getAuth(app);
  return { app, auth, config: readyConfig };
}

async function loadFirebaseConfig(): Promise<FirebaseConfig | null> {
  const windowConfig = window.SALSEO_FIREBASE_CONFIG;
  if (windowConfig && isConfigComplete(windowConfig)) return windowConfig;

  const envConfig = {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "",
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "",
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "",
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "",
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "",
    appId: import.meta.env.VITE_FIREBASE_APP_ID || "",
  };
  if (isConfigComplete(envConfig)) return envConfig;

  try {
    const response = await fetch(CONFIG_URL, { cache: "no-store" });
    if (!response.ok) return null;
    const json = (await response.json()) as FirebaseConfig;
    return json;
  } catch {
    return null;
  }
}

function isConfigComplete(config: FirebaseConfig | null | undefined) {
  return Boolean(
    config?.apiKey?.trim() &&
      config?.authDomain?.trim() &&
      config?.projectId?.trim() &&
      config?.appId?.trim(),
  );
}

async function firestoreToken(firebase: FirebaseBundle) {
  const user = firebase.auth.currentUser;
  if (!user) throw new Error("Inicia sesión.");
  return user.getIdToken(false);
}

function firestoreBase(firebase: FirebaseBundle) {
  const project = encodeURIComponent(firebase.config.projectId);
  return `https://firestore.googleapis.com/v1/projects/${project}/databases/(default)/documents`;
}

function documentUrl(firebase: FirebaseBundle, collectionId: string, documentId: string) {
  return `${firestoreBase(firebase)}/${encodeURIComponent(collectionId)}/${encodeURIComponent(documentId)}?key=${encodeURIComponent(firebase.config.apiKey)}`;
}

async function restFetch(
  firebase: FirebaseBundle,
  url: string,
  init: RequestInit = {},
) {
  const token = await firestoreToken(firebase);
  const response = await fetch(url, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
      ...(init.headers || {}),
    },
  });
  return response;
}

async function getRestDocument(
  firebase: FirebaseBundle,
  collectionId: string,
  documentId: string,
): Promise<{ id: string; data: Record<string, unknown> } | null> {
  const response = await restFetch(firebase, documentUrl(firebase, collectionId, documentId));
  if (response.status === 404) return null;
  if (!response.ok) throw await firestoreRestError(response);
  const json = (await response.json()) as FirestoreRestDocument;
  return { id: documentIdFromName(json.name) || documentId, data: fieldsToObject(json.fields || {}) };
}

async function setRestDocument(
  firebase: FirebaseBundle,
  collectionId: string,
  documentId: string,
  data: Record<string, unknown>,
) {
  const response = await restFetch(firebase, documentUrl(firebase, collectionId, documentId), {
    method: "PATCH",
    body: JSON.stringify({ fields: objectToFields(data) }),
  });
  if (!response.ok) throw await firestoreRestError(response);
}

async function createRestDocument(
  firebase: FirebaseBundle,
  collectionId: string,
  data: Record<string, unknown>,
) {
  const response = await restFetch(
    firebase,
    `${firestoreBase(firebase)}/${encodeURIComponent(collectionId)}?key=${encodeURIComponent(firebase.config.apiKey)}`,
    {
      method: "POST",
      body: JSON.stringify({ fields: objectToFields(data) }),
    },
  );
  if (!response.ok) throw await firestoreRestError(response);
}

async function deleteRestDocument(
  firebase: FirebaseBundle,
  collectionId: string,
  documentId: string,
) {
  const response = await restFetch(firebase, documentUrl(firebase, collectionId, documentId), {
    method: "DELETE",
  });
  if (response.status === 404) return;
  if (!response.ok) throw await firestoreRestError(response);
}

async function runCollectionQuery(
  firebase: FirebaseBundle,
  collectionId: string,
  options: {
    where?: Record<string, unknown>;
    orderBy?: Array<Record<string, unknown>>;
    limit?: number;
  } = {},
): Promise<Array<{ id: string; data: Record<string, unknown> }>> {
  const body = {
    structuredQuery: {
      from: [{ collectionId }],
      ...(options.where ? { where: options.where } : {}),
      ...(options.orderBy ? { orderBy: options.orderBy } : {}),
      ...(options.limit ? { limit: options.limit } : {}),
    },
  };
  const response = await restFetch(
    firebase,
    `${firestoreBase(firebase)}:runQuery?key=${encodeURIComponent(firebase.config.apiKey)}`,
    { method: "POST", body: JSON.stringify(body) },
  );
  if (!response.ok) throw await firestoreRestError(response);
  const json = (await response.json()) as FirestoreQueryResponseItem[];
  return json
    .map((item) => item.document)
    .filter((document): document is FirestoreRestDocument => Boolean(document))
    .map((document) => ({
      id: documentIdFromName(document.name),
      data: fieldsToObject(document.fields || {}),
    }))
    .filter((document) => Boolean(document.id));
}

function fieldFilter(fieldPath: string, op: string, value: FirestoreRestValue) {
  return {
    fieldFilter: {
      field: { fieldPath },
      op,
      value,
    },
  };
}

function documentIdFromName(name?: string) {
  if (!name) return "";
  return decodeURIComponent(name.split("/").pop() || "");
}

function objectToFields(input: Record<string, unknown>) {
  const fields: Record<string, FirestoreRestValue> = {};
  Object.entries(input).forEach(([key, value]) => {
    if (value === undefined) return;
    fields[key] = jsToFirestoreValue(value);
  });
  return fields;
}

function jsToFirestoreValue(value: unknown): FirestoreRestValue {
  if (value === null) return { nullValue: null };
  if (typeof value === "boolean") return { booleanValue: value };
  if (typeof value === "number") {
    if (Number.isInteger(value)) return { integerValue: String(value) };
    return { doubleValue: value };
  }
  if (typeof value === "string") return stringValue(value);
  if (Array.isArray(value)) {
    return { arrayValue: { values: value.map(jsToFirestoreValue) } };
  }
  if (typeof value === "object") {
    return { mapValue: { fields: objectToFields(value as Record<string, unknown>) } };
  }
  return stringValue(String(value));
}

function stringValue(value: string): FirestoreRestValue {
  return { stringValue: value };
}

function fieldsToObject(fields: Record<string, FirestoreRestValue>) {
  const output: Record<string, unknown> = {};
  Object.entries(fields).forEach(([key, value]) => {
    output[key] = firestoreValueToJs(value);
  });
  return output;
}

function firestoreValueToJs(value: FirestoreRestValue): unknown {
  if ("nullValue" in value) return null;
  if ("booleanValue" in value) return Boolean(value.booleanValue);
  if ("integerValue" in value) return Number(value.integerValue || 0);
  if ("doubleValue" in value) return Number(value.doubleValue || 0);
  if ("stringValue" in value) return String(value.stringValue || "");
  if ("timestampValue" in value) return String(value.timestampValue || "");
  if ("arrayValue" in value) return (value.arrayValue?.values || []).map(firestoreValueToJs);
  if ("mapValue" in value) return fieldsToObject(value.mapValue?.fields || {});
  return "";
}

async function firestoreRestError(response: Response) {
  let message = `Firestore respondió ${response.status}.`;
  try {
    const json = await response.json();
    const raw = json?.error?.message;
    if (raw) message = String(raw);
  } catch {
    // Mantener el mensaje HTTP si el cuerpo no es JSON.
  }
  return new Error(message);
}

function chatMessageFromData(
  id: string,
  data: Record<string, unknown>,
  currentUid: string,
): ChatMessage {
  return {
    id: String(data.id || id),
    author: String(data.author || "usuario"),
    authorUid: data.authorUid ? String(data.authorUid) : undefined,
    body: String(data.body || ""),
    mediaUrl: data.mediaUrl ? String(data.mediaUrl) : undefined,
    createdAt: String(data.createdAt || ""),
    mine: Boolean(currentUid && data.authorUid === currentUid),
    direct: Boolean(data.direct),
    recipientUsername: data.recipientUsername ? String(data.recipientUsername) : undefined,
    recipientUid: data.recipientUid ? String(data.recipientUid) : undefined,
    conversationKey: data.conversationKey ? String(data.conversationKey) : undefined,
    createdAtMs: Number(data.createdAtMs || 0),
  };
}

function communityPostFromData(
  id: string,
  data: Record<string, unknown>,
): CommunityPost {
  return {
    id: String(data.id || id),
    author: String(data.author || "usuario"),
    handle: String(data.handle || data.author || "usuario"),
    title: String(data.title || "Comentario"),
    body: String(data.body || ""),
    tags: Array.isArray(data.tags) ? data.tags.map(String) : [],
    mediaUrl: data.mediaUrl ? String(data.mediaUrl) : undefined,
    linkUrl: data.linkUrl ? String(data.linkUrl) : undefined,
    createdAt: String(data.createdAt || ""),
    likes: Number(data.likes || 0),
    replies: Number(data.replies || 0),
    status:
      data.status === "hidden" || data.status === "pending"
        ? data.status
        : "approved",
  };
}

function salseoNotificationFromData(
  id: string,
  data: Record<string, unknown>,
): SalseoNotification {
  return {
    id,
    targetUid: String(data.targetUid || ""),
    targetUsername: String(data.targetUsername || ""),
    type:
      data.type === "follow" ||
      data.type === "chat" ||
      data.type === "post" ||
      data.type === "favorite"
        ? data.type
        : "post",
    title: String(data.title || "Salseo"),
    body: String(data.body || "Nueva actividad"),
    actor: String(data.actor || "usuario"),
    actorUsername: String(data.actorUsername || data.actor || "usuario"),
    entityId: data.entityId ? String(data.entityId) : undefined,
    createdAt: String(data.createdAt || ""),
    createdAtMs: Number(data.createdAtMs || 0),
  };
}

function userProfileFromData(data: Record<string, unknown>): UserProfile {
  return {
    uid: data.uid ? String(data.uid) : undefined,
    username: String(data.username || "usuario"),
    alias: String(data.alias || data.username || "usuario"),
    role:
      data.role === "Creador / Moderador"
        ? "Creador / Moderador"
        : "Usuario registrado",
    joinedAt: String(data.joinedAt || new Date().toISOString().slice(0, 10)),
    preferredLanguage:
      data.preferredLanguage === "en" || data.preferredLanguage === "fr"
        ? data.preferredLanguage
        : "es",
    avatarUrl: data.avatarUrl ? String(data.avatarUrl) : "",
    backgroundUrl: data.backgroundUrl ? String(data.backgroundUrl) : "",
    bio: data.bio ? String(data.bio) : "",
    followingUsers: Array.isArray(data.followingUsers)
      ? data.followingUsers.map(String).filter(Boolean)
      : [],
    friendListPrivate: Boolean(data.friendListPrivate),
  };
}

function profileFromUsername(
  username: string,
  preferredLanguage: Language,
): UserProfile {
  const clean = normalizeUsername(username);
  return {
    username: clean,
    alias: clean,
    role: "Usuario registrado",
    joinedAt: new Date().toISOString().slice(0, 10),
    preferredLanguage,
    avatarUrl: "",
    backgroundUrl: "",
    bio: "",
    followingUsers: [],
    friendListPrivate: false,
  };
}

function directConversationKey(firstUid: string, secondUid: string) {
  return [firstUid, secondUid].sort().join("__");
}

function normalizeUsername(value: string) {
  return value.trim().toLowerCase();
}

function normalizeEmail(value: string) {
  return value.trim().toLowerCase();
}
