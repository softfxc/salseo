import type { Language, NavView } from "./types";

export type UiCopy = {
  nav: Record<NavView, string>;
  auth: {
    signup: string;
    login: string;
    submitSignup: string;
    submitLogin: string;
    reader: string;
    username: string;
    email: string;
    password: string;
    pin: string;
    pin2fa: string;
    verifyPin: string;
    back: string;
    localOnly: string;
  };
  search: {
    title: string;
    placeholder: string;
    history: string;
    suggestions: string;
    noResults: string;
    searching: string;
    sources: string;
  };
  recipe: {
    ingredients: string;
    steps: string;
    sourceOnly: string;
    discuss: string;
  };
  posts: {
    publish: string;
    title: string;
    body: string;
    photo: string;
    photoReady: string;
    imageUrl: string;
    postUrl: string;
    upload: string;
    pending: string;
    favs: string;
    replies: string;
    loginRequired: string;
  };
  chat: {
    title: string;
    placeholder: string;
    send: string;
    p2pFilter: string;
    discard: string;
    restore: string;
    readerNotice: string;
  };
  favorites: {
    title: string;
    empty: string;
  };
  profile: {
    prepared: string;
    network: string;
    favorites: string;
    review: string;
    moderation: string;
    empty: string;
    logout: string;
    editPhotos: string;
    memberSince: string;
    about: string;
    noBio: string;
  };
  settings: {
    title: string;
    language: string;
    notifications: string;
    background: string;
    clearHistory: string;
    logout: string;
    logoutWarning: string;
    avatar: string;
    backgroundImage: string;
    imageUrl: string;
    public: string;
    bio: string;
    bioPlaceholder: string;
    bioHelp: string;
    readerLocked: string;
    privacyNotice: string;
    general: string;
    preferences: string;
    aboutApp: string;
    privacyPolicy: string;
    notificationLabels: {
      chat: string;
      follow: string;
      post: string;
      favorite: string;
    };
    notificationHelper: string;
    notificationPermissionDenied: string;
    friendListPrivate: string;
    version: string;
    checkingUpdates: string;
    checkUpdates: string;
    updateAvailable: string;
    upToDate: string;
    updateCheckFailed: string;
    deleteAccount: string;
  };
  actions: {
    save: string;
    search: string;
    open: string;
  };
  common: {
    profile: string;
    previewTitle: string;
    profilePreview: string;
    shareMyProfile: string;
    shareProfile: string;
    follow: string;
    following: string;
    message: string;
    followers: string;
    followingUsers: string;
    noUsers: string;
    privateFriendsList: string;
    back: string;
    editProfile: string;
    changeAvatar: string;
    changeBackground: string;
    guest: string;
    followersTitle: string;
    followingTitle: string;
    deleteMessage: string;
    deleteMessageConfirm: string;
  };
};

export const copyByLang: Record<Language, UiCopy> = {
  es: {
    nav: {
      buscar: "Inicio",
      chats: "Chats",
      favoritos: "Favoritos",
      posts: "Posts",
      perfil: "Perfil",
      ajustes: "Ajustes",
      preparados: "Preparados",
      editarPerfil: "Editar perfil",
      perfilVista: "Vista previa",
      amistades: "Amigos",
      detalleReceta: "Receta",
    },
    auth: {
      signup: "Crear cuenta",
      login: "Iniciar sesión",
      submitSignup: "Crear cuenta",
      submitLogin: "Iniciar sesión",
      reader: "Entrar como invitado",
      username: "Usuario",
      email: "Email",
      password: "Contraseña",
      pin: "PIN",
      pin2fa: "PIN",
      verifyPin: "Verificar PIN",
      back: "Volver",
      localOnly:
        "La cuenta es local. Sirve para comentar, subir fotos y firmar aportes en este dispositivo, sin servidor central.",
    },
    search: {
      title: "Buscar",
      placeholder: "Buscar",
      history: "Historial de búsqueda",
      suggestions: "Sugerencias",
      noResults: "",
      searching: "Cargando...",
      sources: "Fuentes consultadas",
    },
    recipe: {
      ingredients: "Ingredientes",
      steps: "Preparación",
      sourceOnly: "Toca Ver para abrir la ficha de Salseo.",
      discuss: "Comentar",
    },
    posts: {
      publish: "Publicar",
      title: "Título del post",
      body: "Comentario, pregunta o truco",
      photo: "Foto",
      photoReady: "Foto lista",
      imageUrl: "URL de imagen",
      postUrl: "URL relacionada",
      upload: "Subir post",
      pending: "Revisión",
      favs: "favs",
      replies: "respuestas",
      loginRequired:
        "Como invitado solo puedes leer y guardar favoritos. Para comentar o subir fotos necesitas registrarte.",
    },
    chat: {
      title: "Chats",
      placeholder: "Escribe un mensaje...",
      send: "Enviar",
      p2pFilter: "Descartar usuarios del feed",
      discard: "Descartar",
      restore: "Restaurar",
      readerNotice:
        "Como invitado solo puedes leer. Regístrate para participar en chats.",
    },
    favorites: {
      title: "Favoritos",
      empty:
        "Todavía no has guardado favoritos. Puedes guardar recetas, vídeos y posts tocando el corazón.",
    },
    profile: {
      prepared: "Preparados",
      network: "Red",
      favorites: "Favoritos",
      review: "Revisión",
      moderation: "Moderación",
      empty: "No hay posts pendientes.",
      logout: "Cerrar sesión",
      editPhotos: "Editar fotografías",
      memberSince: "Miembro desde",
      about: "Sobre mí",
      noBio: "Sin biografía todavía.",
    },
    settings: {
      title: "Ajustes",
      language: "Idioma",
      notifications: "Notificaciones",
      background: "Segundo plano",
      clearHistory: "Borrar historial de búsqueda",
      logout: "Cerrar sesión",
      logoutWarning:
        "¿Seguro que deseas cerrar sesión?",
      avatar: "Foto de perfil",
      backgroundImage: "Fondo de perfil",
      imageUrl: "URL de imagen",
      public: "Público",
      bio: "Sobre mí",
      bioPlaceholder: "Escribe tu biografía",
      bioHelp: "",
      readerLocked: "Como invitado no puedes modificar el perfil.",
      privacyNotice:
        "Salseo pide el uso responsable de la aplicación y recomienda evitar publicar fotos de personas o mascotas. Si necesita conocer más detalles sobre nosotros puede leer nuestra Política de privacidad en https://github.com/softfxc/salseo.",
      general: "GENERAL",
      preferences: "PREFERENCIAS",
      aboutApp: "ACERCA DE",
      privacyPolicy: "Política de privacidad",
      notificationLabels: {
        chat: "Mensajes",
        follow: "Seguidores",
        post: "Publicaciones",
        favorite: "Favoritos",
      },
      notificationHelper:
        "Los avisos se mostrarán como notificaciones reales del dispositivo, no como una lista dentro de Ajustes.",
      notificationPermissionDenied:
        "No se concedió el permiso de notificaciones. Puedes activarlo después desde los ajustes del teléfono.",
      friendListPrivate: "Lista de amigos privada",
      version: "Versión",
      checkingUpdates: "Comprobando...",
      checkUpdates: "Buscar actualizaciones",
      updateAvailable: "Actualización disponible",
      upToDate: "Salseo está actualizado",
      updateCheckFailed: "No se pudo comprobar la actualización.",
      deleteAccount: "Eliminar cuenta",
    },
    actions: { save: "Guardar", search: "Buscar", open: "Abrir" },
    common: {
      profile: "Perfil",
      previewTitle: "Vista previa",
      profilePreview: "Vista previa del perfil",
      shareMyProfile: "Compartir mi perfil",
      shareProfile: "Compartir perfil",
      follow: "Seguir",
      following: "Siguiendo",
      message: "Mensaje",
      followers: "seguidores",
      followingUsers: "seguidos",
      noUsers: "No hay usuarios para mostrar.",
      privateFriendsList: "Este usuario tiene privada su lista de amigos.",
      back: "Volver",
      editProfile: "Editar perfil",
      changeAvatar: "Cambiar foto de perfil",
      changeBackground: "Cambiar fondo",
      guest: "Invitado",
      followersTitle: "Seguidores",
      followingTitle: "Seguidos",
      deleteMessage: "Eliminar",
      deleteMessageConfirm: "¿Eliminar este mensaje?",
    },
  },
  en: {
    nav: {
      buscar: "Home",
      chats: "Chats",
      favoritos: "Saved",
      posts: "Posts",
      perfil: "Profile",
      ajustes: "Settings",
      preparados: "Prepared",
      editarPerfil: "Edit profile",
      perfilVista: "Preview",
      amistades: "Friends",
      detalleReceta: "Recipe",
    },
    auth: {
      signup: "Sign up",
      login: "Login",
      submitSignup: "Create account",
      submitLogin: "Continue",
      reader: "Enter as guest",
      username: "Public username",
      email: "Email",
      password: "Password",
      pin: "PIN",
      pin2fa: "2FA PIN",
      verifyPin: "Verify PIN",
      back: "Back",
      localOnly:
        "The account is local. It lets you comment, upload photos and sign contributions on this device, without a central server.",
    },
    search: {
      title: "Search recipes and videos",
      placeholder: "Example: omelette, croquettes, chicken rice...",
      history: "Search history",
      suggestions: "Suggestions",
      noResults: "",
      searching: "Loading...",
      sources: "Sources checked",
    },
    recipe: {
      ingredients: "Ingredients",
      steps: "Preparation",
      sourceOnly: "Tap View to open the Salseo recipe card.",
      discuss: "Comment",
    },
    posts: {
      publish: "Publish",
      title: "Post title",
      body: "Comment, question or trick",
      photo: "Photo",
      photoReady: "Photo ready",
      imageUrl: "Image URL",
      postUrl: "Related URL",
      upload: "Upload post",
      pending: "Review",
      favs: "favs",
      replies: "replies",
      loginRequired:
        "As a guest you can only read and save favorites. Create an account to comment or upload photos.",
    },
    chat: {
      title: "Chats",
      placeholder: "Write a message...",
      send: "Send",
      p2pFilter: "Discard users from feed",
      discard: "Discard",
      restore: "Restore",
      readerNotice: "As a guest you can only read. Sign up to join chats.",
    },
    favorites: {
      title: "Saved",
      empty:
        "You have not saved anything yet. Tap the heart to save recipes, videos and posts.",
    },
    profile: {
      prepared: "Prepared",
      network: "Network",
      favorites: "Saved",
      review: "Review",
      moderation: "Moderation",
      empty: "No pending posts.",
      logout: "Log out",
      editPhotos: "Edit photographs",
      memberSince: "Member since",
      about: "About me",
      noBio: "No biography yet.",
    },
    settings: {
      title: "Settings",
      language: "Language",
      notifications: "Notifications",
      background: "Background",
      clearHistory: "Clear search history",
      logout: "Log out",
      logoutWarning:
        "Logging out will remove posts, comments, favorites and profile from this device. Continue?",
      avatar: "Profile photo",
      backgroundImage: "Profile background",
      imageUrl: "Image URL",
      public: "Public",
      bio: "About me",
      bioPlaceholder: "Write your biography",
      bioHelp: "",
      readerLocked: "Guests cannot edit the profile.",
      privacyNotice:
        "Salseo requests responsible use of the application and recommends avoiding photos of people or pets. To learn more, read our Privacy Policy at https://github.com/softfxc/salseo.",
      general: "GENERAL",
      preferences: "PREFERENCES",
      aboutApp: "ABOUT",
      privacyPolicy: "Privacy Policy",
      notificationLabels: {
        chat: "Messages",
        follow: "Followers",
        post: "Posts",
        favorite: "Favorites",
      },
      notificationHelper:
        "Alerts will appear as real device notifications, not as a list inside Settings.",
      notificationPermissionDenied:
        "Notification permission was not granted. You can enable it later from your phone settings.",
      friendListPrivate: "Private friends list",
      version: "Version",
      checkingUpdates: "Checking...",
      checkUpdates: "Check for updates",
      updateAvailable: "Update available",
      upToDate: "Salseo is up to date",
      updateCheckFailed: "Could not check for updates.",
      deleteAccount: "Delete account",
    },
    actions: { save: "Save", search: "Search", open: "Open" },
    common: {
      profile: "Profile",
      previewTitle: "Preview",
      profilePreview: "Profile preview",
      shareMyProfile: "Share my profile",
      shareProfile: "Share profile",
      follow: "Follow",
      following: "Following",
      message: "Message",
      followers: "followers",
      followingUsers: "following",
      noUsers: "No users to show.",
      privateFriendsList: "This user has a private friends list.",
      back: "Back",
      editProfile: "Edit profile",
      changeAvatar: "Change profile photo",
      changeBackground: "Change background",
      guest: "Guest",
      followersTitle: "Followers",
      followingTitle: "Following",
      deleteMessage: "Delete",
      deleteMessageConfirm: "Delete this message?",
    },
  },
  fr: {
    nav: {
      buscar: "Accueil",
      chats: "Chats",
      favoritos: "Favoris",
      posts: "Posts",
      perfil: "Profil",
      ajustes: "Réglages",
      preparados: "Préparés",
      editarPerfil: "Modifier profil",
      perfilVista: "Aperçu",
      amistades: "Amis",
      detalleReceta: "Recette",
    },
    auth: {
      signup: "Inscription",
      login: "Login",
      submitSignup: "Créer compte",
      submitLogin: "Continuer",
      reader: "Entrer comme invité",
      username: "Nom public",
      email: "Email",
      password: "Mot de passe",
      pin: "PIN",
      pin2fa: "PIN",
      verifyPin: "Vérifier PIN",
      back: "Retour",
      localOnly:
        "Le compte est local. Il permet de commenter, publier des photos et signer des apports sur cet appareil, sans serveur central.",
    },
    search: {
      title: "Chercher recettes et vidéos",
      placeholder: "Exemple : omelette, croquettes, riz au poulet...",
      history: "Historique de recherche",
      suggestions: "Suggestions",
      noResults:
        "Aucun résultat pour cette recherche. Essaie une autre phrase ou vérifie la connexion.",
      searching: "Chargement...",
      sources: "Sources consultées",
    },
    recipe: {
      ingredients: "Ingrédients",
      steps: "Préparation",
      sourceOnly: "Ouvre la source pour voir la recette complète.",
      discuss: "Commenter",
    },
    posts: {
      publish: "Publier",
      title: "Titre du post",
      body: "Commentaire, question ou astuce",
      photo: "Photo",
      photoReady: "Photo prête",
      imageUrl: "URL image",
      postUrl: "URL liée",
      upload: "Publier",
      pending: "Révision",
      favs: "favoris",
      replies: "réponses",
      loginRequired:
        "Comme invité, tu peux seulement lire et garder des favoris. Crée un compte pour commenter ou publier des photos.",
    },
    chat: {
      title: "Chats",
      placeholder: "Écris un message...",
      send: "Envoyer",
      p2pFilter: "Écarter utilisateurs du feed",
      discard: "Écarter",
      restore: "Restaurer",
      readerNotice:
        "Comme invité, tu peux seulement lire. Inscris-toi pour participer aux chats.",
    },
    favorites: {
      title: "Favoris",
      empty:
        "Tu n'as encore rien gardé. Touche le cœur pour garder recettes, vidéos et posts.",
    },
    profile: {
      prepared: "Préparés récemment",
      network: "Réseau",
      favorites: "Favoris",
      review: "Révision",
      moderation: "Modération",
      empty: "Aucun post en attente.",
      logout: "Fermer session",
      editPhotos: "Modifier photographies",
      memberSince: "Membre depuis",
      about: "À propos de moi",
      noBio: "Aucune biographie pour le moment.",
    },
    settings: {
      title: "Réglages",
      language: "Langue",
      notifications: "Notifications",
      background: "Arrière-plan",
      clearHistory: "Effacer l'historique de recherche",
      logout: "Fermer session",
      logoutWarning:
        "Fermer la session supprimera de cet appareil posts, commentaires, favoris et profil. Continuer ?",
      avatar: "Photo de profil",
      backgroundImage: "Fond de profil",
      imageUrl: "URL image",
      public: "Public",
      bio: "À propos de moi",
      bioPlaceholder: "Écris ta biographie",
      bioHelp: "",
      readerLocked: "Les invités ne peuvent pas modifier le profil.",
      privacyNotice:
        "Salseo demande un usage responsable de l'application et recommande d'éviter les photos de personnes ou d'animaux. Pour plus d'informations, lisez notre Politique de confidentialité sur https://github.com/softfxc/salseo.",
      general: "GÉNÉRAL",
      preferences: "PRÉFÉRENCES",
      aboutApp: "À PROPOS",
      privacyPolicy: "Politique de confidentialité",
      notificationLabels: {
        chat: "Messages",
        follow: "Abonnés",
        post: "Publications",
        favorite: "Favoris",
      },
      notificationHelper:
        "Les alertes apparaîtront comme de vraies notifications de l'appareil, pas comme une liste dans les réglages.",
      notificationPermissionDenied:
        "L'autorisation de notifications n'a pas été accordée. Vous pouvez l'activer plus tard dans les réglages du téléphone.",
      friendListPrivate: "Liste d'amis privée",
      version: "Version",
      checkingUpdates: "Vérification...",
      checkUpdates: "Rechercher des mises à jour",
      updateAvailable: "Mise à jour disponible",
      upToDate: "Salseo est à jour",
      updateCheckFailed: "Impossible de vérifier la mise à jour.",
      deleteAccount: "Supprimer le compte",
    },
    actions: { save: "Enregistrer", search: "Chercher", open: "Ouvrir" },
    common: {
      profile: "Profil",
      previewTitle: "Aperçu",
      profilePreview: "Aperçu du profil",
      shareMyProfile: "Partager mon profil",
      shareProfile: "Partager le profil",
      follow: "Suivre",
      following: "Abonné",
      message: "Message",
      followers: "abonnés",
      followingUsers: "abonnements",
      noUsers: "Aucun utilisateur à afficher.",
      privateFriendsList: "Cet utilisateur a une liste d'amis privée.",
      back: "Retour",
      editProfile: "Modifier le profil",
      changeAvatar: "Changer la photo de profil",
      changeBackground: "Changer le fond",
      guest: "Invité",
      followersTitle: "Abonnés",
      followingTitle: "Abonnements",
      deleteMessage: "Supprimer",
      deleteMessageConfirm: "Supprimer ce message ?",
    },
  },
};
