export const APP_VERSION_LABEL = "1.0-release";

const DEFAULT_REPO = "softfxc/salseo";
const CONFIG_URL = "/app-update.json";
const REQUEST_TIMEOUT_MS = 12000;

type UpdateConfig = {
  repo?: string;
  currentVersion?: string;
  latestUrl?: string;
  assetPattern?: string;
};

export type AppUpdateInfo = {
  currentVersion: string;
  latestVersion: string;
  available: boolean;
  releaseUrl: string;
  assetUrl: string;
  notes: string;
  repo: string;
};

export async function checkForAppUpdate(): Promise<AppUpdateInfo> {
  const config = await loadUpdateConfig();
  const repo = normalizeRepo(config.repo || DEFAULT_REPO);
  const currentVersion = normalizeVersion(config.currentVersion || APP_VERSION_LABEL);
  const latestUrl = buildLatestReleaseUrl(config.latestUrl, repo);
  const response = await fetchWithTimeout(latestUrl, {
    cache: "no-store",
    headers: {
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
    },
  });

  if (!response.ok) {
    throw new Error("No se pudo comprobar la actualización.");
  }

  const data = await response.json();
  const latestVersion = normalizeVersion(String(data.tag_name || data.name || ""));
  if (!latestVersion) {
    throw new Error("No se pudo comprobar la actualización.");
  }

  const releaseUrl = String(data.html_url || `https://github.com/${repo}/releases/latest`);
  const assetUrl = selectDownloadUrl(data, config.assetPattern) || releaseUrl;

  return {
    currentVersion,
    latestVersion,
    available: latestVersion !== currentVersion,
    releaseUrl,
    assetUrl,
    notes: String(data.body || ""),
    repo,
  };
}

async function loadUpdateConfig(): Promise<UpdateConfig> {
  try {
    const response = await fetch(CONFIG_URL, { cache: "no-store" });
    if (!response.ok) return {};
    const data = await response.json();
    return data && typeof data === "object" ? data : {};
  } catch {
    return {};
  }
}

function buildLatestReleaseUrl(value: string | undefined, repo: string) {
  const clean = String(value || "").trim();
  if (clean) return clean;
  return `https://api.github.com/repos/${repo}/releases/latest`;
}

function selectDownloadUrl(data: any, assetPattern?: string) {
  const assets = Array.isArray(data?.assets) ? data.assets : [];
  const pattern = compileAssetPattern(assetPattern);
  const apkAssets = assets
    .filter((asset: any) => /\.apk$/i.test(String(asset?.name || asset?.browser_download_url || "")))
    .sort((a: any, b: any) => scoreAsset(b, pattern) - scoreAsset(a, pattern));
  return String(apkAssets[0]?.browser_download_url || "");
}

function compileAssetPattern(value?: string) {
  const clean = String(value || "").trim();
  if (!clean) return null;
  try {
    return new RegExp(clean, "i");
  } catch {
    return null;
  }
}

function scoreAsset(asset: any, pattern: RegExp | null) {
  const name = String(asset?.name || "");
  let score = 0;
  if (pattern?.test(name)) score += 100;
  if (/release/i.test(name)) score += 20;
  if (/universal/i.test(name)) score += 15;
  if (/arm64|v8a/i.test(name)) score += 8;
  if (/debug/i.test(name)) score -= 10;
  return score;
}

async function fetchWithTimeout(input: RequestInfo | URL, init: RequestInit = {}) {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    return await fetch(input, { ...init, signal: controller.signal });
  } catch {
    throw new Error("No se pudo comprobar la actualización.");
  } finally {
    window.clearTimeout(timer);
  }
}

function normalizeRepo(value: string) {
  return (
    value
      .trim()
      .replace(/^https:\/\/github\.com\//i, "")
      .replace(/\.git$/i, "")
      .replace(/^\/+|\/+$/g, "") || DEFAULT_REPO
  );
}

function normalizeVersion(value: string) {
  return value.trim().replace(/^v/i, "");
}
