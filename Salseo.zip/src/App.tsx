import {
  ArrowLeft,
  Camera,
  Check,
  CheckCircle2,
  ChevronRight,
  Copy,
  EllipsisVertical,
  Eye,
  EyeOff,
  Heart,
  Home,
  ImagePlus,
  KeyRound,
  Link2,
  MessageCircle,
  Play,
  Search,
  Send,
  Settings,
  ShieldCheck,
  Trash2,
  UserRound,
  X,
} from "lucide-react";
import {
  ChangeEvent,
  FormEvent,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  defaultAvatarUrl,
  defaultBackgroundUrl,
  privacyPolicyUrl,
  defaultNotificationPrefs,
  emptyProfile,
  initialHistory,
  seedChat,
  seedPosts,
} from "./data";
import {
  continueWithGoogle,
  createAccount,
  createReaderProfile,
  requestPasswordReset,
  verifyCredentials,
} from "./auth";
import { copyByLang, type UiCopy } from "./i18n";
import { APP_VERSION_LABEL, checkForAppUpdate, type AppUpdateInfo } from "./appUpdates";
import { requestSalseoNotificationPermission, showSalseoNotification } from "./nativeNotify";
import { runExternalSearch } from "./search";
import {
  deleteDirectChatMessage,
  deleteFirebaseAccount,
  notifyFollowersOfProfile,
  notifyUserByUsername,
  publishChatMessage,
  publishCommunityPost,
  publishDirectChatMessage,
  readProfileFriendList,
  readUserProfileByUsername,
  readProfileSocialCounts,
  searchUserProfilesByPrefix,
  saveCloudProfile,
  signOutFirebase,
  subscribeToCloudChat,
  subscribeToCloudPosts,
  subscribeToDirectChat,
  subscribeToUserNotifications,
} from "./firebaseClient";
import { useStoredState } from "./storage";
import type {
  ChatMessage,
  CommunityPost,
  Language,
  NavView,
  NotificationPrefs,
  RecipeResult,
  SalseoNotification,
  UserProfile,
} from "./types";

const MAX_PHOTO_SIZE = 5 * 1024 * 1024;
const randomId = (prefix: string) =>
  `${prefix}-${crypto.randomUUID().slice(0, 8)}`;
const bottomViews: NavView[] = ["buscar", "favoritos", "chats", "perfil"];
const renderedViews: NavView[] = [
  "buscar",
  "favoritos",
  "chats",
  "perfil",
  "ajustes",
  "editarPerfil",
  "perfilVista",
  "amistades",
  "detalleReceta",
];

function App() {
  const [lang, setLang] = useStoredState<Language>("salseo:lang:v13", "es");
  const [isAuthed, setIsAuthed] = useStoredState("salseo:authed:v13", false);
  const [profile, setProfile] = useStoredState<UserProfile>(
    "salseo:profile:v13",
    emptyProfile(lang),
  );
  const [view, setView] = useStoredState<NavView>("salseo:view:v13", "buscar");
  const [query, setQuery] = useStoredState("salseo:query:v13", "");
  const [history, setHistory] = useStoredState<string[]>(
    "salseo:history:v13",
    initialHistory,
  );
  const [preparedRecipes, setPreparedRecipes] = useStoredState<RecipeResult[]>(
    "salseo:prepared-recipes:v13",
    [],
  );
  const [favoriteRecipes, setFavoriteRecipes] = useStoredState<string[]>(
    "salseo:fav-recipes:v13",
    [],
  );
  const [favoritePosts, setFavoritePosts] = useStoredState<string[]>(
    "salseo:fav-posts:v13",
    [],
  );
  const [posts, setPosts] = useStoredState<CommunityPost[]>(
    "salseo:posts:v13",
    seedPosts,
  );
  const [chat, setChat] = useStoredState<ChatMessage[]>(
    "salseo:chat:v13",
    seedChat,
  );
  const [directChat, setDirectChat] = useStoredState<ChatMessage[]>(
    "salseo:direct-chat:v1",
    [],
  );
  const [notificationPrefs, setNotificationPrefs] =
    useStoredState<NotificationPrefs>(
      "salseo:notifications:v13",
      defaultNotificationPrefs,
    );
  const [ignoredUsers, setIgnoredUsers] = useStoredState<string[]>(
    "salseo:ignored-users:v13",
    [],
  );
  const [discardedPosts, setDiscardedPosts] = useStoredState<string[]>(
    "salseo:discarded-posts:v16",
    [],
  );
  const [results, setResults] = useState<RecipeResult[]>([]);
  const [userResults, setUserResults] = useState<UserProfile[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState("");
  const [selectedRecipe, setSelectedRecipe] = useState<RecipeResult | null>(
    null,
  );
  const [viewedProfile, setViewedProfile] = useState<UserProfile | null>(null);
  const [profileBackView, setProfileBackView] = useState<NavView>("chats");
  const [directRecipient, setDirectRecipient] = useState<UserProfile | null>(null);
  const [cloudNotifications, setCloudNotifications] = useState<SalseoNotification[]>([]);
  const [friendListContext, setFriendListContext] = useState<{
    profile: UserProfile;
    kind: "followers" | "following";
  } | null>(null);
  const [friendListUsers, setFriendListUsers] = useState<UserProfile[]>([]);
  const [friendListLoading, setFriendListLoading] = useState(false);

  const copy = copyByLang[lang];
  const activeProfile = normalizeProfile(profile, lang);
  const isReader = activeProfile.role === "Solo lector";
  const currentView: NavView =
    !renderedViews.includes(view) || (view === "detalleReceta" && !selectedRecipe)
      ? "buscar"
      : view === "amistades" && !friendListContext
        ? "perfil"
        : view;

  useEffect(() => {
    if (!renderedViews.includes(view)) {
      setView("buscar");
      return;
    }
    if (view === "detalleReceta" && !selectedRecipe) {
      setView("buscar");
    }
    if (view === "amistades" && !friendListContext) {
      setView("perfil");
    }
  }, [view, selectedRecipe, friendListContext, setView]);

  useEffect(() => {
    if (!isAuthed) return undefined;
    return subscribeToCloudChat(setChat);
  }, [isAuthed, setChat]);

  useEffect(() => {
    if (!isAuthed) return undefined;
    return subscribeToDirectChat(
      setDirectChat,
      (message) =>
        notifyIfAllowed(
          notificationPrefs,
          "chat",
          `Mensaje de @${message.author}`,
          message.body || "Nuevo mensaje directo",
        ),
    );
  }, [isAuthed, notificationPrefs, setDirectChat]);

  useEffect(() => {
    if (!isAuthed) return undefined;
    return subscribeToUserNotifications(
      setCloudNotifications,
      (notification) =>
        notifyIfAllowed(
          notificationPrefs,
          notification.type,
          notification.title,
          notification.body,
        ),
    );
  }, [isAuthed, notificationPrefs]);

  useEffect(() => {
    if (!isAuthed) return undefined;
    return subscribeToCloudPosts(setPosts);
  }, [isAuthed, setPosts]);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    const clean = normalizeProfile(profile, lang);
    if (JSON.stringify(clean) !== JSON.stringify(profile)) setProfile(clean);
  }, [profile, lang, setProfile]);

  const visiblePosts = useMemo(
    () =>
      posts.filter(
        (post) =>
          post.status === "approved" &&
          !ignoredUsers.includes(post.author) &&
          !discardedPosts.includes(post.id),
      ),
    [posts, ignoredUsers, discardedPosts],
  );

  useEffect(() => {
    setPreparedRecipes((current) => current.filter(hasInternalContent));
  }, [setPreparedRecipes]);

  const runSearch = async (nextQuery = query) => {
    const clean = nextQuery.trim();
    if (!clean) return;
    setQuery(clean);
    setView("buscar");
    setHistory((current) =>
      [
        clean,
        ...current.filter((item) => normalize(item) !== normalize(clean)),
      ].slice(0, 20),
    );
    setSearching(true);
    setSearchError("");

    try {
      if (clean.startsWith("@")) {
        const foundUsers = await searchUserProfilesByPrefix(clean.slice(1));
        setUserResults(foundUsers);
        setResults([]);
        return;
      }

      setUserResults([]);
      const report = await runExternalSearch(clean);
      setResults(report.results);
      if (report.results.length > 0) {
        setPreparedRecipes((current) =>
          mergeManyById(current, report.results).slice(0, 80),
        );
      }
      if (report.errors.length > 0 && report.results.length === 0)
        setSearchError("No se pudieron cargar resultados externos.");
    } catch (error) {
      setResults([]);
      setUserResults([]);
      setSearchError(
        error instanceof Error ? error.message : "La búsqueda falló.",
      );
    } finally {
      setSearching(false);
    }
  };

  const openRecipe = (recipe: RecipeResult) => {
    setSelectedRecipe(recipe);
    setView("detalleReceta");
  };

  const toggleRecipeFavorite = (id: string) => {
    const adding = !favoriteRecipes.includes(id);
    setFavoriteRecipes((current) => toggleId(current, id));
    if (adding && !isReader) {
      const recipe = [...results, ...preparedRecipes].find((item) => item.id === id);
      if (recipe) {
        void notifyFollowersOfProfile(activeProfile, {
          type: "favorite",
          title: `${activeProfile.alias || activeProfile.username} guardó un favorito`,
          body: recipe.title,
          entityId: recipe.id,
        }).catch(() => undefined);
      }
    }
  };
  const togglePostFavorite = (id: string) => {
    const adding = !favoritePosts.includes(id);
    setFavoritePosts((current) => toggleId(current, id));
    if (adding && !isReader) {
      const post = posts.find((item) => item.id === id);
      if (post) {
        void notifyFollowersOfProfile(activeProfile, {
          type: "favorite",
          title: `${activeProfile.alias || activeProfile.username} guardó un favorito`,
          body: post.title,
          entityId: post.id,
        }).catch(() => undefined);
      }
    }
  };

  const addPost = async (post: CommunityPost) => {
    setPosts((current) => mergeById(current, post));
    try {
      await publishCommunityPost(post);
      void notifyFollowersOfProfile(activeProfile, {
        type: "post",
        title: `${activeProfile.alias || activeProfile.username} publicó un comentario`,
        body: post.title,
        entityId: post.id,
      }).catch(() => undefined);
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "No se pudo publicar.");
    }
  };

  const discussRecipe = (recipe: RecipeResult) => {
    if (isReader) return;
    addPost({
      id: randomId("post"),
      author: activeProfile.username,
      handle: activeProfile.alias || activeProfile.username,
      title: `Comentario sobre: ${recipe.title}`,
      body: `Hilo abierto para comentar este resultado de ${recipe.sourceLabel}.`,
      tags: recipe.tags.slice(0, 4),
      linkUrl: recipe.sourceUrl,
      createdAt: nowLabel(),
      likes: 0,
      replies: 0,
      status: "approved",
    });
    setView("chats");
  };

  const sendChat = async (message: ChatMessage, recipient?: UserProfile | null) => {
    if (isReader) return;
    const target = recipient ? normalizeProfile(recipient, lang) : null;

    if (target && normalizeFollowName(target.username) !== normalizeFollowName(activeProfile.username)) {
      const directMessage: ChatMessage = {
        ...message,
        direct: true,
        author: activeProfile.username,
        authorUid: activeProfile.uid,
        recipientUsername: normalizeFollowName(target.username),
        recipientUid: target.uid,
        mine: true,
      };
      setDirectChat((current) => mergeById(current, directMessage));
      try {
        await publishDirectChatMessage(directMessage, target);
        void notifyUserByUsername(target.username, {
          type: "chat",
          title: `Mensaje directo de ${activeProfile.alias || activeProfile.username}`,
          body: directMessage.body || "Nuevo mensaje directo",
          actor: activeProfile.alias || activeProfile.username,
          actorUsername: activeProfile.username,
          entityId: directMessage.id,
        }).catch(() => undefined);
      } catch (error) {
        window.alert(error instanceof Error ? error.message : "No se pudo enviar el mensaje directo.");
      }
      return;
    }

    setChat((current) => mergeById(current, message));
    try {
      await publishChatMessage(message);
      void notifyFollowersOfProfile(
        activeProfile,
        {
          type: "chat",
          title: `Chat nuevo de ${activeProfile.alias || activeProfile.username}`,
          body: message.body || "Nuevo mensaje",
          entityId: message.id,
        },
        { mutualOnly: true },
      ).catch(() => undefined);
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "No se pudo enviar el mensaje.");
    }
  };

  const sendChatImageUrl = async (mediaUrl: string, recipient?: UserProfile | null) => {
    if (isReader) return;
    const cleanUrl = normalizeImageUrl(mediaUrl);
    if (!cleanUrl) {
      window.alert("Introduce una URL válida de imagen, empezando por https:// o http://");
      return;
    }
    await sendChat(
      {
        id: randomId("chat"),
        author: activeProfile.username,
        body: "Imagen",
        createdAt: nowLabel(),
        mine: true,
        mediaUrl: cleanUrl,
      },
      recipient,
    );
  };

  const deleteSentDirectMessage = async (message: ChatMessage) => {
    if (!message.direct || !message.mine) return;
    const confirmed = window.confirm(copy.common.deleteMessageConfirm);
    if (!confirmed) return;

    try {
      await deleteDirectChatMessage(message.id);
      setDirectChat((current) => current.filter((item) => item.id !== message.id));
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "No se pudo eliminar el mensaje.");
    }
  };

  const discardPost = (postId: string) => {
    if (!postId) return;
    setDiscardedPosts((current) =>
      current.includes(postId) ? current : [postId, ...current],
    );
    window.alert("Entrada descartada.");
  };

  const toggleFollowAuthor = (author: string) => {
    const cleanAuthor = normalizeFollowName(author);
    if (!cleanAuthor || cleanAuthor === normalizeFollowName(activeProfile.username)) return;
    const currentFollowing = activeProfile.followingUsers || [];
    const alreadyFollowing = currentFollowing.includes(cleanAuthor);
    const nextFollowing = toggleId(currentFollowing, cleanAuthor);
    const nextProfile = { ...activeProfile, followingUsers: nextFollowing };
    setProfile(nextProfile);
    void saveCloudProfile(nextProfile).catch((error) =>
      window.alert(error instanceof Error ? error.message : "No se pudo guardar el seguimiento."),
    );
    if (!alreadyFollowing) {
      void notifyUserByUsername(cleanAuthor, {
        type: "follow",
        title: "Nuevo seguidor",
        body: `${activeProfile.alias || activeProfile.username} ha empezado a seguirte`,
        actor: activeProfile.alias || activeProfile.username,
        actorUsername: activeProfile.username,
      }).catch(() => undefined);
    }
  };

  const openPublicProfile = (author: string) => {
    const cleanAuthor = normalizeFollowName(author);
    if (!cleanAuthor) return;
    if (cleanAuthor === normalizeFollowName(activeProfile.username)) {
      setViewedProfile(null);
      setView("perfil");
      return;
    }
    setProfileBackView(view);
    setViewedProfile({
      username: cleanAuthor,
      alias: cleanAuthor,
      role: "Usuario registrado",
      joinedAt: new Date().toISOString().slice(0, 10),
      preferredLanguage: lang,
      avatarUrl: "",
      backgroundUrl: "",
      bio: "",
      followingUsers: [],
    });
    setView("perfilVista");
    void readUserProfileByUsername(cleanAuthor)
      .then((found) => {
        if (found) setViewedProfile(normalizeProfile(found, lang));
      })
      .catch(() => undefined);
  };

  useEffect(() => {
    if (!isAuthed) return;
    const params = new URLSearchParams(window.location.search);
    const sharedProfile = params.get("perfil") || params.get("profile");
    if (sharedProfile) openPublicProfile(sharedProfile);
    // Se ejecuta solo al entrar para resolver enlaces compartidos.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthed]);

  const startDirectMessage = (targetProfile: UserProfile) => {
    if (isReader) return;
    const target = normalizeProfile(targetProfile, lang);
    if (!target.uid) {
      void readUserProfileByUsername(target.username)
        .then((found) => {
          if (found) setDirectRecipient(normalizeProfile(found, lang));
          else setDirectRecipient(target);
          setView("chats");
        })
        .catch(() => {
          setDirectRecipient(target);
          setView("chats");
        });
      return;
    }
    setDirectRecipient(target);
    setView("chats");
  };

  const openFriendList = async (targetProfile: UserProfile, kind: "followers" | "following") => {
    const target = normalizeProfile(targetProfile, lang);
    const isOwn = normalizeFollowName(target.username) === normalizeFollowName(activeProfile.username);
    if (target.friendListPrivate && !isOwn) {
      window.alert(copy.common.privateFriendsList);
      return;
    }

    setProfileBackView(currentView);
    setFriendListContext({ profile: target, kind });
    setFriendListUsers([]);
    setFriendListLoading(true);
    setView("amistades");
    try {
      const users = await readProfileFriendList(target, kind);
      setFriendListUsers(users);
    } catch (error) {
      window.alert(error instanceof Error ? error.message : "No se pudo cargar la lista.");
      setFriendListUsers([]);
    } finally {
      setFriendListLoading(false);
    }
  };

  const shareProfile = async (targetProfile: UserProfile) => {
    const url = profileShareUrl(targetProfile.username);
    const title = `Perfil de ${targetProfile.alias || targetProfile.username} en Salseo`;
    try {
      if (navigator.share) {
        await navigator.share({ title, url });
      } else {
        await navigator.clipboard.writeText(url);
        window.alert("Enlace del perfil copiado.");
      }
    } catch {
      try {
        await navigator.clipboard.writeText(url);
        window.alert("Enlace del perfil copiado.");
      } catch {
        window.alert(url);
      }
    }
  };

  const clearSearchHistory = () => {
    if (!window.confirm("¿Seguro que quieres borrar el historial de búsqueda?"))
      return;
    setHistory([]);
    setQuery("");
    setResults([]);
    setUserResults([]);
    setSelectedRecipe(null);
    setSearchError("");
    try {
      Object.keys(window.localStorage).forEach((key) => {
        if (/^salseo:(history|query):v/i.test(key))
          window.localStorage.removeItem(key);
      });
    } catch {
      // Ignorar si el almacenamiento no está disponible.
    }
    setView("buscar");
    window.alert("Historial de búsqueda borrado.");
  };

  const clearLocalSession = (purgeAllSalseoStorage = false) => {
    void signOutFirebase().catch(() => undefined);
    setProfile(emptyProfile(lang));
    setFavoritePosts([]);
    setFavoriteRecipes([]);
    setDiscardedPosts([]);
    setPosts([]);
    setChat([]);
    setDirectChat([]);
    setDirectRecipient(null);
    setFriendListContext(null);
    setFriendListUsers([]);
    setPreparedRecipes([]);
    setResults([]);
    setUserResults([]);
    setSelectedRecipe(null);
    setQuery("");
    setIsAuthed(false);
    setView("buscar");
    if (purgeAllSalseoStorage) {
      try {
        Object.keys(window.localStorage).forEach((key) => {
          if (key.startsWith("salseo:")) window.localStorage.removeItem(key);
        });
      } catch {
        // Ignorar si el almacenamiento local no está disponible.
      }
    }
  };

  const deleteRegisteredAccount = async () => {
    if (isReader) return;
    const firstConfirm = window.confirm(
      "Se eliminará definitivamente la cuenta y todos sus datos asociados: perfil, publicaciones, chats públicos, mensajes directos, notificaciones y seguimientos. Esta acción no se puede deshacer.",
    );
    if (!firstConfirm) return;

    const typed = window.prompt('Escribe ELIMINAR para confirmar el borrado total.');
    if (typed !== "ELIMINAR") return;

    const password = window.prompt(
      "Si entraste con email y contraseña, introduce tu contraseña. Si entraste con Google, deja este campo vacío y pulsa Aceptar.",
    );
    if (password === null) return;

    try {
      await deleteFirebaseAccount(password || undefined);
      window.alert("Tu cuenta y sus datos asociados se han eliminado correctamente.");
      clearLocalSession(true);
    } catch (error) {
      const message = error instanceof Error ? error.message : "No se pudo eliminar la cuenta.";
      if (message.includes("auth/wrong-password") || message.includes("auth/invalid-credential")) {
        window.alert("La contraseña no es correcta. La cuenta no se ha eliminado.");
        return;
      }
      if (message.includes("auth/requires-recent-login")) {
        window.alert("Por seguridad, Firebase exige iniciar sesión de nuevo antes de eliminar la cuenta. Cierra sesión, vuelve a entrar y repite la eliminación.");
        return;
      }
      window.alert(message);
    }
  };

  if (!isAuthed) {
    return (
      <AuthScreen
        lang={lang}
        copy={copy}
        onProfile={(nextProfile) => {
          const clean = normalizeProfile(
            nextProfile,
            nextProfile.preferredLanguage,
          );
          setProfile(clean);
          setLang(clean.preferredLanguage);
        }}
        onEnter={() => {
          setIsAuthed(true);
          setView("buscar");
        }}
      />
    );
  }

  return (
    <div className="app-shell">
      <main className="screen-stage">
        {currentView === "buscar" && (
          <SearchView
            query={query}
            history={history}
            recipes={results}
            userResults={userResults}
            copy={copy}
            favoriteRecipes={favoriteRecipes}
            searching={searching}
            searchError={searchError}
            onQuery={setQuery}
            onSearch={runSearch}
            onFavorite={toggleRecipeFavorite}
            onDiscuss={discussRecipe}
            onOpenRecipe={openRecipe}
            onOpenProfile={openPublicProfile}
          />
        )}

        {currentView === "detalleReceta" && selectedRecipe && (
          <RecipeDetailView
            recipe={selectedRecipe}
            copy={copy}
            isFavorite={favoriteRecipes.includes(selectedRecipe.id)}
            onBack={() => setView("buscar")}
            onFavorite={() => toggleRecipeFavorite(selectedRecipe.id)}
            onDiscuss={
              !isReader ? () => discussRecipe(selectedRecipe) : undefined
            }
          />
        )}

        {currentView === "favoritos" && (
          <FavoritesView
            recipes={preparedRecipes.filter((recipe) =>
              favoriteRecipes.includes(recipe.id),
            )}
            posts={visiblePosts.filter((post) =>
              favoritePosts.includes(post.id),
            )}
            copy={copy}
            favoriteRecipes={favoriteRecipes}
            favoritePosts={favoritePosts}
            onRecipeFavorite={toggleRecipeFavorite}
            onPostFavorite={togglePostFavorite}
            onOpenRecipe={openRecipe}
            onDiscard={discardPost}
          />
        )}

        {currentView === "chats" && (
          <ChatsView
            chat={chat}
            directChat={directChat}
            directRecipient={directRecipient}
            posts={visiblePosts}
            profile={activeProfile}
            copy={copy}
            canChat={!isReader}
            onSend={sendChat}
            onSendImageUrl={sendChatImageUrl}
            favoritePosts={favoritePosts}
            onPostFavorite={togglePostFavorite}
            onOpenProfile={openPublicProfile}
            onClearDirectRecipient={() => setDirectRecipient(null)}
            onDeleteDirectMessage={deleteSentDirectMessage}
            onDiscard={discardPost}
          />
        )}

        {currentView === "perfil" && (
          <ProfileView
            profile={activeProfile}
            copy={copy}
            onEdit={() => setView("editarPerfil")}
            onSettings={() => setView("ajustes")}
            onPreview={() => {
              setViewedProfile(null);
              setProfileBackView("perfil");
              setView("perfilVista");
            }}
            onShare={() => shareProfile(activeProfile)}
            onOpenFriendList={(kind) => openFriendList(activeProfile, kind)}
            onLogout={() => {
              if (window.confirm(copy.settings.logoutWarning))
                clearLocalSession();
            }}
          />
        )}

        {currentView === "perfilVista" && (
          <ProfilePreviewView
            profile={viewedProfile || activeProfile}
            copy={copy}
            isOwnProfile={
              normalizeFollowName((viewedProfile || activeProfile).username) ===
              normalizeFollowName(activeProfile.username)
            }
            isFollowing={(activeProfile.followingUsers || []).includes(
              normalizeFollowName((viewedProfile || activeProfile).username),
            )}
            onFollow={() => toggleFollowAuthor((viewedProfile || activeProfile).username)}
            onMessage={() => startDirectMessage(viewedProfile || activeProfile)}
            onShare={() => shareProfile(viewedProfile || activeProfile)}
            onOpenFriendList={(kind) => openFriendList(viewedProfile || activeProfile, kind)}
            onBack={() => setView(profileBackView)}
          />
        )}

        {currentView === "amistades" && friendListContext && (
          <FriendListView
            context={friendListContext}
            users={friendListUsers}
            loading={friendListLoading}
            copy={copy}
            onBack={() => setView(profileBackView)}
            onOpenProfile={openPublicProfile}
          />
        )}

        {currentView === "editarPerfil" && (
          <EditProfileView
            profile={activeProfile}
            copy={copy}
            isReader={isReader}
            onBack={() => setView("perfil")}
            onProfile={(nextProfile) => {
              const clean = normalizeProfile(nextProfile, lang);
              setProfile(clean);
              void saveCloudProfile(clean).catch((error) =>
                window.alert(error instanceof Error ? error.message : "No se pudo guardar el perfil."),
              );
            }}
          />
        )}

        {currentView === "ajustes" && (
          <SettingsView
            profile={activeProfile}
            copy={copy}
            lang={lang}
            notifications={notificationPrefs}
            cloudNotifications={cloudNotifications}
            onBack={() => setView("perfil")}
            onLang={(nextLang) => {
              setLang(nextLang);
              const clean = { ...activeProfile, preferredLanguage: nextLang };
              setProfile(clean);
              void saveCloudProfile(clean).catch(() => undefined);
            }}
            onNotifications={setNotificationPrefs}
            onProfile={(nextProfile) => {
              const clean = normalizeProfile(nextProfile, lang);
              setProfile(clean);
              void saveCloudProfile(clean).catch((error) =>
                window.alert(error instanceof Error ? error.message : "No se pudo guardar el perfil."),
              );
            }}
            onClearHistory={clearSearchHistory}
            onDeleteAccount={!isReader ? deleteRegisteredAccount : undefined}
            onLogout={() => {
              if (window.confirm(copy.settings.logoutWarning))
                clearLocalSession();
            }}
          />
        )}
      </main>

      {bottomViews.includes(currentView) && (
        <BottomNav active={currentView} copy={copy} onChange={setView} />
      )}
    </div>
  );
}


function GoogleGIcon() {
  return (
    <span className="google-mark" aria-hidden="true">
      <svg className="google-g-icon" viewBox="0 0 18 18" focusable="false">
        <path fill="#4285F4" d="M17.64 9.2045c0-.638-.0573-1.2518-.1636-1.8409H9v3.4818h4.8436c-.2086 1.125-.8427 2.0782-1.796 2.7164v2.2582h2.908c1.7018-1.5673 2.6844-3.874 2.6844-6.6155z" />
        <path fill="#34A853" d="M9 18c2.43 0 4.4673-.805 5.9564-2.18l-2.908-2.2582c-.805.54-1.8368.8591-3.0484.8591-2.344 0-4.3282-1.5832-5.036-3.7109H.9573v2.3318C2.4382 15.9832 5.4818 18 9 18z" />
        <path fill="#FBBC05" d="M3.964 10.71c-.18-.54-.2827-1.1173-.2827-1.71s.1027-1.17.2827-1.71V4.9582H.9573C.3477 6.1732 0 7.5477 0 9s.3477 2.8268.9573 4.0418L3.964 10.71z" />
        <path fill="#EA4335" d="M9 3.5791c1.3214 0 2.5077.4541 3.4405 1.3459l2.5814-2.5814C13.4632.8918 11.4259 0 9 0 5.4818 0 2.4382 2.0168.9573 4.9582L3.964 7.29C4.6718 5.1623 6.656 3.5791 9 3.5791z" />
      </svg>
    </span>
  );
}

function AuthScreen({
  lang,
  copy,
  onProfile,
  onEnter,
}: {
  lang: Language;
  copy: UiCopy;
  onProfile: (profile: UserProfile) => void;
  onEnter: () => void;
}) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [showIntro, setShowIntro] = useState(true);

  useEffect(() => {
    const timer = window.setTimeout(() => setShowIntro(false), 5000);
    return () => window.clearTimeout(timer);
  }, []);

  const reset = (nextMode: "login" | "signup") => {
    setMode(nextMode);
    setUsername("");
    setEmail("");
    setPassword("");
    setError("");
    setNotice("");
  };

  const submitAuth = async (event: FormEvent) => {
    event.preventDefault();
    setError("");
    setNotice("");
    setSubmitting(true);
    try {
      if (mode === "signup") {
        const nextProfile = await createAccount({
          username,
          email,
          password,
          preferredLanguage: lang,
        });
        window.alert("Te hemos enviado un email de verificación.");
        onProfile(nextProfile);
        onEnter();
        return;
      }
      const nextProfile = await verifyCredentials({ email, password });
      onProfile(nextProfile);
      onEnter();
    } catch (authError) {
      setError(
        authError instanceof Error
          ? authError.message
          : "No se pudo completar el acceso.",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const submitGoogleAuth = async () => {
    setError("");
    setNotice("");
    setSubmitting(true);
    try {
      const nextProfile = await continueWithGoogle();
      onProfile(nextProfile);
      onEnter();
    } catch (authError) {
      setError(
        authError instanceof Error
          ? authError.message
          : "No se pudo completar el acceso con Google.",
      );
    } finally {
      setSubmitting(false);
    }
  };

  const handlePasswordReset = async () => {
    setError("");
    setNotice("");
    setSubmitting(true);
    try {
      await requestPasswordReset(email);
      setNotice("Te hemos enviado un email para restablecer tu contraseña.");
    } catch (resetError) {
      setError(
        resetError instanceof Error
          ? resetError.message
          : "No se pudo enviar el email.",
      );
    } finally {
      setSubmitting(false);
    }
  };

  if (showIntro) {
    return (
      <main
        className="auth-screen intro-screen"
        aria-label="Presentación de Salseo"
      >
        <p className="intro-claim">
          Tu nueva red social favorita al alcance de tu mano
        </p>
      </main>
    );
  }


  return (
    <main className="auth-screen">
      <section
        className={
          mode === "signup"
            ? "phone-card auth-phone signup-phone"
            : "phone-card auth-phone"
        }
      >
        {mode === "signup" ? (
          <>
            <header className="plain-header signup-header">
              <button
                className="top-icon"
                type="button"
                onClick={() => reset("login")}
                aria-label="Volver"
              >
                <ArrowLeft size={22} />
              </button>
              <h1>Crear cuenta</h1>
              <span />
            </header>
            <form
              className="auth-form clean-form compact-signup-form"
              onSubmit={submitAuth}
              autoComplete="off"
            >
              <button
                className="google-button full"
                type="button"
                onClick={submitGoogleAuth}
                disabled={submitting}
              >
                <GoogleGIcon />
                Continuar con Google
              </button>
              <div className="auth-separator"><span>o registrarte con email</span></div>
              <input
                value={username}
                onChange={(event) => setUsername(event.target.value)}
                placeholder={copy.auth.username}
                autoComplete="username"
              />
              <input
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder={copy.auth.email}
                type="email"
                inputMode="email"
                autoComplete="email"
              />
              <PasswordField
                value={password}
                onChange={setPassword}
                placeholder={copy.auth.password}
                visible={showPassword}
                onVisible={setShowPassword}
              />
              <p className="policy-inline">
                Al registrarte, aceptas nuestra {" "}
                <a href={privacyPolicyUrl} target="_blank" rel="noreferrer">
                  Política de privacidad
                </a>
              </p>
              {submitting && <p className="form-status">Creando cuenta...</p>}
              {notice && <p className="form-status">{notice}</p>}
              {error && <p className="form-error">{error}</p>}
              <button
                className="primary-button full"
                type="submit"
                disabled={submitting}
              >
                {submitting ? "Creando cuenta..." : "Registrarme"}
              </button>
              <button
                className="link-button register-link"
                type="button"
                onClick={() => reset("login")}
              >
                ¿Ya tienes cuenta? <strong>Iniciar sesión</strong>
              </button>
            </form>
          </>
        ) : (
          <>
            <div className="login-logo-wrap logo-after-intro">
              <img
                className="login-logo"
                src="/salseo-icon-512.png"
                alt="Salseo"
              />
            </div>
            <h1 className="login-title">Salseo</h1>
            <form
              className="auth-form login-form"
              onSubmit={submitAuth}
              autoComplete="off"
            >
              <h2>Iniciar sesión</h2>
              <button
                className="google-button full"
                type="button"
                onClick={submitGoogleAuth}
                disabled={submitting}
              >
                <GoogleGIcon />
                Continuar con Google
              </button>
              <div className="auth-separator"><span>o entrar con email</span></div>
              <input
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder={copy.auth.email}
                type="email"
                inputMode="email"
                autoComplete="email"
              />
              <PasswordField
                value={password}
                onChange={setPassword}
                placeholder={copy.auth.password}
                visible={showPassword}
                onVisible={setShowPassword}
              />
              <button
                className="link-button forgot-link"
                type="button"
                onClick={handlePasswordReset}
                disabled={submitting}
              >
                ¿Olvidaste tu contraseña?
              </button>
              {submitting && <p className="form-status">Conectando...</p>}
              {notice && <p className="form-status">{notice}</p>}
              {error && <p className="form-error">{error}</p>}
              <button
                className="primary-button full"
                type="submit"
                disabled={submitting}
              >
                {submitting ? "Entrando..." : "Iniciar sesión"}
              </button>
              <button
                className="link-button register-link"
                type="button"
                onClick={() => reset("signup")}
              >
                ¿No tienes cuenta? <strong>Regístrate</strong>
              </button>
              <button
                className="link-button muted-link"
                type="button"
                onClick={() => {
                  onProfile(createReaderProfile(lang));
                  onEnter();
                }}
              >
                Entrar como invitado
              </button>
            </form>
          </>
        )}
      </section>
    </main>
  );
}

function PasswordField({
  value,
  onChange,
  placeholder,
  visible,
  onVisible,
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  visible: boolean;
  onVisible: (visible: boolean) => void;
}) {
  return (
    <label className="password-field">
      <input
        type={visible ? "text" : "password"}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        autoComplete="off"
      />
      <button
        type="button"
        onClick={() => onVisible(!visible)}
        aria-label="Mostrar contraseña"
      >
        {visible ? <EyeOff size={17} /> : <Eye size={17} />}
      </button>
    </label>
  );
}

function SearchView({
  query,
  history,
  recipes,
  userResults,
  copy,
  favoriteRecipes,
  searching,
  searchError,
  onQuery,
  onSearch,
  onFavorite,
  onDiscuss,
  onOpenRecipe,
  onOpenProfile,
}: {
  query: string;
  history: string[];
  recipes: RecipeResult[];
  userResults: UserProfile[];
  copy: UiCopy;
  favoriteRecipes: string[];
  searching: boolean;
  searchError: string;
  onQuery: (query: string) => void;
  onSearch: (query?: string) => void;
  onFavorite: (id: string) => void;
  onDiscuss: (recipe: RecipeResult) => void;
  onOpenRecipe: (recipe: RecipeResult) => void;
  onOpenProfile: (username: string) => void;
}) {
  const [tab, setTab] = useState<"recetas" | "videos">("recetas");
  const [menuOpen, setMenuOpen] = useState(false);
  const [inputFocused, setInputFocused] = useState(false);
  const isUserSearch = query.trim().startsWith("@");
  const videos = recipes.filter(
    (recipe) =>
      recipe.sourceLabel.toLowerCase().includes("youtube") || recipe.youtubeId,
  );
  const recipeResults = recipes.filter((recipe) => !videos.includes(recipe));

  useEffect(() => {
    if (!searching && recipes.length > 0 && videos.length > 0 && recipeResults.length === 0) {
      setTab("videos");
    }
  }, [searching, recipes.length, videos.length, recipeResults.length]);

  return (
    <section className="mobile-screen with-bottom-padding">
      <header className="screen-header search-header">
        <h1>{inputFocused || query.trim() ? "" : copy.search.title}</h1>
        <div className="menu-anchor">
          <button
            className="top-icon"
            type="button"
            aria-label="Opciones"
            onClick={() => setMenuOpen((value) => !value)}
          >
            <EllipsisVertical size={21} />
          </button>
          {menuOpen && (
            <div className="overflow-menu">
              <button
                type="button"
                onClick={() => {
                  onQuery("");
                  setMenuOpen(false);
                }}
              >
                Limpiar búsqueda
              </button>
              <button
                type="button"
                onClick={() => {
                  if (query.trim()) onSearch(query);
                  setMenuOpen(false);
                }}
              >
                Recargar
              </button>
            </div>
          )}
        </div>
      </header>
      <form
        className={`mock-search ${inputFocused && !query.trim() ? "search-empty-focused" : ""}`}
        onSubmit={(event) => {
          event.preventDefault();
          onSearch(query);
        }}
      >
        <Search size={18} />
        <input
          value={query}
          onChange={(event) => onQuery(event.target.value)}
          onFocus={() => setInputFocused(true)}
          onBlur={() => setInputFocused(false)}
          placeholder={copy.search.placeholder}
        />
      </form>
      {!isUserSearch && (
        <div className="tabs" role="tablist">
          <button
            className={tab === "recetas" ? "active" : ""}
            onClick={() => setTab("recetas")}
            type="button"
          >
            Recetas{recipeResults.length ? ` (${recipeResults.length})` : ""}
          </button>
          <button
            className={tab === "videos" ? "active" : ""}
            onClick={() => setTab("videos")}
            type="button"
          >
            Vídeos{videos.length ? ` (${videos.length})` : ""}
          </button>
        </div>
      )}
      {query.trim() && !searching && (
        <div className="query-pill-row">
          <span>{query.trim()}</span>
        </div>
      )}

      {searching && (
        <p className="empty-state clean-empty">{copy.search.searching}</p>
      )}
      {searchError && <p className="form-error clean-error">{searchError}</p>}

      {isUserSearch && !searching && userResults.length > 0 && (
        <div className="user-search-list">
          {userResults.map((user) => (
            <UserSearchCard
              key={user.uid || user.username}
              profile={user}
              onOpen={() => onOpenProfile(user.username)}
            />
          ))}
        </div>
      )}

      {!searching &&
        recipes.length === 0 &&
        !query.trim() &&
        history.length > 0 && (
          <div className="history-pills">
            {history.slice(0, 6).map((item) => (
              <button key={item} type="button" onClick={() => onSearch(item)}>
                {item}
              </button>
            ))}
          </div>
        )}

      {!isUserSearch && tab === "recetas" && recipeResults.length > 0 && (
        <div className="recipe-feed">
          {recipeResults.map((recipe) => (
            <RecipeListItem
              key={recipe.id}
              recipe={recipe}
              copy={copy}
              isFavorite={favoriteRecipes.includes(recipe.id)}
              onFavorite={() => onFavorite(recipe.id)}
              onDiscuss={() => onDiscuss(recipe)}
              onOpen={() => onOpenRecipe(recipe)}
            />
          ))}
        </div>
      )}

      {!isUserSearch && tab === "videos" && videos.length > 0 && (
        <section className="youtube-section embedded-videos">
          <div className="youtube-stack">
            {videos.map((recipe) => (
              <YoutubeEmbedCard key={recipe.id} recipe={recipe} />
            ))}
          </div>
        </section>
      )}
      {!searching &&
        !isUserSearch &&
        recipes.length > 0 &&
        tab === "videos" &&
        videos.length === 0 && (
          <p className="empty-state clean-empty">
            No se han encontrado vídeos reproducibles para esta búsqueda.
          </p>
        )}
      {!searching &&
        !isUserSearch &&
        recipes.length > 0 &&
        tab === "recetas" &&
        recipeResults.length === 0 && (
          <p className="empty-state clean-empty">
            No se han encontrado recetas completas para esta búsqueda.
          </p>
        )}
    </section>
  );
}

function UserSearchCard({
  profile,
  onOpen,
}: {
  profile: UserProfile;
  onOpen: () => void;
}) {
  const avatar = profile.avatarUrl || defaultAvatarUrl;
  return (
    <button className="user-result-card" type="button" onClick={onOpen}>
      <img src={avatar} alt="" />
      <span>
        <strong>{profile.alias || profile.username}</strong>
        <small>@{profile.username}</small>
      </span>
      <ChevronRight size={18} />
    </button>
  );
}

function RecipeListItem({
  recipe,
  copy,
  isFavorite,
  onFavorite,
  onDiscuss,
  onOpen,
  compact = false,
  showDetails = false,
}: {
  recipe: RecipeResult;
  copy: UiCopy;
  isFavorite: boolean;
  onFavorite: () => void;
  onDiscuss?: () => void;
  onOpen?: () => void;
  compact?: boolean;
  showDetails?: boolean;
}) {
  const hasDetails = recipe.ingredients.length > 0 || recipe.steps.length > 0;
  return (
    <article className={compact ? "list-card compact" : "list-card"}>
      <div
        className={onOpen ? "list-main clickable" : "list-main"}
        onClick={onOpen}
        role={onOpen ? "button" : undefined}
        tabIndex={onOpen ? 0 : undefined}
        onKeyDown={
          onOpen
            ? (event) => {
                if (event.key === "Enter" || event.key === " ") {
                  event.preventDefault();
                  onOpen();
                }
              }
            : undefined
        }
      >
        <div className="list-text">
          <h2>{recipe.title}</h2>
          <p className="source-line">{recipe.sourceLabel}</p>
          {recipe.summary && <p>{recipe.summary}</p>}
        </div>
        {recipe.imageUrl ? (
          <img src={recipe.imageUrl} alt="" />
        ) : (
          <DishThumb title={recipe.title} />
        )}
      </div>
      {!compact && showDetails && hasDetails && (
        <div className="recipe-inline-details">
          {recipe.ingredients.length > 0 && (
            <div>
              <strong>{copy.recipe.ingredients}</strong>
              <ul>
                {recipe.ingredients.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          )}
          {recipe.steps.length > 0 && (
            <div>
              <strong>{copy.recipe.steps}</strong>
              <ol>
                {recipe.steps.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ol>
            </div>
          )}
        </div>
      )}
      {!compact && !hasDetails && (
        <p className="source-note">{copy.recipe.sourceOnly}</p>
      )}
      <div className="small-actions">
        <button
          className={isFavorite ? "heart active" : "heart"}
          type="button"
          onClick={onFavorite}
        >
          <Heart size={18} fill={isFavorite ? "currentColor" : "none"} />
        </button>
        {onDiscuss && (
          <button type="button" className="text-mini" onClick={onDiscuss}>
            {copy.recipe.discuss}
          </button>
        )}
        {onOpen && (
          <button type="button" className="text-mini" onClick={onOpen}>
            Ver
          </button>
        )}
      </div>
    </article>
  );
}

function YoutubeEmbedCard({ recipe }: { recipe: RecipeResult }) {
  const id = youtubeVideoId(recipe.youtubeId || recipe.sourceUrl);
  const [playing, setPlaying] = useState(false);
  if (!id) return null;

  return (
    <article className="yt-embed-card">
      <div className="yt-embed-frame">
        {playing ? (
          <iframe
            src={youtubeEmbedUrl(id, true)}
            title={recipe.title}
            loading="lazy"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
          />
        ) : (
          <button
            className="yt-poster-button"
            type="button"
            onClick={() => setPlaying(true)}
            aria-label={`Reproducir ${recipe.title}`}
          >
            <YoutubeThumbnail
              id={id}
              title={recipe.title}
              imageUrl={recipe.imageUrl}
            />
            <span className="play-dot large">
              <Play size={24} fill="currentColor" />
            </span>
          </button>
        )}
      </div>
      <div className="yt-embed-meta">
        <strong>{recipe.title}</strong>
        <span>{recipe.author || "YouTube"}</span>
      </div>
    </article>
  );
}

function YoutubeThumbnail({
  id,
  title,
  imageUrl,
}: {
  id: string;
  title: string;
  imageUrl?: string;
}) {
  const candidates = useMemo(
    () =>
      uniqueStrings([
        imageUrl || "",
        keepYoutubeThumbnailQuality(imageUrl || "", id, "hq720"),
        keepYoutubeThumbnailQuality(imageUrl || "", id, "sddefault"),
        youtubeThumbnailUrl(id, "hq720"),
        youtubeThumbnailUrl(id, "sddefault"),
        youtubeThumbnailUrl(id, "hqdefault"),
        youtubeThumbnailUrl(id, "mqdefault"),
        youtubeThumbnailUrl(id, "default"),
      ]),
    [id, imageUrl],
  );
  const [candidateIndex, setCandidateIndex] = useState(0);
  const src = candidates[candidateIndex] || youtubeThumbnailUrl(id, "mqdefault");

  const tryNext = () => {
    setCandidateIndex((index) =>
      index < candidates.length - 1 ? index + 1 : index,
    );
  };

  return (
    <img
      key={src}
      className="yt-thumbnail-img"
      src={src}
      alt={title}
      loading="lazy"
      decoding="async"
      referrerPolicy="no-referrer"
      onError={tryNext}
      onLoad={(event) => {
        const img = event.currentTarget;
        if (
          candidateIndex < candidates.length - 1 &&
          isLikelyYoutubePlaceholder(img.naturalWidth, img.naturalHeight)
        ) {
          tryNext();
        }
      }}
    />
  );
}

function youtubeThumbnailUrl(
  id: string,
  quality = "maxresdefault",
  format: "jpg" | "webp" = "jpg",
) {
  const folder = format === "webp" ? "vi_webp" : "vi";
  return `https://i.ytimg.com/${folder}/${id}/${quality}.${format}`;
}

function keepYoutubeThumbnailQuality(url: string, id: string, quality: string) {
  if (!url) return "";
  if (/ytimg\.com\/(vi|vi_webp)/i.test(url)) {
    return youtubeThumbnailUrl(id, quality, url.includes("vi_webp") ? "webp" : "jpg");
  }
  return url;
}

function isLikelyYoutubePlaceholder(width: number, height: number) {
  return width <= 160 || height <= 120;
}

function uniqueStrings(values: string[]) {
  return [...new Set(values.filter(Boolean))];
}

function youtubeEmbedUrl(id: string, autoplay = false) {
  return `https://www.youtube-nocookie.com/embed/${id}?rel=0&modestbranding=1&playsinline=1${autoplay ? "&autoplay=1" : ""}`;
}

function DishThumb({ title }: { title: string }) {
  return (
    <div className="dish-thumb">
      <span>{title.slice(0, 1).toUpperCase()}</span>
    </div>
  );
}

function RecipeDetailView({
  recipe,
  copy,
  isFavorite,
  onBack,
  onFavorite,
  onDiscuss,
}: {
  recipe: RecipeResult;
  copy: UiCopy;
  isFavorite: boolean;
  onBack: () => void;
  onFavorite: () => void;
  onDiscuss?: () => void;
}) {
  const embedId = youtubeVideoId(recipe.youtubeId || recipe.sourceUrl);
  const [playingVideo, setPlayingVideo] = useState(false);

  return (
    <section className="mobile-screen with-bottom-padding recipe-detail-screen">
      <header className="screen-header centered">
        <button className="top-icon" type="button" onClick={onBack}>
          <ArrowLeft size={22} />
        </button>
        <h1>{recipe.title}</h1>
        <span />
      </header>
      <div className="detail-hero">
        {recipe.imageUrl ? (
          <img src={recipe.imageUrl} alt={recipe.title} />
        ) : (
          <DishThumb title={recipe.title} />
        )}
      </div>
      <div className="detail-head">
        <p className="source-line">{recipe.sourceLabel}</p>
        <h2>{recipe.title}</h2>
        {recipe.summary && <p className="detail-summary">{recipe.summary}</p>}
        <div className="detail-meta">
          {recipe.prepTime && <span>Prep: {recipe.prepTime}</span>}
          {recipe.cookTime && <span>Cocción: {recipe.cookTime}</span>}
          {recipe.yieldText && <span>Raciones: {recipe.yieldText}</span>}
          {!recipe.prepTime && !recipe.cookTime && !recipe.yieldText && (
            <span>{recipe.duration}</span>
          )}
        </div>
      </div>

      <div className="detail-actions">
        <button
          className={isFavorite ? "detail-pill active" : "detail-pill"}
          type="button"
          onClick={onFavorite}
        >
          <Heart size={18} fill={isFavorite ? "currentColor" : "none"} />{" "}
          Favorito
        </button>
        {onDiscuss && (
          <button className="detail-pill" type="button" onClick={onDiscuss}>
            <MessageCircle size={18} /> Comentar
          </button>
        )}
      </div>

      {recipe.ingredients.length > 0 && (
        <section className="detail-section">
          <h3>{copy.recipe.ingredients}</h3>
          <ul>
            {recipe.ingredients.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </section>
      )}
      {recipe.steps.length > 0 && (
        <section className="detail-section">
          <h3>{copy.recipe.steps}</h3>
          <ol>
            {recipe.steps.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ol>
        </section>
      )}
      {recipe.ingredients.length === 0 && recipe.steps.length === 0 && (
        <section className="detail-section">
          <h3>Entrada</h3>
          <p className="detail-summary">
            Salseo no ha podido capturar todavía una receta completa para esta
            entrada.
          </p>
        </section>
      )}

      {embedId && (
        <section className="detail-section">
          <h3>Vídeo</h3>
          <div className="yt-embed-frame detail-video">
            {playingVideo ? (
              <iframe
                src={youtubeEmbedUrl(embedId, true)}
                title={`Vídeo relacionado de ${recipe.title}`}
                loading="lazy"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                referrerPolicy="strict-origin-when-cross-origin"
              />
            ) : (
              <button
                className="yt-poster-button"
                type="button"
                onClick={() => setPlayingVideo(true)}
                aria-label={`Reproducir ${recipe.title}`}
              >
                <YoutubeThumbnail
                  id={embedId}
                  title={recipe.title}
                  imageUrl={recipe.imageUrl}
                />
                <span className="play-dot large">
                  <Play size={24} fill="currentColor" />
                </span>
              </button>
            )}
          </div>
        </section>
      )}
    </section>
  );
}

function FavoritesView({
  recipes,
  posts,
  copy,
  favoriteRecipes,
  favoritePosts,
  onRecipeFavorite,
  onPostFavorite,
  onOpenRecipe,
  onDiscard,
}: {
  recipes: RecipeResult[];
  posts: CommunityPost[];
  copy: UiCopy;
  favoriteRecipes: string[];
  favoritePosts: string[];
  onRecipeFavorite: (id: string) => void;
  onPostFavorite: (id: string) => void;
  onOpenRecipe: (recipe: RecipeResult) => void;
  onDiscard: (postId: string) => void;
}) {
  return (
    <section className="mobile-screen with-bottom-padding">
      <header className="screen-header centered">
        <h1>{copy.favorites.title}</h1>
      </header>
      {recipes.length === 0 && posts.length === 0 ? (
        <p className="empty-state clean-empty">{copy.favorites.empty}</p>
      ) : (
        <div className="recipe-feed">
          {recipes.map((recipe) => (
            <RecipeListItem
              key={recipe.id}
              recipe={recipe}
              copy={copy}
              isFavorite={favoriteRecipes.includes(recipe.id)}
              onFavorite={() => onRecipeFavorite(recipe.id)}
              onOpen={() => onOpenRecipe(recipe)}
              compact
            />
          ))}
          {posts.map((post) => (
            <PostListItem
              key={post.id}
              post={post}
              isFavorite={favoritePosts.includes(post.id)}
              onFavorite={() => onPostFavorite(post.id)}
              onDiscard={() => onDiscard(post.id)}
            />
          ))}
        </div>
      )}
    </section>
  );
}

function ChatsView({
  chat,
  directChat,
  directRecipient,
  posts,
  profile,
  copy,
  canChat,
  onSend,
  onSendImageUrl,
  favoritePosts,
  onPostFavorite,
  onOpenProfile,
  onClearDirectRecipient,
  onDeleteDirectMessage,
  onDiscard,
}: {
  chat: ChatMessage[];
  directChat: ChatMessage[];
  directRecipient: UserProfile | null;
  posts: CommunityPost[];
  profile: UserProfile;
  copy: UiCopy;
  canChat: boolean;
  onSend: (message: ChatMessage, recipient?: UserProfile | null) => void;
  onSendImageUrl: (url: string, recipient?: UserProfile | null) => Promise<void>;
  favoritePosts: string[];
  onPostFavorite: (id: string) => void;
  onOpenProfile: (author: string) => void;
  onClearDirectRecipient: () => void;
  onDeleteDirectMessage: (message: ChatMessage) => void | Promise<void>;
  onDiscard: (postId: string) => void;
}) {
  const [draft, setDraft] = useState("");
  const [attachmentError, setAttachmentError] = useState("");
  const [messageMenuId, setMessageMenuId] = useState<string | null>(null);
  const longPressTimer = useRef<number | null>(null);
  const activeRecipient = directRecipient ? normalizeProfile(directRecipient, profile.preferredLanguage) : null;
  const activeRecipientName = activeRecipient ? normalizeFollowName(activeRecipient.username) : "";
  const directMessages = activeRecipientName
    ? directChat.filter((message) =>
        [message.author, message.recipientUsername]
          .filter(Boolean)
          .map((value) => normalizeFollowName(String(value)))
          .includes(activeRecipientName),
      )
    : [];
  const visibleMessages = activeRecipient ? directMessages : chat;
  const empty = activeRecipient
    ? directMessages.length === 0
    : chat.length === 0 && posts.length === 0;

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!draft.trim() || !canChat) return;
    onSend(
      {
        id: randomId("chat"),
        author: profile.username,
        body: draft.trim(),
        createdAt: nowLabel(),
        mine: true,
      },
      activeRecipient,
    );
    setDraft("");
  };

  const handleChatImageUrl = async () => {
    if (!canChat) return;
    setAttachmentError("");
    const url = window.prompt("Pegar URL de imagen");
    if (!url) return;
    try {
      await onSendImageUrl(url, activeRecipient);
    } catch (error) {
      setAttachmentError(error instanceof Error ? error.message : "No se pudo añadir la imagen.");
    }
  };

  const cancelLongPress = () => {
    if (longPressTimer.current) {
      window.clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const canDeleteMessage = (message: ChatMessage) =>
    Boolean(activeRecipient && message.direct && message.mine);

  const startLongPress = (message: ChatMessage) => {
    if (!canDeleteMessage(message)) return;
    cancelLongPress();
    longPressTimer.current = window.setTimeout(() => {
      setMessageMenuId(message.id);
      longPressTimer.current = null;
    }, 520);
  };

  const openMessageMenu = (message: ChatMessage) => {
    if (!canDeleteMessage(message)) return;
    cancelLongPress();
    setMessageMenuId((current) => (current === message.id ? null : message.id));
  };

  const confirmDeleteMessage = async (message: ChatMessage) => {
    setMessageMenuId(null);
    await onDeleteDirectMessage(message);
  };

  return (
    <section className="mobile-screen with-bottom-padding chat-screen">
      <header className="screen-header chat-title-header">
        <div>
          <h1>Chats</h1>
          {activeRecipient && (
            <span className="chat-subtitle">Mensaje directo con @{activeRecipient.username}</span>
          )}
        </div>
        {activeRecipient && (
          <button className="top-icon" type="button" onClick={onClearDirectRecipient} aria-label="Ver chat general">
            <X size={20} />
          </button>
        )}
      </header>

      {activeRecipient && (
        <div className="direct-recipient-card">
          <img src={activeRecipient.avatarUrl || defaultAvatarUrl} alt="" />
          <div>
            <strong>{activeRecipient.alias || activeRecipient.username}</strong>
            <span>@{activeRecipient.username}</span>
          </div>
        </div>
      )}

      <div className="chat-list modern-chat-list">
        {empty && (
          <div className="chat-empty-hero">
            <div className="chat-empty-icon">
              <MessageCircle size={42} />
              <span />
            </div>
            <strong>Aún no tienes conversaciones</strong>
            <p>
              {activeRecipient
                ? "Envía el primer mensaje directo a este perfil."
                : "Inicia una conversación y empieza a compartir recetas."}
            </p>
          </div>
        )}
        {!activeRecipient && posts.map((post) => (
          <PostListItem
            key={post.id}
            post={post}
            isFavorite={favoritePosts.includes(post.id)}
            onFavorite={() => onPostFavorite(post.id)}
            onOpenProfile={() => onOpenProfile(post.author)}
            onDiscard={() => onDiscard(post.id)}
          />
        ))}
        {visibleMessages.map((message) => {
          const deletable = canDeleteMessage(message);
          return (
            <div
              key={message.id}
              className={message.mine ? "bubble mine" : "bubble"}
              onContextMenu={(event) => {
                if (!deletable) return;
                event.preventDefault();
                openMessageMenu(message);
              }}
              onPointerDown={() => startLongPress(message)}
              onPointerUp={cancelLongPress}
              onPointerLeave={cancelLongPress}
              onPointerCancel={cancelLongPress}
            >
              {deletable && messageMenuId === message.id && (
                <div className="message-action-popover">
                  <button
                    type="button"
                    className="delete-message-action"
                    onClick={() => void confirmDeleteMessage(message)}
                  >
                    {copy.common.deleteMessage}
                  </button>
                </div>
              )}
              <button
                type="button"
                className="author-link"
                onClick={() => onOpenProfile(message.author)}
              >
                @{message.author}
              </button>
              {message.mediaUrl && (
                <img
                  className="chat-media"
                  src={message.mediaUrl}
                  alt="Adjunto"
                />
              )}
              <p>{message.body}</p>
              <span>{message.createdAt}</span>
            </div>
          );
        })}
      </div>

      {!canChat && (
        <p className="reader-chat-note">
          Como invitado solo puedes leer. Regístrate para participar.
        </p>
      )}
      {attachmentError && (
        <p className="form-error clean-error">{attachmentError}</p>
      )}
      {canChat ? (
        <form className="chat-composer modern-composer" onSubmit={submit}>
          <button
            className="attach-button"
            type="button"
            aria-label="Añadir imagen por URL"
            onClick={handleChatImageUrl}
            title="Añadir imagen por URL"
          >
            +
          </button>
          <input
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            placeholder={activeRecipient ? `Mensaje para @${activeRecipient.username}...` : copy.chat.placeholder}
          />
          <button type="submit" aria-label="Enviar mensaje">
            <Send size={18} />
          </button>
        </form>
      ) : (
        <button
          className="primary-button full new-chat-button"
          type="button"
          disabled
        >
          Nuevo chat
        </button>
      )}
    </section>
  );
}

function PostListItem({
  post,
  isFavorite,
  onFavorite,
  onOpenProfile,
  onDiscard,
}: {
  post: CommunityPost;
  isFavorite: boolean;
  onFavorite: () => void;
  onOpenProfile?: () => void;
  onDiscard?: () => void;
}) {
  return (
    <article className="post-item">
      <div>
        <strong>{post.title}</strong>
        <button type="button" className="post-author-link" onClick={onOpenProfile}>
          @{post.handle} · {post.createdAt}
        </button>
      </div>
      {post.body && <p>{post.body}</p>}
      {post.mediaUrl && <img src={post.mediaUrl} alt="" />}
      <button
        className={isFavorite ? "heart active" : "heart"}
        onClick={onFavorite}
        type="button"
      >
        <Heart size={17} fill={isFavorite ? "currentColor" : "none"} />
      </button>
      {onDiscard && (
        <div className="post-actions">
          <button type="button" onClick={onDiscard}>
            Descartar
          </button>
        </div>
      )}
    </article>
  );
}

function ProfileView({
  profile,
  copy,
  onEdit,
  onSettings,
  onPreview,
  onShare,
  onOpenFriendList,
  onLogout,
}: {
  profile: UserProfile;
  copy: UiCopy;
  onEdit: () => void;
  onSettings: () => void;
  onPreview: () => void;
  onShare: () => void;
  onOpenFriendList: (kind: "followers" | "following") => void;
  onLogout: () => void;
}) {
  const avatar = profile.avatarUrl || defaultAvatarUrl;
  const background = profile.backgroundUrl || defaultBackgroundUrl;
  return (
    <section className="mobile-screen with-bottom-padding profile-screen">
      <header className="screen-header centered">
        <span />
        <h1>{copy.common.profile}</h1>
        <button className="top-icon" type="button" onClick={onSettings}>
          <Settings size={20} />
        </button>
      </header>
      <div className="profile-cover-block">
        <img className="profile-cover" src={background} alt="Fondo de perfil" />
        <button className="cover-camera" onClick={onEdit} type="button">
          <Camera size={18} />
        </button>
      </div>
      <div className="avatar-row">
        <div className="avatar-wrap">
          <img className="profile-avatar" src={avatar} alt="Foto de perfil" />
          <button type="button" onClick={onEdit}>
            <Camera size={20} />
          </button>
        </div>
      </div>
      <div className="profile-name">
        <h2>{profile.alias || profile.username || copy.common.guest}</h2>
        <p>
          {copy.profile.memberSince} {formatMemberSince(profile.joinedAt)}
        </p>
      </div>
      <ProfileSocialStats
        profile={profile}
        copy={copy}
        onOpen={onOpenFriendList}
        canOpenList
      />
      <nav className="profile-menu">
        <ProfileRow label={copy.profile.about} onClick={onEdit} />
        <ProfileRow label={copy.common.profilePreview} onClick={onPreview} />
        <ProfileRow label={copy.common.shareMyProfile} onClick={onShare} />
        <ProfileRow label={copy.profile.logout} danger onClick={onLogout} />
      </nav>
    </section>
  );
}

function ProfileSocialStats({
  profile,
  copy,
  onOpen,
  canOpenList,
}: {
  profile: UserProfile;
  copy: UiCopy;
  onOpen: (kind: "followers" | "following") => void;
  canOpenList: boolean;
}) {
  const [counts, setCounts] = useState({ followers: 0, following: 0 });

  useEffect(() => {
    let closed = false;
    readProfileSocialCounts(profile)
      .then((nextCounts) => {
        if (!closed) setCounts(nextCounts);
      })
      .catch(() => {
        if (!closed) {
          setCounts({
            followers: 0,
            following: (profile.followingUsers || []).length,
          });
        }
      });
    return () => {
      closed = true;
    };
  }, [profile.username, profile.followingUsers]);

  const buttonClass = canOpenList
    ? "profile-stat-button"
    : "profile-stat-button disabled";

  return (
    <div className="profile-social-stats" aria-label="Red del perfil">
      <button
        type="button"
        className={buttonClass}
        onClick={() => canOpenList && onOpen("followers")}
      >
        <strong>{counts.followers}</strong>
        <span>{copy.common.followers}</span>
      </button>
      <button
        type="button"
        className={buttonClass}
        onClick={() => canOpenList && onOpen("following")}
      >
        <strong>{counts.following}</strong>
        <span>{copy.common.followingUsers}</span>
      </button>
    </div>
  );
}

function FriendListView({
  context,
  users,
  loading,
  copy,
  onBack,
  onOpenProfile,
}: {
  context: { profile: UserProfile; kind: "followers" | "following" };
  users: UserProfile[];
  loading: boolean;
  copy: UiCopy;
  onBack: () => void;
  onOpenProfile: (username: string) => void;
}) {
  const title = context.kind === "followers"
    ? copy.common.followersTitle
    : copy.common.followingTitle;

  return (
    <section className="mobile-screen friends-screen">
      <header className="screen-header centered">
        <button className="top-icon" type="button" onClick={onBack}>
          <ArrowLeft size={22} />
        </button>
        <h1>{title}</h1>
        <span />
      </header>
      <div className="friend-list-owner">
        <img src={context.profile.avatarUrl || defaultAvatarUrl} alt="" />
        <div>
          <strong>@{context.profile.username}</strong>
          <span>{context.profile.alias || context.profile.username}</span>
        </div>
      </div>
      {loading ? (
        <p className="empty-state clean-empty">{copy.search.searching}</p>
      ) : users.length === 0 ? (
        <p className="empty-state clean-empty">{copy.common.noUsers}</p>
      ) : (
        <div className="friends-list">
          {users.map((user) => (
            <button
              key={user.uid || user.username}
              type="button"
              className="friend-list-row"
              onClick={() => onOpenProfile(user.username)}
            >
              <img src={user.avatarUrl || defaultAvatarUrl} alt="" />
              <span>
                <strong>{user.alias || user.username}</strong>
                <small>@{user.username}</small>
              </span>
              <ChevronRight size={18} />
            </button>
          ))}
        </div>
      )}
    </section>
  );
}

function ProfileRow({
  label,
  value,
  danger,
  onClick,
}: {
  label: string;
  value?: string;
  danger?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      className={danger ? "profile-row danger" : "profile-row"}
      type="button"
      onClick={onClick}
    >
      <span>{label}</span>
      <span>{value}</span>
      <ChevronRight size={18} />
    </button>
  );
}

function ProfilePreviewView({
  profile,
  copy,
  isOwnProfile = true,
  isFollowing = false,
  onFollow,
  onMessage,
  onShare,
  onOpenFriendList,
  onBack,
}: {
  profile: UserProfile;
  copy: UiCopy;
  isOwnProfile?: boolean;
  isFollowing?: boolean;
  onFollow?: () => void;
  onMessage?: () => void;
  onShare?: () => void;
  onOpenFriendList: (kind: "followers" | "following") => void;
  onBack: () => void;
}) {
  const avatar = profile.avatarUrl || defaultAvatarUrl;
  const background = profile.backgroundUrl || defaultBackgroundUrl;
  return (
    <section className="mobile-screen with-bottom-padding profile-screen preview-screen">
      <header className="screen-header centered">
        <button className="top-icon" type="button" onClick={onBack}>
          <ArrowLeft size={22} />
        </button>
        <h1>{copy.common.previewTitle}</h1>
        <span />
      </header>
      <div className="profile-cover-block">
        <img className="profile-cover" src={background} alt="Fondo de perfil" />
      </div>
      <div className="avatar-row">
        <div className="avatar-wrap">
          <img className="profile-avatar" src={avatar} alt="Foto de perfil" />
        </div>
      </div>
      <div className="profile-name">
        <h2>{profile.alias || profile.username || copy.common.guest}</h2>
        <p>
          {copy.profile.memberSince} {formatMemberSince(profile.joinedAt)}
        </p>
      </div>
      <ProfileSocialStats
        profile={profile}
        copy={copy}
        onOpen={onOpenFriendList}
        canOpenList={!profile.friendListPrivate || isOwnProfile}
      />
      <div className="profile-follow-row profile-action-grid">
        {!isOwnProfile && onFollow && (
          <button
            type="button"
            className={isFollowing ? "profile-follow-button active" : "profile-follow-button"}
            onClick={() => {
              if (isFollowing) {
                const username = normalizeFollowName(profile.username);
                if (!window.confirm(`¿Dejar de seguir a '${username}'?`)) return;
              }
              onFollow();
            }}
          >
            {isFollowing ? copy.common.following : copy.common.follow}
          </button>
        )}
        {!isOwnProfile && onMessage && (
          <button
            type="button"
            className="profile-follow-button message"
            onClick={onMessage}
          >
            {copy.common.message}
          </button>
        )}
        {onShare && (
          <button
            type="button"
            className="profile-follow-button share"
            onClick={onShare}
          >
            {copy.common.shareProfile}
          </button>
        )}
      </div>
      <section className="preview-bio-card">
        <h3>{copy.profile.about}</h3>
        <p>{profile.bio?.trim() || copy.profile.noBio}</p>
      </section>
    </section>
  );
}

function EditProfileView({
  profile,
  copy,
  isReader,
  onBack,
  onProfile,
}: {
  profile: UserProfile;
  copy: UiCopy;
  isReader: boolean;
  onBack: () => void;
  onProfile: (profile: UserProfile) => void;
}) {
  const [draft, setDraft] = useState(profile);
  const [error, setError] = useState("");
  const avatar = draft.avatarUrl || defaultAvatarUrl;
  const background = draft.backgroundUrl || defaultBackgroundUrl;

  const updateBio = (value: string) => {
    setError("");
    if (value.length > 2000)
      return setError("La biografía no puede superar 2000 caracteres.");
    if (hasEmoji(value)) return setError("La biografía no admite emoticonos.");
    setDraft({ ...draft, bio: value });
  };

  const handleImage = (field: "avatarUrl" | "backgroundUrl", file?: File) => {
    if (!file || isReader) return;
    setError("");
    if (file.size > MAX_PHOTO_SIZE)
      return setError("La imagen supera el límite de 5 MB.");
    const reader = new FileReader();
    reader.onload = () =>
      setDraft({ ...draft, [field]: String(reader.result) });
    reader.readAsDataURL(file);
  };

  return (
    <section className="mobile-screen edit-screen">
      <header className="screen-header centered">
        <button className="top-icon" onClick={onBack} type="button">
          <X size={22} />
        </button>
        <h1>{copy.common.editProfile}</h1>
        <button
          className="top-icon"
          onClick={() => {
            onProfile(draft);
            onBack();
          }}
          type="button"
        >
          <Check size={22} />
        </button>
      </header>
      {isReader && (
        <p className="form-error clean-error">{copy.settings.readerLocked}</p>
      )}
      <div className="edit-cover">
        <img src={background} alt="" />
        <label>
          <Camera size={19} />
          <input
            type="file"
            accept="image/*"
            disabled={isReader}
            onChange={(event: ChangeEvent<HTMLInputElement>) =>
              handleImage("backgroundUrl", event.target.files?.[0])
            }
          />
        </label>
      </div>
      <div className="edit-avatar">
        <img src={avatar} alt="" />
        <label>
          <Camera size={20} />
          <input
            type="file"
            accept="image/*"
            disabled={isReader}
            onChange={(event: ChangeEvent<HTMLInputElement>) =>
              handleImage("avatarUrl", event.target.files?.[0])
            }
          />
        </label>
      </div>
      <textarea
        className="bio-area"
        value={draft.bio || ""}
        onChange={(event) => updateBio(event.target.value)}
        disabled={isReader}
        placeholder={copy.settings.bioPlaceholder}
        maxLength={2000}
      />
      <span className="counter">{(draft.bio || "").length}/2000</span>
      <div className="edit-actions">
        <label>
          <ImagePlus size={17} /> {copy.common.changeAvatar}
          <input
            type="file"
            accept="image/*"
            disabled={isReader}
            onChange={(event: ChangeEvent<HTMLInputElement>) =>
              handleImage("avatarUrl", event.target.files?.[0])
            }
          />
        </label>
        <label>
          <ImagePlus size={17} /> {copy.common.changeBackground}
          <input
            type="file"
            accept="image/*"
            disabled={isReader}
            onChange={(event: ChangeEvent<HTMLInputElement>) =>
              handleImage("backgroundUrl", event.target.files?.[0])
            }
          />
        </label>
      </div>
      <p className="privacy-small">{copy.settings.privacyNotice}</p>
      {error && <p className="form-error clean-error">{error}</p>}
    </section>
  );
}

function SettingsView({
  profile,
  copy,
  lang,
  notifications,
  cloudNotifications,
  onBack,
  onLang,
  onNotifications,
  onProfile,
  onClearHistory,
  onDeleteAccount,
  onLogout,
}: {
  profile: UserProfile;
  copy: UiCopy;
  lang: Language;
  notifications: NotificationPrefs;
  cloudNotifications: SalseoNotification[];
  onBack: () => void;
  onLang: (lang: Language) => void;
  onNotifications: (prefs: NotificationPrefs) => void;
  onProfile: (profile: UserProfile) => void;
  onClearHistory: () => void;
  onDeleteAccount?: () => void;
  onLogout: () => void;
}) {
  const [updateInfo, setUpdateInfo] = useState<AppUpdateInfo | null>(null);
  const [checkingUpdate, setCheckingUpdate] = useState(false);
  void cloudNotifications;

  const runUpdateCheck = async () => {
    if (checkingUpdate) return;
    setCheckingUpdate(true);
    try {
      const info = await checkForAppUpdate();
      setUpdateInfo(info);
      window.alert(
        info.available
          ? `${copy.settings.updateAvailable}: ${info.latestVersion}`
          : `${copy.settings.upToDate}: ${info.currentVersion}`,
      );
    } catch {
      setUpdateInfo(null);
      window.alert(copy.settings.updateCheckFailed);
    } finally {
      setCheckingUpdate(false);
    }
  };

  return (
    <section className="mobile-screen settings-screen">
      <header className="screen-header centered">
        <button className="top-icon" type="button" onClick={onBack}>
          <ArrowLeft size={22} />
        </button>
        <h1>{copy.settings.title}</h1>
        <span />
      </header>
      <div className="settings-group">
        <p className="settings-title">{copy.settings.general}</p>
        <button className="settings-row-button" type="button">
          <span>{copy.settings.language}</span>
          <span className="row-value">
            {lang === "es" ? "Español" : lang === "en" ? "English" : "Français"}
          </span>
          <ChevronRight size={18} />
        </button>
        <LanguageRow
          label="Español"
          active={lang === "es"}
          onClick={() => onLang("es")}
        />
        <LanguageRow
          label="English"
          active={lang === "en"}
          onClick={() => onLang("en")}
        />
        <LanguageRow
          label="Français"
          active={lang === "fr"}
          onClick={() => onLang("fr")}
        />
        <a
          className="settings-row-button external-link-row"
          href={privacyPolicyUrl}
          target="_blank"
          rel="noreferrer"
        >
          <span>{copy.settings.privacyPolicy}</span>
          <Link2 size={17} />
        </a>
      </div>
      <div className="settings-group flat">
        <p className="settings-title">{copy.settings.preferences}</p>
        <ToggleRow
          label={copy.settings.notifications}
          checked={normalizeNotificationPrefs(notifications).enabled}
          onClick={async () => {
            const current = normalizeNotificationPrefs(notifications);
            if (current.enabled) {
              onNotifications({ ...current, enabled: false });
              return;
            }
            const allowed = await requestSalseoNotificationPermission();
            onNotifications({ ...current, enabled: allowed });
            if (!allowed) {
              window.alert(
                copy.settings.notificationPermissionDenied,
              );
            }
          }}
        />
        <div className="notification-choice-list">
          <ToggleRow
            label={copy.settings.notificationLabels.chat}
            checked={normalizeNotificationPrefs(notifications).chat}
            disabled={!normalizeNotificationPrefs(notifications).enabled}
            onClick={() => {
              const current = normalizeNotificationPrefs(notifications);
              onNotifications({ ...current, chat: !current.chat });
            }}
          />
          <ToggleRow
            label={copy.settings.notificationLabels.follow}
            checked={normalizeNotificationPrefs(notifications).follow}
            disabled={!normalizeNotificationPrefs(notifications).enabled}
            onClick={() => {
              const current = normalizeNotificationPrefs(notifications);
              onNotifications({ ...current, follow: !current.follow });
            }}
          />
          <ToggleRow
            label={copy.settings.notificationLabels.post}
            checked={normalizeNotificationPrefs(notifications).post}
            disabled={!normalizeNotificationPrefs(notifications).enabled}
            onClick={() => {
              const current = normalizeNotificationPrefs(notifications);
              onNotifications({ ...current, post: !current.post });
            }}
          />
          <ToggleRow
            label={copy.settings.notificationLabels.favorite}
            checked={normalizeNotificationPrefs(notifications).favorite}
            disabled={!normalizeNotificationPrefs(notifications).enabled}
            onClick={() => {
              const current = normalizeNotificationPrefs(notifications);
              onNotifications({ ...current, favorite: !current.favorite });
            }}
          />
        </div>
        <p className="settings-helper notification-helper">
          {copy.settings.notificationHelper}
        </p>
        <ToggleRow
          label={copy.settings.friendListPrivate}
          checked={Boolean(profile.friendListPrivate)}
          onClick={() =>
            onProfile({
              ...profile,
              friendListPrivate: !profile.friendListPrivate,
            })
          }
        />
      </div>
      <div className="settings-group flat">
        <p className="settings-title">{copy.settings.aboutApp}</p>
        <button
          className="settings-row-button"
          type="button"
          onClick={onClearHistory}
        >
          {copy.settings.clearHistory}
          <ChevronRight size={18} />
        </button>
        <button className="settings-row-button" type="button">
          <span>{copy.settings.version}</span>
          <span className="row-value">{APP_VERSION_LABEL}</span>
        </button>
        <button
          className="settings-row-button"
          type="button"
          onClick={runUpdateCheck}
          disabled={checkingUpdate}
        >
          <span>{checkingUpdate ? copy.settings.checkingUpdates : copy.settings.checkUpdates}</span>
          <ChevronRight size={18} />
        </button>
        {updateInfo?.available && updateInfo.assetUrl && (
          <button
            className="settings-update-button"
            type="button"
            onClick={() => window.open(updateInfo.assetUrl, "_blank", "noopener,noreferrer")}
          >
            {copy.settings.updateAvailable}: {updateInfo.latestVersion}
          </button>
        )}
        {onDeleteAccount && (
          <button
            className="settings-row-button danger"
            type="button"
            onClick={onDeleteAccount}
          >
            <span>{copy.settings.deleteAccount}</span>
            <ChevronRight size={18} />
          </button>
        )}
        <button
          className="settings-row-button danger"
          type="button"
          onClick={onLogout}
        >
          {copy.settings.logout}
          <ChevronRight size={18} />
        </button>
      </div>
      <p className="settings-foot">{profile.role}</p>
    </section>
  );
}

function LanguageRow({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      className={active ? "language-option active" : "language-option"}
      onClick={onClick}
      type="button"
    >
      <span>{label}</span>
      {active ? <Check size={20} /> : <ChevronRight size={18} />}
    </button>
  );
}

function ToggleRow({
  label,
  checked,
  disabled,
  onClick,
}: {
  label: string;
  checked: boolean;
  disabled?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      className="toggle-row"
      onClick={onClick}
      disabled={disabled}
      type="button"
    >
      <span>{label}</span>
      <span className={checked ? "switch on" : "switch"}>
        <i />
      </span>
    </button>
  );
}

function BottomNav({
  active,
  copy,
  onChange,
}: {
  active: NavView;
  copy: UiCopy;
  onChange: (view: NavView) => void;
}) {
  const items: Array<{ view: NavView; icon: typeof Home }> = [
    { view: "buscar", icon: Home },
    { view: "favoritos", icon: Heart },
    { view: "chats", icon: MessageCircle },
    { view: "perfil", icon: UserRound },
  ];
  return (
    <nav className="bottom-nav">
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <button
            key={item.view}
            className={active === item.view ? "active" : ""}
            type="button"
            onClick={() => onChange(item.view)}
          >
            <Icon size={21} />
            <span>{copy.nav[item.view]}</span>
          </button>
        );
      })}
    </nav>
  );
}


function normalizeImageUrl(value: string) {
  const clean = value.trim();
  if (!clean) return "";
  try {
    const url = new URL(clean);
    if (url.protocol !== "https:" && url.protocol !== "http:") return "";
    return url.toString();
  } catch {
    return "";
  }
}

function hasInternalContent(recipe: RecipeResult) {
  return Boolean(
    recipe.youtubeId ||
    recipe.ingredients.length > 0 ||
    recipe.steps.length > 0,
  );
}
function toggleId(items: string[], id: string) {
  return items.includes(id)
    ? items.filter((item) => item !== id)
    : [...items, id];
}
function mergeById<T extends { id: string }>(items: T[], item: T) {
  return items.some((current) => current.id === item.id)
    ? items
    : [item, ...items];
}
function mergeManyById<T extends { id: string }>(items: T[], nextItems: T[]) {
  return nextItems.reduce((current, item) => mergeById(current, item), items);
}
function normalize(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .trim();
}
function normalizeProfile(profile: UserProfile, lang: Language): UserProfile {
  return {
    ...emptyProfile(lang),
    ...profile,
    preferredLanguage: profile.preferredLanguage || lang,
    alias: profile.alias || profile.username || "Invitado",
    avatarUrl: profile.avatarUrl || "",
    backgroundUrl: profile.backgroundUrl || "",
    bio: profile.bio || "",
    followingUsers: Array.isArray(profile.followingUsers)
      ? uniqueStrings(profile.followingUsers.map(normalizeFollowName))
      : [],
    friendListPrivate: Boolean(profile.friendListPrivate),
  };
}

function notifyIfAllowed(
  prefs: NotificationPrefs,
  type: SalseoNotification["type"],
  title: string,
  body: string,
) {
  const cleanPrefs = normalizeNotificationPrefs(prefs);
  if (!cleanPrefs.enabled || !cleanPrefs[type]) return;
  showSalseoNotification(title, body);
}
function normalizeNotificationPrefs(prefs: NotificationPrefs): NotificationPrefs {
  return {
    ...defaultNotificationPrefs,
    ...prefs,
  };
}
function profileShareUrl(username: string) {
  const url = new URL(window.location.href);
  url.searchParams.set("perfil", normalizeFollowName(username));
  url.hash = "";
  return url.toString();
}
function normalizeFollowName(value: string) {
  return normalize(value).replace(/[^a-z0-9._-]/g, "");
}
function sortedAuthors(authors: string[]) {
  return [...new Set(authors.filter(Boolean))].sort((a, b) =>
    a.localeCompare(b),
  );
}
function nowLabel() {
  return new Date().toLocaleString("es-ES", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}
function formatMemberSince(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? value
    : date.toLocaleDateString("es-ES", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
      });
}
function hasEmoji(value: string) {
  return /[\p{Extended_Pictographic}\uFE0F]/u.test(value);
}
function youtubeVideoId(value: string) {
  const trimmed = value.trim();
  if (!trimmed || trimmed.startsWith("search:")) return "";
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) return trimmed;
  try {
    const url = new URL(trimmed);
    if (url.hostname.includes("youtu.be"))
      return url.pathname.split("/").filter(Boolean)[0]?.slice(0, 11) || "";
    const watchId = url.searchParams.get("v");
    if (watchId) return watchId.slice(0, 11);
    const parts = url.pathname.split("/").filter(Boolean);
    const marker = parts.findIndex((part) =>
      ["embed", "shorts", "live"].includes(part),
    );
    return marker >= 0 ? parts[marker + 1]?.slice(0, 11) || "" : "";
  } catch {
    return "";
  }
}

export default App;
