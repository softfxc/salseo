package com.salseo.soft;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
