import { getApp, getApps, initializeApp, type FirebaseApp } from "firebase/app";
import {
  createUserWithEmailAndPassword,
  getAuth,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
  type Auth,
} from "firebase/auth";
import {
  collection,
  doc,
  getDoc,
  getFirestore,
  limit,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  type Firestore,
} from "firebase/firestore";
import type { ChatMessage, CommunityPost, Language, UserProfile } from "./types";

export type FirebaseConfig = {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket?: string;
  messagingSenderId?: string;
  appId: string;
};

type FirebaseBundle = {
  app: FirebaseApp;
  auth: Auth;
  db: Firestore;
};

const CONFIG_URL = "/firebase-config.json";
let bundlePromise: Promise<FirebaseBundle> | null = null;

declare global {
  interface Window {
    SALSEO_FIREBASE_CONFIG?: FirebaseConfig;
  }
}

export async function firebaseReady() {
  try {
    await getFirebase();
    return true;
  } catch {
    return false;
  }
}

export async function registerFirebaseAccount(input: {
  username: string;
  email: string;
  password: string;
  pinHash: string;
  pinSalt: string;
  preferredLanguage: Language;
}): Promise<UserProfile> {
  const firebase = await getFirebase();
  const username = normalizeUsername(input.username);
  const email = normalizeEmail(input.email);
  const credentials = await createUserWithEmailAndPassword(
    firebase.auth,
    email,
    input.password,
  );
  const user = credentials.user;
  const profile = profileFromUsername(username, input.preferredLanguage);

  await updateProfile(user, {
    displayName: profile.alias || profile.username,
  });

  await setDoc(
    doc(firebase.db, "users", user.uid),
    {
      ...profile,
      uid: user.uid,
      email,
      updatedAtMs: Date.now(),
    },
    { merge: true },
  );

  await setDoc(
    doc(firebase.db, "privateUsers", user.uid),
    {
      pinHash: input.pinHash,
      pinSalt: input.pinSalt,
      updatedAtMs: Date.now(),
    },
    { merge: true },
  );

  return profile;
}

export async function signInFirebaseAccount(input: {
  email: string;
  password: string;
}): Promise<string> {
  const firebase = await getFirebase();
  const email = normalizeEmail(input.email);
  const credentials = await signInWithEmailAndPassword(
    firebase.auth,
    email,
    input.password,
  );
  return credentials.user.uid;
}

export async function readPrivatePin(uid: string): Promise<{
  pinHash: string;
  pinSalt: string;
}> {
  const firebase = await getFirebase();
  const snapshot = await getDoc(doc(firebase.db, "privateUsers", uid));
  if (!snapshot.exists()) throw new Error("No se encontró la verificación PIN de esta cuenta.");
  const data = snapshot.data();
  return {
    pinHash: String(data.pinHash || ""),
    pinSalt: String(data.pinSalt || ""),
  };
}

export async function readCurrentProfile(uid: string): Promise<UserProfile> {
  const firebase = await getFirebase();
  const snapshot = await getDoc(doc(firebase.db, "users", uid));
  if (!snapshot.exists()) {
    const authUser = firebase.auth.currentUser;
    return profileFromUsername(
      authUser?.displayName || authUser?.email || "usuario",
      "es",
    );
  }
  return userProfileFromData(snapshot.data());
}

export async function saveCloudProfile(profile: UserProfile) {
  const firebase = await getFirebase();
  const uid = firebase.auth.currentUser?.uid;
  if (!uid) throw new Error("Inicia sesión para guardar el perfil.");
  await setDoc(
    doc(firebase.db, "users", uid),
    {
      ...profile,
      uid,
      updatedAtMs: Date.now(),
    },
    { merge: true },
  );
}

export async function publishChatMessage(message: ChatMessage) {
  const firebase = await getFirebase();
  const uid = firebase.auth.currentUser?.uid;
  if (!uid) throw new Error("Inicia sesión para chatear.");
  await setDoc(
    doc(firebase.db, "publicChat", message.id),
    {
      id: message.id,
      author: message.author,
      authorUid: uid,
      body: message.body,
      mediaUrl: message.mediaUrl || "",
      createdAt: message.createdAt,
      createdAtMs: Date.now(),
    },
    { merge: false },
  );
}

export async function publishCommunityPost(post: CommunityPost) {
  const firebase = await getFirebase();
  const uid = firebase.auth.currentUser?.uid;
  if (!uid) throw new Error("Inicia sesión para publicar.");
  await setDoc(
    doc(firebase.db, "posts", post.id),
    {
      ...post,
      authorUid: uid,
      createdAtMs: Date.now(),
    },
    { merge: false },
  );
}


export function subscribeToCloudChat(
  onChange: (items: ChatMessage[]) => void,
  onNewRemoteMessage?: (message: ChatMessage) => void,
) {
  let previousIds = new Set<string>();
  let firstSnapshot = true;
  let closed = false;
  let unsubscribe: () => void = () => {};

  getFirebase()
    .then((firebase) => {
      if (closed) return;
      const currentUid = firebase.auth.currentUser?.uid || "";
      const chatQuery = query(
        collection(firebase.db, "publicChat"),
        orderBy("createdAtMs", "asc"),
        limit(200),
      );
      unsubscribe = onSnapshot(chatQuery, (snapshot) => {
        const messages: ChatMessage[] = snapshot.docs.map((document) =>
          chatMessageFromData(document.id, document.data(), currentUid),
        );
        onChange(messages);
        if (!firstSnapshot && onNewRemoteMessage) {
          messages.forEach((message) => {
            if (!previousIds.has(message.id) && !message.mine)
              onNewRemoteMessage(message);
          });
        }
        previousIds = new Set(messages.map((message) => message.id));
        firstSnapshot = false;
      });
    })
    .catch((error) => {
      console.warn("Salseo Firebase chat no disponible", error);
    });

  return () => {
    closed = true;
    unsubscribe();
  };
}

export function subscribeToCloudPosts(onChange: (items: CommunityPost[]) => void) {
  let closed = false;
  let unsubscribe: () => void = () => {};

  getFirebase()
    .then((firebase) => {
      if (closed) return;
      const postsQuery = query(
        collection(firebase.db, "posts"),
        orderBy("createdAtMs", "desc"),
        limit(100),
      );
      unsubscribe = onSnapshot(postsQuery, (snapshot) => {
        onChange(
          snapshot.docs.map((document) =>
            communityPostFromData(document.id, document.data()),
          ),
        );
      });
    })
    .catch((error) => {
      console.warn("Salseo Firebase posts no disponible", error);
    });

  return () => {
    closed = true;
    unsubscribe();
  };
}

export async function signOutFirebase() {
  const firebase = await getFirebase();
  await signOut(firebase.auth);
}

async function getFirebase(): Promise<FirebaseBundle> {
  if (!bundlePromise) bundlePromise = createFirebaseBundle();
  return bundlePromise;
}

async function createFirebaseBundle(): Promise<FirebaseBundle> {
  const config = await loadFirebaseConfig();
  if (!isConfigComplete(config)) {
    throw new Error(
      "Firebase no está configurado. Completa public/firebase-config.json con los datos del proyecto Salseo.",
    );
  }

  const readyConfig = config as FirebaseConfig;
  const app = getApps().length ? getApp() : initializeApp(readyConfig);
  const auth = getAuth(app);
  const db = getFirestore(app);
  return { app, auth, db };
}

async function loadFirebaseConfig(): Promise<FirebaseConfig | null> {
  const windowConfig = window.SALSEO_FIREBASE_CONFIG;
  if (windowConfig && isConfigComplete(windowConfig)) return windowConfig;

  const envConfig = {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "",
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "",
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "",
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "",
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "",
    appId: import.meta.env.VITE_FIREBASE_APP_ID || "",
  };
  if (isConfigComplete(envConfig)) return envConfig;

  try {
    const response = await fetch(CONFIG_URL, { cache: "no-store" });
    if (!response.ok) return null;
    const json = (await response.json()) as FirebaseConfig;
    return json;
  } catch {
    return null;
  }
}

function isConfigComplete(config: FirebaseConfig | null | undefined) {
  return Boolean(
    config?.apiKey?.trim() &&
      config?.authDomain?.trim() &&
      config?.projectId?.trim() &&
      config?.appId?.trim(),
  );
}

function chatMessageFromData(id: string, data: Record<string, unknown>, currentUid: string): ChatMessage {
  return {
    id: String(data.id || id),
    author: String(data.author || "usuario"),
    body: String(data.body || ""),
    mediaUrl: data.mediaUrl ? String(data.mediaUrl) : undefined,
    createdAt: String(data.createdAt || ""),
    mine: Boolean(currentUid && data.authorUid === currentUid),
  };
}

function communityPostFromData(id: string, data: Record<string, unknown>): CommunityPost {
  return {
    id: String(data.id || id),
    author: String(data.author || "usuario"),
    handle: String(data.handle || data.author || "usuario"),
    title: String(data.title || "Comentario"),
    body: String(data.body || ""),
    tags: Array.isArray(data.tags) ? data.tags.map(String) : [],
    mediaUrl: data.mediaUrl ? String(data.mediaUrl) : undefined,
    linkUrl: data.linkUrl ? String(data.linkUrl) : undefined,
    createdAt: String(data.createdAt || ""),
    likes: Number(data.likes || 0),
    replies: Number(data.replies || 0),
    status: data.status === "hidden" || data.status === "pending" ? data.status : "approved",
  };
}

function userProfileFromData(data: Record<string, unknown>): UserProfile {
  return {
    username: String(data.username || "usuario"),
    alias: String(data.alias || data.username || "usuario"),
    role: data.role === "Creador / Moderador" ? "Creador / Moderador" : "Usuario registrado",
    joinedAt: String(data.joinedAt || new Date().toISOString().slice(0, 10)),
    preferredLanguage: data.preferredLanguage === "en" || data.preferredLanguage === "fr" ? data.preferredLanguage : "es",
    avatarUrl: data.avatarUrl ? String(data.avatarUrl) : "",
    backgroundUrl: data.backgroundUrl ? String(data.backgroundUrl) : "",
    bio: data.bio ? String(data.bio) : "",
  };
}

function profileFromUsername(username: string, preferredLanguage: Language): UserProfile {
  const clean = normalizeUsername(username);
  return {
    username: clean,
    alias: clean,
    role: "Usuario registrado",
    joinedAt: new Date().toISOString().slice(0, 10),
    preferredLanguage,
    avatarUrl: "",
    backgroundUrl: "",
    bio: "",
  };
}

function normalizeUsername(value: string) {
  return value.trim().toLowerCase();
}

function normalizeEmail(value: string) {
  return value.trim().toLowerCase();
}
