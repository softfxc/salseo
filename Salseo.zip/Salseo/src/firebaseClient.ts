import { getApp, getApps, initializeApp, type FirebaseApp } from "firebase/app";
import {
  createUserWithEmailAndPassword,
  deleteUser,
  EmailAuthProvider,
  getAuth,
  reauthenticateWithCredential,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
  type Auth,
} from "firebase/auth";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  getFirestore,
  limit,
  onSnapshot,
  orderBy,
  query,
  setDoc,
  where,
  writeBatch,
  type Firestore,
} from "firebase/firestore";
import type {
  ChatMessage,
  CommunityPost,
  Language,
  SalseoNotification,
  UserProfile,
} from "./types";

export type FirebaseConfig = {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket?: string;
  messagingSenderId?: string;
  appId: string;
};

type FirebaseBundle = {
  app: FirebaseApp;
  auth: Auth;
  db: Firestore;
};

const CONFIG_URL = "/firebase-config.json";
let bundlePromise: Promise<FirebaseBundle> | null = null;

declare global {
  interface Window {
    SALSEO_FIREBASE_CONFIG?: FirebaseConfig;
  }
}

export async function firebaseReady() {
  try {
    await getFirebase();
    return true;
  } catch {
    return false;
  }
}

export async function registerFirebaseAccount(input: {
  username: string;
  email: string;
  password: string;
  preferredLanguage: Language;
}): Promise<UserProfile> {
  const firebase = await getFirebase();
  const username = normalizeUsername(input.username);
  const email = normalizeEmail(input.email);

  const usernameQuery = query(
    collection(firebase.db, "users"),
    where("username", "==", username),
    limit(1),
  );
  const existingUsername = await getDocs(usernameQuery);
  if (!existingUsername.empty) throw new Error("Ese usuario ya está en uso.");

  const credentials = await createUserWithEmailAndPassword(
    firebase.auth,
    email,
    input.password,
  );
  const user = credentials.user;
  const profile = {
    ...profileFromUsername(username, input.preferredLanguage),
    uid: user.uid,
  };

  try {
    await updateProfile(user, {
      displayName: profile.alias || profile.username,
    });

    await setDoc(
      doc(firebase.db, "users", user.uid),
      {
        ...profile,
        uid: user.uid,
        email,
        updatedAtMs: Date.now(),
      },
      { merge: false },
    );
  } catch (error) {
    await deleteUser(user).catch(() => undefined);
    throw error;
  }

  return profile;
}

export async function signInFirebaseAccount(input: {
  email: string;
  password: string;
}): Promise<string> {
  const firebase = await getFirebase();
  const email = normalizeEmail(input.email);
  const credentials = await signInWithEmailAndPassword(
    firebase.auth,
    email,
    input.password,
  );
  return credentials.user.uid;
}

export async function readCurrentProfile(uid: string): Promise<UserProfile> {
  const firebase = await getFirebase();
  const snapshot = await getDoc(doc(firebase.db, "users", uid));
  if (!snapshot.exists()) throw new Error("Perfil no encontrado.");
  return userProfileFromData(snapshot.data());
}

export async function saveCloudProfile(profile: UserProfile) {
  const firebase = await getFirebase();
  const uid = firebase.auth.currentUser?.uid;
  if (!uid) throw new Error("Inicia sesión para guardar el perfil.");
  await setDoc(
    doc(firebase.db, "users", uid),
    {
      ...profile,
      uid,
      updatedAtMs: Date.now(),
    },
    { merge: true },
  );
}

export async function publishChatMessage(message: ChatMessage) {
  const firebase = await getFirebase();
  const uid = firebase.auth.currentUser?.uid;
  if (!uid) throw new Error("Inicia sesión para chatear.");
  await setDoc(
    doc(firebase.db, "publicChat", message.id),
    {
      id: message.id,
      author: message.author,
      authorUid: uid,
      body: message.body,
      mediaUrl: message.mediaUrl || "",
      createdAt: message.createdAt,
      createdAtMs: Date.now(),
    },
    { merge: false },
  );
}

export async function publishCommunityPost(post: CommunityPost) {
  const firebase = await getFirebase();
  const uid = firebase.auth.currentUser?.uid;
  if (!uid) throw new Error("Inicia sesión para publicar.");
  await setDoc(
    doc(firebase.db, "posts", post.id),
    {
      ...post,
      authorUid: uid,
      createdAtMs: Date.now(),
    },
    { merge: false },
  );
}

export function subscribeToCloudChat(
  onChange: (items: ChatMessage[]) => void,
  onNewRemoteMessage?: (message: ChatMessage) => void,
) {
  let previousIds = new Set<string>();
  let firstSnapshot = true;
  let closed = false;
  let unsubscribe: () => void = () => {};

  getFirebase()
    .then((firebase) => {
      if (closed) return;
      const currentUid = firebase.auth.currentUser?.uid || "";
      const chatQuery = query(
        collection(firebase.db, "publicChat"),
        orderBy("createdAtMs", "asc"),
        limit(200),
      );
      unsubscribe = onSnapshot(chatQuery, (snapshot) => {
        const messages: ChatMessage[] = snapshot.docs.map((document) =>
          chatMessageFromData(document.id, document.data(), currentUid),
        );
        onChange(messages);
        if (!firstSnapshot && onNewRemoteMessage) {
          messages.forEach((message) => {
            if (!previousIds.has(message.id) && !message.mine)
              onNewRemoteMessage(message);
          });
        }
        previousIds = new Set(messages.map((message) => message.id));
        firstSnapshot = false;
      });
    })
    .catch((error) => {
      console.warn("Salseo Firebase chat no disponible", error);
    });

  return () => {
    closed = true;
    unsubscribe();
  };
}

export function subscribeToCloudPosts(
  onChange: (items: CommunityPost[]) => void,
) {
  let closed = false;
  let unsubscribe: () => void = () => {};

  getFirebase()
    .then((firebase) => {
      if (closed) return;
      const postsQuery = query(
        collection(firebase.db, "posts"),
        orderBy("createdAtMs", "desc"),
        limit(100),
      );
      unsubscribe = onSnapshot(postsQuery, (snapshot) => {
        onChange(
          snapshot.docs.map((document) =>
            communityPostFromData(document.id, document.data()),
          ),
        );
      });
    })
    .catch((error) => {
      console.warn("Salseo Firebase posts no disponible", error);
    });

  return () => {
    closed = true;
    unsubscribe();
  };
}

export async function readUserProfileByUsername(
  username: string,
): Promise<UserProfile | null> {
  const firebase = await getFirebase();
  const clean = normalizeUsername(username);
  if (!clean) return null;
  const usersQuery = query(
    collection(firebase.db, "users"),
    where("username", "==", clean),
    limit(1),
  );
  const snapshot = await getDocs(usersQuery);
  const first = snapshot.docs[0];
  if (!first) return null;
  return userProfileFromData({ ...first.data(), uid: first.id });
}

export async function notifyUserByUsername(
  targetUsername: string,
  notification: Omit<
    SalseoNotification,
    "id" | "targetUid" | "targetUsername" | "createdAt" | "createdAtMs"
  >,
) {
  const target = await readUserProfileByUsername(targetUsername);
  if (!target?.uid) return;
  await createNotification(target.uid, target.username, notification);
}

export async function notifyFollowersOfProfile(
  actorProfile: UserProfile,
  notification: Omit<
    SalseoNotification,
    | "id"
    | "targetUid"
    | "targetUsername"
    | "createdAt"
    | "createdAtMs"
    | "actor"
    | "actorUsername"
  >,
  options: { mutualOnly?: boolean } = {},
) {
  const firebase = await getFirebase();
  const actorUsername = normalizeUsername(actorProfile.username);
  if (!actorUsername) return;

  const followersQuery = query(
    collection(firebase.db, "users"),
    where("followingUsers", "array-contains", actorUsername),
    limit(200),
  );
  const snapshot = await getDocs(followersQuery);
  const actorFollowing = new Set(
    (actorProfile.followingUsers || []).map(normalizeUsername).filter(Boolean),
  );

  const recipients = snapshot.docs
    .map((document) =>
      userProfileFromData({ ...document.data(), uid: document.id }),
    )
    .filter((target) => {
      const targetUsername = normalizeUsername(target.username);
      if (!target.uid || !targetUsername || targetUsername === actorUsername)
        return false;
      if (options.mutualOnly && !actorFollowing.has(targetUsername))
        return false;
      return true;
    });

  await Promise.all(
    recipients.map((target) =>
      createNotification(target.uid || "", target.username, {
        ...notification,
        actor: actorProfile.alias || actorProfile.username,
        actorUsername,
      }),
    ),
  );
}

export function subscribeToUserNotifications(
  onChange: (items: SalseoNotification[]) => void,
  onNewNotification?: (notification: SalseoNotification) => void,
) {
  let previousIds = new Set<string>();
  let firstSnapshot = true;
  let closed = false;
  let unsubscribe: () => void = () => {};

  getFirebase()
    .then((firebase) => {
      if (closed) return;
      const uid = firebase.auth.currentUser?.uid;
      if (!uid) return;
      const notificationsQuery = query(
        collection(firebase.db, "notifications"),
        where("targetUid", "==", uid),
        limit(60),
      );
      unsubscribe = onSnapshot(notificationsQuery, (snapshot) => {
        const items = snapshot.docs
          .map((document) =>
            salseoNotificationFromData(document.id, document.data()),
          )
          .sort((a, b) => b.createdAtMs - a.createdAtMs);
        onChange(items);
        if (!firstSnapshot && onNewNotification) {
          items.forEach((item) => {
            if (!previousIds.has(item.id)) onNewNotification(item);
          });
        }
        previousIds = new Set(items.map((item) => item.id));
        firstSnapshot = false;
      });
    })
    .catch((error) => {
      console.warn("Salseo Firebase notifications no disponible", error);
    });

  return () => {
    closed = true;
    unsubscribe();
  };
}

async function createNotification(
  targetUid: string,
  targetUsername: string,
  notification: Omit<
    SalseoNotification,
    "id" | "targetUid" | "targetUsername" | "createdAt" | "createdAtMs"
  >,
) {
  if (!targetUid) return;
  const firebase = await getFirebase();
  const actorUid = firebase.auth.currentUser?.uid || "";
  const createdAtMs = Date.now();
  await addDoc(collection(firebase.db, "notifications"), {
    targetUid,
    targetUsername: normalizeUsername(targetUsername),
    type: notification.type,
    title: notification.title,
    body: notification.body,
    actor: notification.actor,
    actorUsername: normalizeUsername(notification.actorUsername),
    actorUid,
    entityId: notification.entityId || "",
    createdAt: new Date(createdAtMs).toLocaleString("es-ES", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    }),
    createdAtMs,
  });
}

function salseoNotificationFromData(
  id: string,
  data: Record<string, unknown>,
): SalseoNotification {
  return {
    id,
    targetUid: String(data.targetUid || ""),
    targetUsername: String(data.targetUsername || ""),
    type:
      data.type === "follow" ||
      data.type === "chat" ||
      data.type === "post" ||
      data.type === "favorite"
        ? data.type
        : "post",
    title: String(data.title || "Salseo"),
    body: String(data.body || "Nueva actividad"),
    actor: String(data.actor || "usuario"),
    actorUsername: String(data.actorUsername || data.actor || "usuario"),
    entityId: data.entityId ? String(data.entityId) : undefined,
    createdAt: String(data.createdAt || ""),
    createdAtMs: Number(data.createdAtMs || 0),
  };
}


export async function deleteFirebaseAccount(password?: string) {
  const firebase = await getFirebase();
  const user = firebase.auth.currentUser;
  if (!user) throw new Error("No hay una sesión iniciada.");

  if (user.email && password) {
    const credential = EmailAuthProvider.credential(user.email, password);
    await reauthenticateWithCredential(user, credential);
  }

  const uid = user.uid;

  const notificationsQuery = query(
    collection(firebase.db, "notifications"),
    where("targetUid", "==", uid),
    limit(200),
  );
  const notificationsSnapshot = await getDocs(notificationsQuery);
  const batch = writeBatch(firebase.db);
  notificationsSnapshot.docs.forEach((item) => batch.delete(item.ref));
  batch.delete(doc(firebase.db, "users", uid));
  await batch.commit();

  await deleteUser(user);
}

export async function signOutFirebase() {
  const firebase = await getFirebase();
  await signOut(firebase.auth);
}

async function getFirebase(): Promise<FirebaseBundle> {
  if (!bundlePromise) bundlePromise = createFirebaseBundle();
  return bundlePromise;
}

async function createFirebaseBundle(): Promise<FirebaseBundle> {
  const config = await loadFirebaseConfig();
  if (!isConfigComplete(config)) {
    throw new Error(
      "Firebase no está configurado. Completa public/firebase-config.json con los datos del proyecto Salseo.",
    );
  }

  const readyConfig = config as FirebaseConfig;
  const app = getApps().length ? getApp() : initializeApp(readyConfig);
  const auth = getAuth(app);
  const db = getFirestore(app);
  return { app, auth, db };
}

async function loadFirebaseConfig(): Promise<FirebaseConfig | null> {
  const windowConfig = window.SALSEO_FIREBASE_CONFIG;
  if (windowConfig && isConfigComplete(windowConfig)) return windowConfig;

  const envConfig = {
    apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "",
    authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "",
    projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "",
    storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "",
    messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "",
    appId: import.meta.env.VITE_FIREBASE_APP_ID || "",
  };
  if (isConfigComplete(envConfig)) return envConfig;

  try {
    const response = await fetch(CONFIG_URL, { cache: "no-store" });
    if (!response.ok) return null;
    const json = (await response.json()) as FirebaseConfig;
    return json;
  } catch {
    return null;
  }
}

function isConfigComplete(config: FirebaseConfig | null | undefined) {
  return Boolean(
    config?.apiKey?.trim() &&
      config?.authDomain?.trim() &&
      config?.projectId?.trim() &&
      config?.appId?.trim(),
  );
}

function chatMessageFromData(
  id: string,
  data: Record<string, unknown>,
  currentUid: string,
): ChatMessage {
  return {
    id: String(data.id || id),
    author: String(data.author || "usuario"),
    body: String(data.body || ""),
    mediaUrl: data.mediaUrl ? String(data.mediaUrl) : undefined,
    createdAt: String(data.createdAt || ""),
    mine: Boolean(currentUid && data.authorUid === currentUid),
  };
}

function communityPostFromData(
  id: string,
  data: Record<string, unknown>,
): CommunityPost {
  return {
    id: String(data.id || id),
    author: String(data.author || "usuario"),
    handle: String(data.handle || data.author || "usuario"),
    title: String(data.title || "Comentario"),
    body: String(data.body || ""),
    tags: Array.isArray(data.tags) ? data.tags.map(String) : [],
    mediaUrl: data.mediaUrl ? String(data.mediaUrl) : undefined,
    linkUrl: data.linkUrl ? String(data.linkUrl) : undefined,
    createdAt: String(data.createdAt || ""),
    likes: Number(data.likes || 0),
    replies: Number(data.replies || 0),
    status:
      data.status === "hidden" || data.status === "pending"
        ? data.status
        : "approved",
  };
}

function userProfileFromData(data: Record<string, unknown>): UserProfile {
  return {
    uid: data.uid ? String(data.uid) : undefined,
    username: String(data.username || "usuario"),
    alias: String(data.alias || data.username || "usuario"),
    role:
      data.role === "Creador / Moderador"
        ? "Creador / Moderador"
        : "Usuario registrado",
    joinedAt: String(data.joinedAt || new Date().toISOString().slice(0, 10)),
    preferredLanguage:
      data.preferredLanguage === "en" || data.preferredLanguage === "fr"
        ? data.preferredLanguage
        : "es",
    avatarUrl: data.avatarUrl ? String(data.avatarUrl) : "",
    backgroundUrl: data.backgroundUrl ? String(data.backgroundUrl) : "",
    bio: data.bio ? String(data.bio) : "",
    followingUsers: Array.isArray(data.followingUsers)
      ? data.followingUsers.map(String).filter(Boolean)
      : [],
  };
}

function profileFromUsername(
  username: string,
  preferredLanguage: Language,
): UserProfile {
  const clean = normalizeUsername(username);
  return {
    username: clean,
    alias: clean,
    role: "Usuario registrado",
    joinedAt: new Date().toISOString().slice(0, 10),
    preferredLanguage,
    avatarUrl: "",
    backgroundUrl: "",
    bio: "",
    followingUsers: [],
  };
}

function normalizeUsername(value: string) {
  return value.trim().toLowerCase();
}

function normalizeEmail(value: string) {
  return value.trim().toLowerCase();
}
