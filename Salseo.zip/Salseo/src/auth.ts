import type { Language, UserProfile } from "./types";
import {
  readCurrentProfile,
  registerFirebaseAccount,
  signInFirebaseAccount,
} from "./firebaseClient";

export async function createAccount(input: {
  username: string;
  email: string;
  password: string;
  preferredLanguage: Language;
}): Promise<UserProfile> {
  const username = normalizeUsername(input.username);
  const email = normalizeEmail(input.email);
  validateAccountInput({ username, email, password: input.password });

  try {
    return await withTimeout(
      registerFirebaseAccount({
        username,
        email,
        password: input.password,
        preferredLanguage: input.preferredLanguage,
      }),
      "crear la cuenta",
    );
  } catch (error) {
    throw new Error(readableAuthError(error, "crear la cuenta"));
  }
}

export async function verifyCredentials(input: {
  email: string;
  password: string;
}): Promise<UserProfile> {
  const email = normalizeEmail(input.email);
  const password = input.password;

  if (!email || !password) throw new Error("Introduce email y contraseña.");
  if (!isValidEmail(email)) throw new Error("Introduce un email válido.");

  try {
    const accountId = await withTimeout(
      signInFirebaseAccount({ email, password }),
      "iniciar sesión",
    );
    return await withTimeout(readCurrentProfile(accountId), "cargar tu perfil");
  } catch (error) {
    throw new Error(readableAuthError(error, "iniciar sesión"));
  }
}

export function createReaderProfile(lang: Language): UserProfile {
  return {
    username: `lector-${crypto.randomUUID().slice(0, 6)}`,
    alias: "lector",
    role: "Solo lector",
    joinedAt: new Date().toISOString().slice(0, 10),
    preferredLanguage: lang,
    avatarUrl: "",
    backgroundUrl: "",
    bio: "",
    followingUsers: [],
  };
}

function withTimeout<T>(promise: Promise<T>, action: string, ms = 15000): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = window.setTimeout(() => {
      reject(
        new Error(
          `Salseo tardó demasiado en ${action}. Comprueba la conexión y que Firebase Authentication y Firestore estén activados.`,
        ),
      );
    }, ms);

    promise
      .then((value) => resolve(value))
      .catch((error) => reject(error))
      .finally(() => window.clearTimeout(timer));
  });
}

function readableAuthError(error: unknown, action: string) {
  const raw = error instanceof Error ? error.message : String(error || "");
  const message = raw.toLowerCase();

  if (message.includes("email-already-in-use")) {
    return "Ese email ya está registrado. Entra con Iniciar sesión o usa otro email.";
  }
  if (message.includes("invalid-email")) {
    return "El email no tiene un formato válido.";
  }
  if (message.includes("weak-password")) {
    return "La contraseña es demasiado débil. Usa al menos 8 caracteres.";
  }
  if (message.includes("operation-not-allowed")) {
    return "El registro por email y contraseña no está activado en Firebase Authentication.";
  }
  if (message.includes("wrong-password") || message.includes("invalid-credential") || message.includes("user-not-found")) {
    return "Email o contraseña incorrectos.";
  }
  if (message.includes("permission-denied") || message.includes("missing or insufficient permissions")) {
    return "Firebase no permite guardar o leer el perfil. Revisa y publica las reglas de Firestore.";
  }
  if (message.includes("network-request-failed") || message.includes("failed to fetch") || message.includes("networkerror")) {
    return "No hay conexión con Firebase. Revisa Internet y vuelve a intentarlo.";
  }
  if (message.includes("firebase no está configurado")) {
    return raw;
  }
  if (message.includes("tardó demasiado")) {
    return raw;
  }
  if (message.includes("usuario ya está en uso")) {
    return raw;
  }
  if (message.includes("perfil")) {
    return raw;
  }

  return `No se pudo ${action}. ${raw || "Inténtalo de nuevo."}`;
}

function validateAccountInput(input: { username: string; email: string; password: string }) {
  const looksLikeUsername = /^[a-z0-9._-]{3,32}$/.test(input.username);
  if (!looksLikeUsername) {
    throw new Error("Introduce un usuario válido: 3 a 32 caracteres, letras, números, punto, guion o guion bajo.");
  }
  if (!isValidEmail(input.email)) {
    throw new Error("Introduce un email válido.");
  }
  if (input.password.length < 8) {
    throw new Error("La contraseña debe tener al menos 8 caracteres.");
  }
}

function normalizeUsername(value: string) {
  return value.trim().toLowerCase();
}

function normalizeEmail(value: string) {
  return value.trim().toLowerCase();
}

function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}
