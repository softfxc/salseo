import type { Language, UserProfile } from "./types";
import {
  readCurrentProfile,
  registerFirebaseAccount,
  signInFirebaseAccount,
} from "./firebaseClient";

export async function createAccount(input: {
  username: string;
  email: string;
  password: string;
  preferredLanguage: Language;
}): Promise<UserProfile> {
  const username = normalizeUsername(input.username);
  const email = normalizeEmail(input.email);
  validateAccountInput({ username, email, password: input.password });

  return registerFirebaseAccount({
    username,
    email,
    password: input.password,
    preferredLanguage: input.preferredLanguage,
  });
}

export async function verifyCredentials(input: {
  email: string;
  password: string;
}): Promise<UserProfile> {
  const email = normalizeEmail(input.email);
  const password = input.password;

  if (!email || !password) throw new Error("Introduce email y contraseña.");
  if (!isValidEmail(email)) throw new Error("Introduce un email válido.");
  const accountId = await signInFirebaseAccount({ email, password });
  return readCurrentProfile(accountId);
}

export function createReaderProfile(lang: Language): UserProfile {
  return {
    username: `lector-${crypto.randomUUID().slice(0, 6)}`,
    alias: "lector",
    role: "Solo lector",
    joinedAt: new Date().toISOString().slice(0, 10),
    preferredLanguage: lang,
    avatarUrl: "",
    backgroundUrl: "",
    bio: "",
    followingUsers: [],
  };
}

function validateAccountInput(input: { username: string; email: string; password: string }) {
  const looksLikeUsername = /^[a-z0-9._-]{3,32}$/.test(input.username);
  if (!looksLikeUsername) {
    throw new Error("Introduce un usuario válido: 3 a 32 caracteres, letras, números, punto, guion o guion bajo.");
  }
  if (!isValidEmail(input.email)) {
    throw new Error("Introduce un email válido.");
  }
  if (input.password.length < 8) {
    throw new Error("La contraseña debe tener al menos 8 caracteres.");
  }
}

function normalizeUsername(value: string) {
  return value.trim().toLowerCase();
}

function normalizeEmail(value: string) {
  return value.trim().toLowerCase();
}

function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}
