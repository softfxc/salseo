import type { Language, UserProfile } from "./types";
import {
  readCurrentProfile,
  readPrivatePin,
  registerFirebaseAccount,
  signInFirebaseAccount,
} from "./firebaseClient";

const ITERATIONS = 120_000;
const PIN_MIN_LENGTH = 16;

export async function createAccount(input: {
  username: string;
  password: string;
  pin: string;
  preferredLanguage: Language;
}): Promise<UserProfile> {
  const username = normalizeUsername(input.username);
  validateAccountInput({ username, password: input.password, pin: input.pin });

  const pinSalt = randomBase64(16);
  const pinHash = await hashSecret(input.pin, pinSalt);

  return registerFirebaseAccount({
    username,
    password: input.password,
    pinHash,
    pinSalt,
    preferredLanguage: input.preferredLanguage,
  });
}

export async function verifyCredentials(input: {
  username: string;
  password: string;
}): Promise<string> {
  const username = normalizeUsername(input.username);
  const password = input.password;

  if (!username || !password) throw new Error("Introduce usuario y contraseña.");
  return signInFirebaseAccount({ username, password });
}

export async function verifyPin(accountId: string, pin: string): Promise<UserProfile> {
  if (pin.length < PIN_MIN_LENGTH) {
    throw new Error(`El PIN debe tener al menos ${PIN_MIN_LENGTH} caracteres.`);
  }

  const privateData = await readPrivatePin(accountId);
  const pinHash = await hashSecret(pin, privateData.pinSalt);
  if (pinHash !== privateData.pinHash) throw new Error("El PIN no es correcto.");

  return readCurrentProfile(accountId);
}

export function createReaderProfile(lang: Language): UserProfile {
  return {
    username: `lector-${crypto.randomUUID().slice(0, 6)}`,
    alias: "lector",
    role: "Solo lector",
    joinedAt: new Date().toISOString().slice(0, 10),
    preferredLanguage: lang,
    avatarUrl: "",
    backgroundUrl: "",
    bio: "",
  };
}

function validateAccountInput(input: { username: string; password: string; pin: string }) {
  const looksLikeEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.username);
  const looksLikeUsername = /^[a-z0-9._-]{3,32}$/.test(input.username);
  if (!looksLikeEmail && !looksLikeUsername) {
    throw new Error("Introduce un usuario válido o un correo electrónico válido.");
  }
  if (input.password.length < 8) {
    throw new Error("La contraseña debe tener al menos 8 caracteres.");
  }
  if (input.pin.length < PIN_MIN_LENGTH) {
    throw new Error(`El PIN debe tener al menos ${PIN_MIN_LENGTH} caracteres.`);
  }
}

function normalizeUsername(value: string) {
  return value.trim().toLowerCase();
}

function randomBase64(bytes: number) {
  const array = new Uint8Array(bytes);
  crypto.getRandomValues(array);
  return btoa(String.fromCharCode(...array));
}

async function hashSecret(secret: string, salt: string) {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt: encoder.encode(salt),
      iterations: ITERATIONS,
      hash: "SHA-256",
    },
    keyMaterial,
    256,
  );
  return btoa(String.fromCharCode(...new Uint8Array(bits)));
}
