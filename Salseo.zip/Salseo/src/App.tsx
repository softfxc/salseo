import {
  ArrowLeft,
  Camera,
  Check,
  CheckCircle2,
  ChevronRight,
  Copy,
  EllipsisVertical,
  Eye,
  EyeOff,
  Heart,
  Home,
  ImagePlus,
  KeyRound,
  Link2,
  MessageCircle,
  Play,
  Search,
  Send,
  Settings,
  ShieldCheck,
  Trash2,
  UserRound,
  X,
} from "lucide-react";
import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from "react";
import {
  defaultAvatarUrl,
  defaultBackgroundUrl,
  privacyPolicyUrl,
  defaultNotificationPrefs,
  emptyProfile,
  initialHistory,
  seedChat,
  seedPosts,
} from "./data";
import { createAccount, createReaderProfile, verifyCredentials, verifyPin } from "./auth";
import { copyByLang, type UiCopy } from "./i18n";
import { runExternalSearch } from "./search";
import { useLocalMesh } from "./p2p";
import { useStoredState } from "./storage";
import type { ChatMessage, CommunityPost, Language, MeshPayload, NavView, NotificationPrefs, RecipeResult, UserProfile } from "./types";

const MAX_PHOTO_SIZE = 5 * 1024 * 1024;
const randomId = (prefix: string) => `${prefix}-${crypto.randomUUID().slice(0, 8)}`;
const bottomViews: NavView[] = ["buscar", "favoritos", "chats", "perfil"];

function App() {
  const [lang, setLang] = useStoredState<Language>("salseo:lang:v9", "es");
  const [isAuthed, setIsAuthed] = useStoredState("salseo:authed:v9", false);
  const [profile, setProfile] = useStoredState<UserProfile>("salseo:profile:v9", emptyProfile(lang));
  const [view, setView] = useStoredState<NavView>("salseo:view:v9", "buscar");
  const [query, setQuery] = useStoredState("salseo:query:v9", "");
  const [history, setHistory] = useStoredState<string[]>("salseo:history:v9", initialHistory);
  const [preparedRecipes, setPreparedRecipes] = useStoredState<RecipeResult[]>("salseo:prepared-recipes:v9", []);
  const [favoriteRecipes, setFavoriteRecipes] = useStoredState<string[]>("salseo:fav-recipes:v9", []);
  const [favoritePosts, setFavoritePosts] = useStoredState<string[]>("salseo:fav-posts:v9", []);
  const [posts, setPosts] = useStoredState<CommunityPost[]>("salseo:posts:v9", seedPosts);
  const [chat, setChat] = useStoredState<ChatMessage[]>("salseo:chat:v9", seedChat);
  const [notificationPrefs, setNotificationPrefs] = useStoredState<NotificationPrefs>("salseo:notifications:v9", defaultNotificationPrefs);
  const [ignoredUsers, setIgnoredUsers] = useStoredState<string[]>("salseo:ignored-users:v9", []);
  const [results, setResults] = useState<RecipeResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState("");

  const copy = copyByLang[lang];
  const activeProfile = normalizeProfile(profile, lang);
  const isReader = activeProfile.role === "Solo lector";
  const isModerator = activeProfile.role === "Creador / Moderador";

  const onMeshPayload = (payload: MeshPayload) => {
    if (isPayloadIgnored(payload, ignoredUsers)) return;
    if (payload.type === "chat") {
      setChat((current) => mergeById(current, payload.message));
      notifyIfAllowed(notificationPrefs, "Salseo", `Nuevo mensaje de ${payload.message.author}`);
    }
    if (payload.type === "post") {
      setPosts((current) => mergeById(current, payload.post));
      notifyIfAllowed(notificationPrefs, "Salseo", `Nuevo comentario de ${payload.post.author}`);
    }
    if (payload.type === "recipe") {
      setPreparedRecipes((current) => mergeById(current, payload.recipe));
      notifyIfAllowed(notificationPrefs, "Salseo", `Nueva entrada: ${payload.recipe.title}`);
    }
    if (payload.type === "moderation") {
      setPosts((current) => current.map((post) => (post.id === payload.postId ? { ...post, status: payload.status } : post)));
    }
  };

  const { peerId, peers, broadcast, createOffer, acceptOffer, completeAnswer, connectionState } = useLocalMesh(onMeshPayload);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    const clean = normalizeProfile(profile, lang);
    if (JSON.stringify(clean) !== JSON.stringify(profile)) setProfile(clean);
  }, [profile, lang, setProfile]);

  const visiblePosts = useMemo(() => posts.filter((post) => post.status === "approved" || isModerator), [posts, isModerator]);
  const ignoredCandidates = useMemo(() => sortedAuthors([...chat.map((item) => item.author), ...posts.map((item) => item.author)]), [chat, posts]);

  const runSearch = async (nextQuery = query) => {
    const clean = nextQuery.trim();
    if (!clean) return;
    setQuery(clean);
    setView("buscar");
    setHistory((current) => [clean, ...current.filter((item) => normalize(item) !== normalize(clean))].slice(0, 20));
    setSearching(true);
    setSearchError("");

    try {
      const report = await runExternalSearch(clean);
      setResults(report.results);
      if (report.results.length > 0) {
        setPreparedRecipes((current) => mergeManyById(current, report.results).slice(0, 80));
        report.results.forEach((recipe) => broadcast({ type: "recipe", recipe }));
      }
      if (report.errors.length > 0 && report.results.length === 0) setSearchError("No se pudieron cargar resultados externos.");
    } catch (error) {
      setResults([]);
      setSearchError(error instanceof Error ? error.message : "La búsqueda falló.");
    } finally {
      setSearching(false);
    }
  };

  const toggleRecipeFavorite = (id: string) => setFavoriteRecipes((current) => toggleId(current, id));
  const togglePostFavorite = (id: string) => setFavoritePosts((current) => toggleId(current, id));

  const addPost = (post: CommunityPost) => {
    setPosts((current) => [post, ...current]);
    broadcast({ type: "post", post });
  };

  const discussRecipe = (recipe: RecipeResult) => {
    if (isReader) return;
    addPost({
      id: randomId("post"),
      author: activeProfile.username,
      handle: activeProfile.alias || activeProfile.username,
      title: `Comentario sobre: ${recipe.title}`,
      body: `Hilo abierto para comentar este resultado de ${recipe.sourceLabel}.`,
      tags: recipe.tags.slice(0, 4),
      linkUrl: recipe.sourceUrl,
      createdAt: nowLabel(),
      likes: 0,
      replies: 0,
      status: isModerator ? "approved" : "pending",
    });
    setView("chats");
  };

  const sendChat = (message: ChatMessage) => {
    if (isReader) return;
    setChat((current) => [...current, message]);
    broadcast({ type: "chat", message });
  };

  const moderatePost = (id: string, status: CommunityPost["status"]) => {
    setPosts((current) => current.map((post) => (post.id === id ? { ...post, status } : post)));
    broadcast({ type: "moderation", postId: id, status, moderator: activeProfile.username });
  };

  const clearLocalSession = () => {
    setProfile(emptyProfile(lang));
    setFavoritePosts([]);
    setFavoriteRecipes([]);
    setPosts([]);
    setChat([]);
    setPreparedRecipes([]);
    setResults([]);
    setQuery("");
    setIsAuthed(false);
    setView("buscar");
  };

  if (!isAuthed) {
    return (
      <AuthScreen
        lang={lang}
        copy={copy}
        onProfile={(nextProfile) => {
          const clean = normalizeProfile(nextProfile, nextProfile.preferredLanguage);
          setProfile(clean);
          setLang(clean.preferredLanguage);
        }}
        onEnter={() => {
          setIsAuthed(true);
          setView("buscar");
        }}
      />
    );
  }

  return (
    <div className="app-shell">
      <main className="screen-stage">
        {view === "buscar" && (
          <SearchView
            query={query}
            history={history}
            recipes={results}
            copy={copy}
            favoriteRecipes={favoriteRecipes}
            searching={searching}
            searchError={searchError}
            onQuery={setQuery}
            onSearch={runSearch}
            onFavorite={toggleRecipeFavorite}
            onDiscuss={discussRecipe}
          />
        )}

        {view === "favoritos" && (
          <FavoritesView
            recipes={preparedRecipes.filter((recipe) => favoriteRecipes.includes(recipe.id))}
            posts={visiblePosts.filter((post) => favoritePosts.includes(post.id))}
            copy={copy}
            favoriteRecipes={favoriteRecipes}
            favoritePosts={favoritePosts}
            onRecipeFavorite={toggleRecipeFavorite}
            onPostFavorite={togglePostFavorite}
          />
        )}

        {view === "chats" && (
          <ChatsView
            chat={chat}
            posts={visiblePosts}
            profile={activeProfile}
            copy={copy}
            canChat={!isReader}
            onSend={sendChat}
            isModerator={isModerator}
            favoritePosts={favoritePosts}
            onPostFavorite={togglePostFavorite}
            onModerate={moderatePost}
          />
        )}

        {view === "perfil" && (
          <ProfileView
            profile={activeProfile}
            copy={copy}
            preparedCount={preparedRecipes.length}
            favoriteCount={favoritePosts.length + favoriteRecipes.length}
            onEdit={() => setView("editarPerfil")}
            onSettings={() => setView("ajustes")}
            onPrepared={() => setView("preparados")}
            onFavorites={() => setView("favoritos")}
            onLogout={() => {
              if (window.confirm(copy.settings.logoutWarning)) clearLocalSession();
            }}
          />
        )}

        {view === "preparados" && (
          <PreparedView
            copy={copy}
            recipes={preparedRecipes}
            favoriteRecipes={favoriteRecipes}
            onBack={() => setView("perfil")}
            onFavorite={toggleRecipeFavorite}
          />
        )}

        {view === "editarPerfil" && (
          <EditProfileView
            profile={activeProfile}
            copy={copy}
            isReader={isReader}
            onBack={() => setView("perfil")}
            onProfile={(nextProfile) => setProfile(normalizeProfile(nextProfile, lang))}
          />
        )}

        {view === "ajustes" && (
          <SettingsView
            profile={activeProfile}
            copy={copy}
            lang={lang}
            notifications={notificationPrefs}
            onBack={() => setView("perfil")}
            onLang={(nextLang) => {
              setLang(nextLang);
              setProfile({ ...activeProfile, preferredLanguage: nextLang });
            }}
            onNotifications={setNotificationPrefs}
            onClearHistory={() => setHistory([])}
            onLogout={() => {
              if (window.confirm(copy.settings.logoutWarning)) clearLocalSession();
            }}
            peerId={peerId}
            peerCount={peers.length + 1}
            connectionState={connectionState}
            onCreateOffer={createOffer}
            onAcceptOffer={acceptOffer}
            onCompleteAnswer={completeAnswer}
          />
        )}
      </main>

      {bottomViews.includes(view) && <BottomNav active={view} copy={copy} onChange={setView} />}
    </div>
  );
}

function AuthScreen({
  lang,
  copy,
  onProfile,
  onEnter,
}: {
  lang: Language;
  copy: UiCopy;
  onProfile: (profile: UserProfile) => void;
  onEnter: () => void;
}) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [loginStage, setLoginStage] = useState<"credentials" | "pin">("credentials");
  const [pendingAccountId, setPendingAccountId] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [pin, setPin] = useState("");
  const [acceptedPrivacy, setAcceptedPrivacy] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showPin, setShowPin] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const reset = (nextMode: "login" | "signup") => {
    setMode(nextMode);
    setLoginStage("credentials");
    setPendingAccountId("");
    setUsername("");
    setPassword("");
    setPin("");
    setAcceptedPrivacy(false);
    setError("");
  };

  const submitAuth = async (event: FormEvent) => {
    event.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      if (mode === "signup") {
        if (!acceptedPrivacy) throw new Error("Debes aceptar la Política de privacidad.");
        const nextProfile = await createAccount({ username, password, pin, preferredLanguage: lang });
        onProfile(nextProfile);
        onEnter();
        return;
      }
      if (loginStage === "credentials") {
        const accountId = await verifyCredentials({ username, password });
        setPendingAccountId(accountId);
        setLoginStage("pin");
        setPin("");
        return;
      }
      const nextProfile = await verifyPin(pendingAccountId, pin);
      onProfile(nextProfile);
      onEnter();
    } catch (authError) {
      setError(authError instanceof Error ? authError.message : "No se pudo completar el acceso.");
    } finally {
      setSubmitting(false);
    }
  };

  if (mode === "login" && loginStage === "pin") {
    return (
      <main className="auth-screen">
        <section className="phone-card auth-phone pin-auth">
          <button className="top-icon left" type="button" onClick={() => setLoginStage("credentials")} aria-label="Volver"><ArrowLeft size={22} /></button>
          <form className="pin-panel" onSubmit={submitAuth} autoComplete="off">
            <h1>Verificación PIN</h1>
            <p>Introduce tu PIN de 16 caracteres</p>
            <input className="pin-input" type={showPin ? "text" : "password"} value={pin} onChange={(event) => setPin(event.target.value)} autoComplete="off" autoFocus />
            <button className="ghost-eye" type="button" onClick={() => setShowPin((value) => !value)}>{showPin ? <EyeOff size={18} /> : <Eye size={18} />}</button>
            {error && <p className="form-error">{error}</p>}
            <button className="primary-button full" type="submit" disabled={submitting}>{copy.auth.verifyPin}</button>
          </form>
        </section>
      </main>
    );
  }

  return (
    <main className="auth-screen">
      <section className={mode === "signup" ? "phone-card auth-phone signup-phone" : "phone-card auth-phone"}>
        {mode === "signup" ? (
          <>
            <header className="plain-header">
              <button className="top-icon" type="button" onClick={() => reset("login")} aria-label="Volver"><ArrowLeft size={22} /></button>
              <h1>Crear cuenta</h1>
              <span />
            </header>
            <form className="auth-form clean-form" onSubmit={submitAuth} autoComplete="off">
              <input value={username} onChange={(event) => setUsername(event.target.value)} placeholder={copy.auth.username} autoComplete="off" />
              <PasswordField value={password} onChange={setPassword} placeholder={copy.auth.password} visible={showPassword} onVisible={setShowPassword} />
              <PasswordField value={pin} onChange={setPin} placeholder={copy.auth.pin} visible={showPin} onVisible={setShowPin} />
              <p className="pin-note">El PIN se usa como verificación en 2 pasos y se guarda solo en tu dispositivo.</p>
              <label className="check-line"><input type="checkbox" checked={acceptedPrivacy} onChange={(event) => setAcceptedPrivacy(event.target.checked)} /> <span>Acepto la <a href={privacyPolicyUrl} target="_blank" rel="noreferrer">Política de privacidad</a></span></label>
              {error && <p className="form-error">{error}</p>}
              <button className="primary-button full" type="submit" disabled={submitting}>Crear cuenta</button>
            </form>
          </>
        ) : (
          <>
            <div className="login-logo-wrap"><img className="login-logo" src="/salseo-icon-512.png" alt="Salseo" /></div>
            <h1 className="login-title">Salseo</h1>
            <form className="auth-form login-form" onSubmit={submitAuth} autoComplete="off">
              <h2>Iniciar sesión</h2>
              <input value={username} onChange={(event) => setUsername(event.target.value)} placeholder={copy.auth.username} autoComplete="off" />
              <PasswordField value={password} onChange={setPassword} placeholder={copy.auth.password} visible={showPassword} onVisible={setShowPassword} />
              {error && <p className="form-error">{error}</p>}
              <button className="primary-button full" type="submit" disabled={submitting}>Iniciar sesión</button>
              <button className="link-button register-link" type="button" onClick={() => reset("signup")}>¿No tienes cuenta? <strong>Regístrate</strong></button>
              <button className="link-button muted-link" type="button" onClick={() => { onProfile(createReaderProfile(lang)); onEnter(); }}>Entrar como invitado</button>
            </form>
          </>
        )}
      </section>
    </main>
  );
}

function PasswordField({ value, onChange, placeholder, visible, onVisible }: { value: string; onChange: (value: string) => void; placeholder: string; visible: boolean; onVisible: (visible: boolean) => void }) {
  return (
    <label className="password-field">
      <input type={visible ? "text" : "password"} value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} autoComplete="off" />
      <button type="button" onClick={() => onVisible(!visible)} aria-label="Mostrar contraseña">{visible ? <EyeOff size={17} /> : <Eye size={17} />}</button>
    </label>
  );
}

function SearchView({
  query,
  history,
  recipes,
  copy,
  favoriteRecipes,
  searching,
  searchError,
  onQuery,
  onSearch,
  onFavorite,
  onDiscuss,
}: {
  query: string;
  history: string[];
  recipes: RecipeResult[];
  copy: UiCopy;
  favoriteRecipes: string[];
  searching: boolean;
  searchError: string;
  onQuery: (query: string) => void;
  onSearch: (query?: string) => void;
  onFavorite: (id: string) => void;
  onDiscuss: (recipe: RecipeResult) => void;
}) {
  const [tab, setTab] = useState<"todo" | "recetas" | "videos" | "blogs">("todo");
  const [menuOpen, setMenuOpen] = useState(false);
  const videos = recipes.filter((recipe) => recipe.sourceLabel.toLowerCase().includes("youtube") || recipe.youtubeId);
  const blogs = recipes.filter((recipe) => !videos.includes(recipe));
  const shownBlogs = tab === "todo" || tab === "recetas" || tab === "blogs" ? blogs : [];
  const shownVideos = tab === "todo" || tab === "videos" ? videos : [];

  return (
    <section className="mobile-screen with-bottom-padding">
      <header className="screen-header search-header"><h1>{copy.search.title}</h1><div className="menu-anchor"><button className="top-icon" type="button" aria-label="Opciones" onClick={() => setMenuOpen((value) => !value)}><EllipsisVertical size={21} /></button>{menuOpen && <div className="overflow-menu"><button type="button" onClick={() => { onQuery(""); setMenuOpen(false); }}>Limpiar búsqueda</button><button type="button" onClick={() => { if (query.trim()) onSearch(query); setMenuOpen(false); }}>Recargar</button></div>}</div></header>
      <form className="mock-search" onSubmit={(event) => { event.preventDefault(); onSearch(query); }}>
        <Search size={18} />
        <input value={query} onChange={(event) => onQuery(event.target.value)} placeholder={copy.search.placeholder} />
      </form>
      <div className="tabs" role="tablist">
        <button className={tab === "todo" ? "active" : ""} onClick={() => setTab("todo")} type="button">Todo</button>
        <button className={tab === "recetas" ? "active" : ""} onClick={() => setTab("recetas")} type="button">Recetas</button>
        <button className={tab === "videos" ? "active" : ""} onClick={() => setTab("videos")} type="button">Vídeos</button>
        <button className={tab === "blogs" ? "active" : ""} onClick={() => setTab("blogs")} type="button">Blogs</button>
      </div>

      {searching && <p className="empty-state clean-empty">{copy.search.searching}</p>}
      {searchError && <p className="form-error clean-error">{searchError}</p>}

      {!searching && recipes.length === 0 && query.trim() && <p className="empty-state clean-empty">{copy.search.noResults}</p>}
      {!searching && recipes.length === 0 && !query.trim() && history.length > 0 && (
        <div className="history-pills">{history.slice(0, 6).map((item) => <button key={item} type="button" onClick={() => onSearch(item)}>{item}</button>)}</div>
      )}

      {shownBlogs.length > 0 && (
        <div className="recipe-feed">
          {shownBlogs.map((recipe) => <RecipeListItem key={recipe.id} recipe={recipe} copy={copy} isFavorite={favoriteRecipes.includes(recipe.id)} onFavorite={() => onFavorite(recipe.id)} onDiscuss={() => onDiscuss(recipe)} />)}
        </div>
      )}

      {shownVideos.length > 0 && (
        <section className="youtube-section">
          <h2>Vídeos de YouTube</h2>
          <div className="youtube-rail">
            {shownVideos.map((recipe) => <YoutubeCard key={recipe.id} recipe={recipe} />)}
          </div>
        </section>
      )}
    </section>
  );
}

function RecipeListItem({ recipe, copy, isFavorite, onFavorite, onDiscuss, compact = false }: { recipe: RecipeResult; copy: UiCopy; isFavorite: boolean; onFavorite: () => void; onDiscuss?: () => void; compact?: boolean }) {
  const hasDetails = recipe.ingredients.length > 0 || recipe.steps.length > 0;
  return (
    <article className={compact ? "list-card compact" : "list-card"}>
      <div className="list-main">
        <div className="list-text">
          <h2>{recipe.title}</h2>
          <p className="source-line">{recipe.sourceLabel}</p>
          {recipe.summary && <p>{recipe.summary}</p>}
        </div>
        {recipe.imageUrl ? <img src={recipe.imageUrl} alt="" /> : <DishThumb title={recipe.title} />}
      </div>
      {!compact && hasDetails && (
        <div className="recipe-inline-details">
          {recipe.ingredients.length > 0 && <div><strong>{copy.recipe.ingredients}</strong><ul>{recipe.ingredients.slice(0, 8).map((item) => <li key={item}>{item}</li>)}</ul></div>}
          {recipe.steps.length > 0 && <div><strong>{copy.recipe.steps}</strong><ol>{recipe.steps.slice(0, 5).map((item) => <li key={item}>{item}</li>)}</ol></div>}
        </div>
      )}
      {!compact && !hasDetails && <p className="source-note">{copy.recipe.sourceOnly}</p>}
      <div className="small-actions">
        <button className={isFavorite ? "heart active" : "heart"} type="button" onClick={onFavorite}><Heart size={18} fill={isFavorite ? "currentColor" : "none"} /></button>
        {onDiscuss && <button type="button" className="text-mini" onClick={onDiscuss}>{copy.recipe.discuss}</button>}
        {recipe.sourceUrl && <a className="text-mini" href={recipe.sourceUrl} target="_blank" rel="noreferrer">Abrir</a>}
      </div>
    </article>
  );
}

function YoutubeCard({ recipe }: { recipe: RecipeResult }) {
  const id = youtubeVideoId(recipe.youtubeId || recipe.sourceUrl);
  const href = recipe.sourceUrl || `https://www.youtube.com/results?search_query=${encodeURIComponent(recipe.title)}`;
  return (
    <a className="yt-card" href={href} target="_blank" rel="noreferrer">
      <div className="yt-thumb">
        {id ? <img src={`https://i.ytimg.com/vi/${id}/hqdefault.jpg`} alt="" /> : <div className="yt-fallback">YouTube</div>}
        <span className="play-dot"><Play size={18} fill="currentColor" /></span>
      </div>
      <strong>{recipe.title}</strong>
      <span>{recipe.author || "YouTube"}</span>
    </a>
  );
}

function DishThumb({ title }: { title: string }) {
  return <div className="dish-thumb"><span>{title.slice(0, 1).toUpperCase()}</span></div>;
}

function FavoritesView({ recipes, posts, copy, favoriteRecipes, favoritePosts, onRecipeFavorite, onPostFavorite }: { recipes: RecipeResult[]; posts: CommunityPost[]; copy: UiCopy; favoriteRecipes: string[]; favoritePosts: string[]; onRecipeFavorite: (id: string) => void; onPostFavorite: (id: string) => void }) {
  return (
    <section className="mobile-screen with-bottom-padding">
      <header className="screen-header centered"><h1>{copy.favorites.title}</h1></header>
      {recipes.length === 0 && posts.length === 0 ? <p className="empty-state clean-empty">{copy.favorites.empty}</p> : (
        <div className="recipe-feed">
          {recipes.map((recipe) => <RecipeListItem key={recipe.id} recipe={recipe} copy={copy} isFavorite={favoriteRecipes.includes(recipe.id)} onFavorite={() => onRecipeFavorite(recipe.id)} compact />)}
          {posts.map((post) => <PostListItem key={post.id} post={post} isFavorite={favoritePosts.includes(post.id)} onFavorite={() => onPostFavorite(post.id)} />)}
        </div>
      )}
    </section>
  );
}

function ChatsView({
  chat,
  posts,
  profile,
  copy,
  canChat,
  onSend,
  isModerator,
  favoritePosts,
  onPostFavorite,
  onModerate,
}: {
  chat: ChatMessage[];
  posts: CommunityPost[];
  profile: UserProfile;
  copy: UiCopy;
  canChat: boolean;
  onSend: (message: ChatMessage) => void;
  isModerator: boolean;
  favoritePosts: string[];
  onPostFavorite: (id: string) => void;
  onModerate: (id: string, status: CommunityPost["status"]) => void;
}) {
  const [draft, setDraft] = useState("");
  const [filter, setFilter] = useState<"todos" | "p2p" | "grupos" | "favoritos">("todos");

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!draft.trim() || !canChat) return;
    onSend({ id: randomId("chat"), author: profile.username, body: draft.trim(), createdAt: nowLabel(), mine: true });
    setDraft("");
  };

  const visiblePosts = filter === "favoritos" ? posts.filter((post) => favoritePosts.includes(post.id)) : posts;

  return (
    <section className="mobile-screen with-bottom-padding chat-screen">
      <header className="screen-header"><h1>Chats</h1><div className="chat-header-icons"><button className="top-icon" type="button" aria-label="Buscar chats"><Search size={19} /></button><button className="top-icon" type="button" aria-label="Opciones"><EllipsisVertical size={20} /></button></div></header>
      <div className="chat-tabs" role="tablist">
        <button className={filter === "todos" ? "active" : ""} type="button" onClick={() => setFilter("todos")}>Todos</button>
        <button className={filter === "p2p" ? "active" : ""} type="button" onClick={() => setFilter("p2p")}>P2P</button>
        <button className={filter === "grupos" ? "active" : ""} type="button" onClick={() => setFilter("grupos")}>Grupos</button>
        <button className={filter === "favoritos" ? "active" : ""} type="button" onClick={() => setFilter("favoritos")}>Favoritos</button>
      </div>

      <div className="chat-list modern-chat-list">
        {chat.length === 0 && visiblePosts.length === 0 && (
          <div className="chat-empty-hero"><div className="chat-empty-icon"><MessageCircle size={42} /><span /></div><strong>Aún no tienes conversaciones</strong><p>Inicia un chat P2P y empieza a conversar.</p></div>
        )}
        {visiblePosts.map((post) => <PostListItem key={post.id} post={post} isFavorite={favoritePosts.includes(post.id)} onFavorite={() => onPostFavorite(post.id)} />)}
        {chat.map((message) => <div key={message.id} className={message.mine ? "bubble mine" : "bubble"}><strong>{message.author}</strong><p>{message.body}</p><span>{message.createdAt}</span></div>)}
      </div>

      {!canChat && <p className="reader-chat-note">Como invitado solo puedes leer. Regístrate para participar.</p>}
      {canChat ? (
        <form className="chat-composer modern-composer" onSubmit={submit}>
          <button className="attach-button" type="button" aria-label="Adjuntar">+</button>
          <input value={draft} onChange={(event) => setDraft(event.target.value)} placeholder={copy.chat.placeholder} />
          <button type="submit"><Send size={18} /></button>
        </form>
      ) : (
        <button className="primary-button full new-chat-button" type="button" disabled>Nuevo chat P2P</button>
      )}
      {isModerator && posts.some((post) => post.status === "pending") && <ModerationBlock posts={posts.filter((post) => post.status === "pending")} onModerate={onModerate} />}
    </section>
  );
}

function PostListItem({ post, isFavorite, onFavorite }: { post: CommunityPost; isFavorite: boolean; onFavorite: () => void }) {
  return (
    <article className="post-item">
      <div><strong>{post.title}</strong><span>@{post.handle} · {post.createdAt}</span></div>
      {post.body && <p>{post.body}</p>}
      {post.mediaUrl && <img src={post.mediaUrl} alt="" />}
      <button className={isFavorite ? "heart active" : "heart"} onClick={onFavorite} type="button"><Heart size={17} fill={isFavorite ? "currentColor" : "none"} /></button>
    </article>
  );
}

function ModerationBlock({ posts, onModerate }: { posts: CommunityPost[]; onModerate: (id: string, status: CommunityPost["status"]) => void }) {
  return <section className="moderation-card"><h2>Moderación</h2>{posts.map((post) => <div key={post.id} className="moderation-row"><span>{post.title}</span><button onClick={() => onModerate(post.id, "approved")}><CheckCircle2 size={17} /></button><button onClick={() => onModerate(post.id, "hidden")}><Trash2 size={17} /></button></div>)}</section>;
}

function ProfileView({ profile, copy, preparedCount, favoriteCount, onEdit, onSettings, onPrepared, onFavorites, onLogout }: { profile: UserProfile; copy: UiCopy; preparedCount: number; favoriteCount: number; onEdit: () => void; onSettings: () => void; onPrepared: () => void; onFavorites: () => void; onLogout: () => void }) {
  const avatar = profile.avatarUrl || defaultAvatarUrl;
  const background = profile.backgroundUrl || defaultBackgroundUrl;
  return (
    <section className="mobile-screen with-bottom-padding profile-screen">
      <header className="screen-header centered"><span /><h1>Perfil</h1><button className="top-icon" type="button" onClick={onSettings}><Settings size={20} /></button></header>
      <div className="profile-cover-block"><img className="profile-cover" src={background} alt="Fondo de perfil" /><button className="cover-camera" onClick={onEdit} type="button"><Camera size={18} /></button></div>
      <div className="avatar-row"><div className="avatar-wrap"><img className="profile-avatar" src={avatar} alt="Foto de perfil" /><button type="button" onClick={onEdit}><Camera size={20} /></button></div></div>
      <div className="profile-name"><h2>{profile.alias || profile.username || "Invitado"}</h2><p>{copy.profile.memberSince} {formatMemberSince(profile.joinedAt)}</p></div>
      <nav className="profile-menu">
        <ProfileRow label={copy.profile.about} onClick={onEdit} />
        <ProfileRow label={copy.profile.prepared} value={preparedCount ? String(preparedCount) : ""} onClick={onPrepared} />
        <ProfileRow label={copy.profile.favorites} value={favoriteCount ? String(favoriteCount) : ""} onClick={onFavorites} />
        <ProfileRow label={copy.settings.title} onClick={onSettings} />
        <ProfileRow label={copy.profile.logout} danger onClick={onLogout} />
      </nav>
    </section>
  );
}

function ProfileRow({ label, value, danger, onClick }: { label: string; value?: string; danger?: boolean; onClick: () => void }) {
  return <button className={danger ? "profile-row danger" : "profile-row"} type="button" onClick={onClick}><span>{label}</span><span>{value}</span><ChevronRight size={18} /></button>;
}

function EditProfileView({ profile, copy, isReader, onBack, onProfile }: { profile: UserProfile; copy: UiCopy; isReader: boolean; onBack: () => void; onProfile: (profile: UserProfile) => void }) {
  const [draft, setDraft] = useState(profile);
  const [error, setError] = useState("");
  const avatar = draft.avatarUrl || defaultAvatarUrl;
  const background = draft.backgroundUrl || defaultBackgroundUrl;

  const updateBio = (value: string) => {
    setError("");
    if (value.length > 2000) return setError("La biografía no puede superar 2000 caracteres.");
    if (hasEmoji(value)) return setError("La biografía no admite emoticonos.");
    setDraft({ ...draft, bio: value });
  };

  const handleImage = (field: "avatarUrl" | "backgroundUrl", file?: File) => {
    if (!file || isReader) return;
    setError("");
    if (file.size > MAX_PHOTO_SIZE) return setError("La imagen supera el límite de 5 MB.");
    const reader = new FileReader();
    reader.onload = () => setDraft({ ...draft, [field]: String(reader.result) });
    reader.readAsDataURL(file);
  };

  return (
    <section className="mobile-screen edit-screen">
      <header className="screen-header centered"><button className="top-icon" onClick={onBack} type="button"><X size={22} /></button><h1>Editar perfil</h1><button className="top-icon" onClick={() => { onProfile(draft); onBack(); }} type="button"><Check size={22} /></button></header>
      {isReader && <p className="form-error clean-error">{copy.settings.readerLocked}</p>}
      <div className="edit-cover"><img src={background} alt="" /><label><Camera size={19} /><input type="file" accept="image/*" disabled={isReader} onChange={(event: ChangeEvent<HTMLInputElement>) => handleImage("backgroundUrl", event.target.files?.[0])} /></label></div>
      <div className="edit-avatar"><img src={avatar} alt="" /><label><Camera size={20} /><input type="file" accept="image/*" disabled={isReader} onChange={(event: ChangeEvent<HTMLInputElement>) => handleImage("avatarUrl", event.target.files?.[0])} /></label></div>
      <textarea className="bio-area" value={draft.bio || ""} onChange={(event) => updateBio(event.target.value)} disabled={isReader} placeholder={copy.settings.bioPlaceholder} maxLength={2000} />
      <span className="counter">{(draft.bio || "").length}/2000</span>
      <div className="edit-actions"><label><ImagePlus size={17} /> Cambiar foto de perfil<input type="file" accept="image/*" disabled={isReader} onChange={(event: ChangeEvent<HTMLInputElement>) => handleImage("avatarUrl", event.target.files?.[0])} /></label><label><ImagePlus size={17} /> Cambiar fondo<input type="file" accept="image/*" disabled={isReader} onChange={(event: ChangeEvent<HTMLInputElement>) => handleImage("backgroundUrl", event.target.files?.[0])} /></label></div>
      <p className="privacy-small">{copy.settings.privacyNotice}</p>
      {error && <p className="form-error clean-error">{error}</p>}
    </section>
  );
}

function PreparedView({ copy, recipes, favoriteRecipes, onBack, onFavorite }: { copy: UiCopy; recipes: RecipeResult[]; favoriteRecipes: string[]; onBack: () => void; onFavorite: (id: string) => void }) {
  return (
    <section className="mobile-screen with-bottom-padding">
      <header className="screen-header centered"><button className="top-icon" type="button" onClick={onBack}><ArrowLeft size={22} /></button><h1>{copy.profile.prepared}</h1><span /></header>
      {recipes.length === 0 ? <p className="empty-state clean-empty">Aún no hay entradas preparadas desde búsquedas.</p> : <div className="prepared-list">{recipes.map((recipe) => <RecipeListItem key={recipe.id} recipe={recipe} copy={copy} isFavorite={favoriteRecipes.includes(recipe.id)} onFavorite={() => onFavorite(recipe.id)} compact />)}</div>}
    </section>
  );
}

function SettingsView({ profile, copy, lang, notifications, peerId, peerCount, connectionState, onBack, onLang, onNotifications, onClearHistory, onLogout, onCreateOffer, onAcceptOffer, onCompleteAnswer }: { profile: UserProfile; copy: UiCopy; lang: Language; notifications: NotificationPrefs; peerId: string; peerCount: number; connectionState: string; onBack: () => void; onLang: (lang: Language) => void; onNotifications: (prefs: NotificationPrefs) => void; onClearHistory: () => void; onLogout: () => void; onCreateOffer: () => Promise<string>; onAcceptOffer: (signal: string) => Promise<string>; onCompleteAnswer: (signal: string) => Promise<void> }) {
  const [signalInput, setSignalInput] = useState("");
  const [signalOutput, setSignalOutput] = useState("");
  const [p2pError, setP2pError] = useState("");

  const runP2pAction = async (action: () => Promise<string | void>) => {
    setP2pError("");
    try {
      const output = await action();
      if (typeof output === "string") setSignalOutput(output);
    } catch (error) {
      setP2pError(error instanceof Error ? error.message : "No se pudo completar la conexión P2P.");
    }
  };

  return (
    <section className="mobile-screen settings-screen">
      <header className="screen-header centered"><button className="top-icon" type="button" onClick={onBack}><ArrowLeft size={22} /></button><h1>{copy.settings.title}</h1><span /></header>
      <div className="settings-group">
        <p className="settings-title">GENERAL</p>
        <button className="settings-row-button" type="button"><span>{copy.settings.language}</span><span className="row-value">{lang === "es" ? "Español" : lang === "en" ? "English" : "Français"}</span><ChevronRight size={18} /></button>
        <LanguageRow label="Español" active={lang === "es"} onClick={() => onLang("es")} />
        <LanguageRow label="English" active={lang === "en"} onClick={() => onLang("en")} />
        <LanguageRow label="Français" active={lang === "fr"} onClick={() => onLang("fr")} />
        <P2PSettings peerId={peerId} peerCount={peerCount} connectionState={connectionState} signalInput={signalInput} signalOutput={signalOutput} p2pError={p2pError} onSignalInput={setSignalInput} onCreateOffer={() => runP2pAction(onCreateOffer)} onAcceptOffer={() => runP2pAction(() => onAcceptOffer(signalInput))} onCompleteAnswer={() => runP2pAction(() => onCompleteAnswer(signalInput))} />
        <a className="settings-row-button external-link-row" href={privacyPolicyUrl} target="_blank" rel="noreferrer"><span>Política de privacidad</span><Link2 size={17} /></a>
      </div>
      <div className="settings-group flat">
        <p className="settings-title">PREFERENCIAS</p>
        <ToggleRow label={copy.settings.notifications} checked={notifications.enabled} onClick={() => onNotifications({ ...notifications, enabled: !notifications.enabled })} />
        <ToggleRow label={copy.settings.background} checked={notifications.background} onClick={() => onNotifications({ ...notifications, background: !notifications.background })} />
      </div>
      <div className="settings-group flat">
        <p className="settings-title">ACERCA DE</p>
        <button className="settings-row-button" type="button" onClick={onClearHistory}>{copy.settings.clearHistory}<ChevronRight size={18} /></button>
        <button className="settings-row-button" type="button"><span>Versión</span><span className="row-value">0.1.9</span></button>
        <button className="settings-row-button" type="button">Ayuda y soporte<ChevronRight size={18} /></button>
        <button className="settings-row-button danger" type="button" onClick={onLogout}>{copy.settings.logout}<ChevronRight size={18} /></button>
      </div>
      <p className="settings-foot">{profile.role}</p>
    </section>
  );
}

function P2PSettings({ peerId, peerCount, connectionState, signalInput, signalOutput, p2pError, onSignalInput, onCreateOffer, onAcceptOffer, onCompleteAnswer }: { peerId: string; peerCount: number; connectionState: string; signalInput: string; signalOutput: string; p2pError: string; onSignalInput: (value: string) => void; onCreateOffer: () => void; onAcceptOffer: () => void; onCompleteAnswer: () => void }) {
  return (
    <details className="settings-p2p">
      <summary><span>Conexión P2P</span><ChevronRight size={18} /></summary>
      <div className="settings-p2p-body">
        <div className="status-row compact-status"><span>{peerCount} peer</span><span>{connectionState}</span><span>ID {peerId.slice(0, 8)}</span></div>
        <textarea value={signalInput} onChange={(event) => onSignalInput(event.target.value)} placeholder="Invitación o respuesta" />
        <div className="triple-buttons">
          <button type="button" onClick={onCreateOffer}>Crear</button>
          <button type="button" onClick={onAcceptOffer}>Aceptar</button>
          <button type="button" onClick={onCompleteAnswer}>Conectar</button>
        </div>
        {signalOutput && <div className="copy-box"><button type="button" onClick={() => navigator.clipboard?.writeText(signalOutput)}><Copy size={16} /> Copiar</button><textarea readOnly value={signalOutput} /></div>}
        {p2pError && <p className="form-error">{p2pError}</p>}
      </div>
    </details>
  );
}

function LanguageRow({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return <button className={active ? "language-option active" : "language-option"} onClick={onClick} type="button"><span>{label}</span>{active ? <Check size={20} /> : <ChevronRight size={18} />}</button>;
}

function ToggleRow({ label, checked, disabled, onClick }: { label: string; checked: boolean; disabled?: boolean; onClick: () => void }) {
  return <button className="toggle-row" onClick={onClick} disabled={disabled} type="button"><span>{label}</span><span className={checked ? "switch on" : "switch"}><i /></span></button>;
}

function BottomNav({ active, copy, onChange }: { active: NavView; copy: UiCopy; onChange: (view: NavView) => void }) {
  const items: Array<{ view: NavView; icon: typeof Home }> = [
    { view: "buscar", icon: Home },
    { view: "favoritos", icon: Heart },
    { view: "chats", icon: MessageCircle },
    { view: "perfil", icon: UserRound },
  ];
  return <nav className="bottom-nav">{items.map((item) => { const Icon = item.icon; return <button key={item.view} className={active === item.view ? "active" : ""} type="button" onClick={() => onChange(item.view)}><Icon size={21} /><span>{copy.nav[item.view]}</span></button>; })}</nav>;
}

function toggleId(items: string[], id: string) { return items.includes(id) ? items.filter((item) => item !== id) : [...items, id]; }
function mergeById<T extends { id: string }>(items: T[], item: T) { return items.some((current) => current.id === item.id) ? items : [item, ...items]; }
function mergeManyById<T extends { id: string }>(items: T[], nextItems: T[]) { return nextItems.reduce((current, item) => mergeById(current, item), items); }
function normalize(value: string) { return value.toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu, "").trim(); }
function normalizeProfile(profile: UserProfile, lang: Language): UserProfile { return { ...emptyProfile(lang), ...profile, preferredLanguage: profile.preferredLanguage || lang, alias: profile.alias || profile.username || "Invitado", avatarUrl: profile.avatarUrl || "", backgroundUrl: profile.backgroundUrl || "", bio: profile.bio || "" }; }
function isPayloadIgnored(payload: MeshPayload, ignoredUsers: string[]) { const author = payload.type === "chat" ? payload.message.author : payload.type === "post" ? payload.post.author : ""; return Boolean(author && ignoredUsers.includes(author)); }
function notifyIfAllowed(prefs: NotificationPrefs, title: string, body: string) { if (!prefs.enabled || !("Notification" in window)) return; if (Notification.permission === "granted") new Notification(title, { body }); else if (Notification.permission !== "denied") Notification.requestPermission().then((permission) => { if (permission === "granted") new Notification(title, { body }); }); }
function sortedAuthors(authors: string[]) { return [...new Set(authors.filter(Boolean))].sort((a, b) => a.localeCompare(b)); }
function nowLabel() { return new Date().toLocaleString("es-ES", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }); }
function formatMemberSince(value: string) { const date = new Date(value); return Number.isNaN(date.getTime()) ? value : date.toLocaleDateString("es-ES", { day: "2-digit", month: "2-digit", year: "numeric" }); }
function hasEmoji(value: string) { return /[\p{Extended_Pictographic}\uFE0F]/u.test(value); }
function youtubeVideoId(value: string) { const trimmed = value.trim(); if (!trimmed || trimmed.startsWith("search:")) return ""; if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) return trimmed; try { const url = new URL(trimmed); if (url.hostname.includes("youtu.be")) return url.pathname.split("/").filter(Boolean)[0]?.slice(0, 11) || ""; const watchId = url.searchParams.get("v"); if (watchId) return watchId.slice(0, 11); const parts = url.pathname.split("/").filter(Boolean); const marker = parts.findIndex((part) => ["embed", "shorts", "live"].includes(part)); return marker >= 0 ? parts[marker + 1]?.slice(0, 11) || "" : ""; } catch { return ""; } }

export default App;
