import type { ChatMessage, CommunityPost, ExternalSource, Language, NotificationPrefs, RecipeResult, UserProfile } from "./types";

export const privacyPolicyUrl = "https://github.com/softfxc/salseo";

export const defaultAvatarUrl = "https://commons.wikimedia.org/wiki/Special:Redirect/file/Cat_domestic.jpg";
export const defaultBackgroundUrl = "/default-forest-day.jpg";

export const defaultNotificationPrefs: NotificationPrefs = {
  enabled: true,
  background: true,
};

export const emptyProfile = (lang: Language = "es"): UserProfile => ({
  username: "",
  alias: "",
  role: "Solo lector",
  joinedAt: new Date().toISOString().slice(0, 10),
  preferredLanguage: lang,
  avatarUrl: "",
  backgroundUrl: "",
  bio: "",
});

export const externalSources: ExternalSource[] = [
  {
    name: "Webos Fritos",
    homeUrl: "https://webosfritos.es/",
    searchUrl: "https://webosfritos.es/?s=",
  },
  {
    name: "Javi Recetas",
    homeUrl: "https://www.javirecetas.com/",
    searchUrl: "https://www.javirecetas.com/?s=",
  },
  {
    name: "Mercado Calabajio",
    homeUrl: "https://www.mercadocalabajio.com/",
    searchUrl: "https://www.mercadocalabajio.com/search?q=",
  },
  {
    name: "El Cocinero Casero",
    homeUrl: "https://elcocinerocasero.com/",
    searchUrl: "https://elcocinerocasero.com/buscar?q=",
  },
  {
    name: "Directo al Paladar",
    homeUrl: "https://www.directoalpaladar.com/",
    searchUrl: "https://www.directoalpaladar.com/search?q=",
  },
  {
    name: "Recetas de Rechupete",
    homeUrl: "https://www.recetasderechupete.com/",
    searchUrl: "https://www.recetasderechupete.com/?s=",
  },
  {
    name: "Cocina Familiar",
    homeUrl: "https://cocina-familiar.com/",
    searchUrl: "https://cocina-familiar.com/?s=",
  },
  {
    name: "El Comidista",
    homeUrl: "https://elcomidista.elpais.com/",
    searchUrl: "https://elcomidista.elpais.com/buscador/?q=",
  },
];

export const initialHistory: string[] = [];
export const seedResults: RecipeResult[] = [];
export const seedPosts: CommunityPost[] = [];
export const seedChat: ChatMessage[] = [];
