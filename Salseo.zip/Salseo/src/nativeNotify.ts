import { Capacitor } from "@capacitor/core";
import { LocalNotifications } from "@capacitor/local-notifications";

export async function requestSalseoNotificationPermission() {
  if (Capacitor.isNativePlatform()) {
    const current = await LocalNotifications.checkPermissions();
    if (current.display === "granted") return true;
    const requested = await LocalNotifications.requestPermissions();
    return requested.display === "granted";
  }

  if (!("Notification" in window)) return false;
  if (Notification.permission === "granted") return true;
  if (Notification.permission === "denied") return false;
  const permission = await Notification.requestPermission();
  return permission === "granted";
}

export async function salseoNotificationStatusText() {
  if (Capacitor.isNativePlatform()) {
    try {
      const current = await LocalNotifications.checkPermissions();
      if (current.display === "granted") {
        return "Permiso concedido: Salseo puede avisarte de seguidores, comentarios, favoritos y chats mutuos.";
      }
      if (current.display === "denied") {
        return "Permiso denegado: actívalo desde los ajustes del teléfono para recibir avisos.";
      }
      return "Al activar las notificaciones, Salseo pedirá permiso al teléfono.";
    } catch {
      return "Al activar las notificaciones, Salseo pedirá permiso al dispositivo.";
    }
  }

  if (!("Notification" in window)) return "Notificaciones no disponibles en este dispositivo.";
  if (Notification.permission === "granted") return "Permiso concedido: Salseo podrá mostrar avisos mientras la app esté activa.";
  if (Notification.permission === "denied") return "Permiso denegado: actívalo desde los ajustes del dispositivo si quieres recibir avisos.";
  return "Al activar las notificaciones, Salseo pedirá permiso al dispositivo.";
}

export function showSalseoNotification(title: string, body: string) {
  void (async () => {
    try {
      if (Capacitor.isNativePlatform()) {
        const current = await LocalNotifications.checkPermissions();
        if (current.display !== "granted") return;
        await LocalNotifications.schedule({
          notifications: [
            {
              id: Math.floor(Date.now() % 2147483647),
              title,
              body,
              smallIcon: "ic_stat_icon_config_sample",
              schedule: { at: new Date(Date.now() + 150) },
            },
          ],
        });
        return;
      }

      if (("Notification" in window) && Notification.permission === "granted") {
        new Notification(title, { body });
      }
    } catch (error) {
      console.warn("No se pudo mostrar la notificación local de Salseo", error);
    }
  })();
}
