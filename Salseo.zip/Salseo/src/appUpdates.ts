export const APP_VERSION_LABEL = "1.0-release";

const DEFAULT_REPO = "softfxc/salseo";
const CONFIG_URL = "/app-update.json";

type UpdateConfig = {
  repo?: string;
  currentVersion?: string;
};

export type AppUpdateInfo = {
  currentVersion: string;
  latestVersion: string;
  available: boolean;
  releaseUrl: string;
  assetUrl: string;
  notes: string;
  repo: string;
};

export async function checkForAppUpdate(): Promise<AppUpdateInfo> {
  const config = await loadUpdateConfig();
  const repo = normalizeRepo(config.repo || DEFAULT_REPO);
  const currentVersion = normalizeVersion(config.currentVersion || APP_VERSION_LABEL);
  const response = await fetch(`https://api.github.com/repos/${repo}/releases/latest`, {
    cache: "no-store",
    headers: {
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
    },
  });

  if (!response.ok) {
    throw new Error(
      response.status === 404
        ? "No se pudo consultar releases/latest."
        : `GitHub respondió HTTP ${response.status}`,
    );
  }

  const data = await response.json();
  const latestVersion = normalizeVersion(String(data.tag_name || data.name || ""));
  const assets = Array.isArray(data.assets) ? data.assets : [];
  const apkAsset = assets.find((asset: any) =>
    /\.apk$/i.test(String(asset?.name || asset?.browser_download_url || "")),
  );
  const assetUrl = String(apkAsset?.browser_download_url || data.html_url || "");
  return {
    currentVersion,
    latestVersion,
    available: Boolean(latestVersion && latestVersion !== currentVersion),
    releaseUrl: String(data.html_url || ""),
    assetUrl,
    notes: String(data.body || ""),
    repo,
  };
}

async function loadUpdateConfig(): Promise<UpdateConfig> {
  try {
    const response = await fetch(CONFIG_URL, { cache: "no-store" });
    if (!response.ok) return {};
    return await response.json();
  } catch {
    return {};
  }
}

function normalizeRepo(value: string) {
  return value.trim().replace(/^https:\/\/github\.com\//i, "").replace(/\.git$/i, "").replace(/^\/+|\/+$/g, "") || DEFAULT_REPO;
}

function normalizeVersion(value: string) {
  return value.trim().replace(/^v/i, "");
}
