import type { Language, NavView } from "./types";

export type UiCopy = {
  nav: Record<NavView, string>;
  auth: {
    signup: string;
    login: string;
    submitSignup: string;
    submitLogin: string;
    reader: string;
    username: string;
    email: string;
    password: string;
    pin: string;
    pin2fa: string;
    verifyPin: string;
    back: string;
    localOnly: string;
  };
  search: {
    title: string;
    placeholder: string;
    history: string;
    suggestions: string;
    noResults: string;
    searching: string;
    sources: string;
  };
  recipe: {
    ingredients: string;
    steps: string;
    sourceOnly: string;
    discuss: string;
  };
  posts: {
    publish: string;
    title: string;
    body: string;
    photo: string;
    photoReady: string;
    imageUrl: string;
    postUrl: string;
    upload: string;
    pending: string;
    favs: string;
    replies: string;
    loginRequired: string;
  };
  chat: {
    title: string;
    placeholder: string;
    send: string;
    p2pFilter: string;
    discard: string;
    restore: string;
    readerNotice: string;
  };
  favorites: {
    title: string;
    empty: string;
  };
  profile: {
    prepared: string;
    network: string;
    favorites: string;
    review: string;
    moderation: string;
    empty: string;
    logout: string;
    editPhotos: string;
    memberSince: string;
    about: string;
    noBio: string;
  };
  settings: {
    title: string;
    language: string;
    notifications: string;
    background: string;
    clearHistory: string;
    logout: string;
    logoutWarning: string;
    avatar: string;
    backgroundImage: string;
    imageUrl: string;
    public: string;
    bio: string;
    bioPlaceholder: string;
    bioHelp: string;
    readerLocked: string;
    privacyNotice: string;
  };
  actions: {
    save: string;
    search: string;
    open: string;
  };
};

export const copyByLang: Record<Language, UiCopy> = {
  es: {
    nav: {
      buscar: "Inicio",
      chats: "Chats",
      favoritos: "Favoritos",
      posts: "Posts",
      perfil: "Perfil",
      ajustes: "Ajustes",
      preparados: "Preparados",
      editarPerfil: "Editar perfil",
      perfilVista: "Vista previa",
      detalleReceta: "Receta",
    },
    auth: {
      signup: "Crear cuenta",
      login: "Iniciar sesión",
      submitSignup: "Crear cuenta",
      submitLogin: "Iniciar sesión",
      reader: "Entrar como invitado",
      username: "Usuario",
      email: "Email",
      password: "Contraseña",
      pin: "PIN",
      pin2fa: "PIN",
      verifyPin: "Verificar PIN",
      back: "Volver",
      localOnly:
        "La cuenta es local. Sirve para comentar, subir fotos y firmar aportes en este dispositivo, sin servidor central.",
    },
    search: {
      title: "Buscar",
      placeholder: "Buscar",
      history: "Historial de búsqueda",
      suggestions: "Sugerencias",
      noResults:
        "No hay resultados para esta búsqueda. Prueba otra frase o revisa la conexión.",
      searching: "Cargando...",
      sources: "Fuentes consultadas",
    },
    recipe: {
      ingredients: "Ingredientes",
      steps: "Preparación",
      sourceOnly: "Toca Ver para abrir la ficha de Salseo.",
      discuss: "Comentar",
    },
    posts: {
      publish: "Publicar",
      title: "Título del post",
      body: "Comentario, pregunta o truco",
      photo: "Foto",
      photoReady: "Foto lista",
      imageUrl: "URL de imagen",
      postUrl: "URL relacionada",
      upload: "Subir post",
      pending: "Revisión",
      favs: "favs",
      replies: "respuestas",
      loginRequired:
        "Como invitado solo puedes leer y guardar favoritos. Para comentar o subir fotos necesitas registrarte.",
    },
    chat: {
      title: "Chats",
      placeholder: "Escribe un mensaje...",
      send: "Enviar",
      p2pFilter: "Descartar usuarios del feed",
      discard: "Descartar",
      restore: "Restaurar",
      readerNotice:
        "Como invitado solo puedes leer. Regístrate para participar en chats.",
    },
    favorites: {
      title: "Favoritos",
      empty:
        "Todavía no has guardado favoritos. Puedes guardar recetas, vídeos y posts tocando el corazón.",
    },
    profile: {
      prepared: "Preparados",
      network: "Red",
      favorites: "Favoritos",
      review: "Revisión",
      moderation: "Moderación",
      empty: "No hay posts pendientes.",
      logout: "Cerrar sesión",
      editPhotos: "Editar fotografías",
      memberSince: "Miembro desde",
      about: "Sobre mí",
      noBio: "Sin biografía todavía.",
    },
    settings: {
      title: "Ajustes",
      language: "Idioma",
      notifications: "Notificaciones",
      background: "Segundo plano",
      clearHistory: "Borrar historial de búsqueda",
      logout: "Cerrar sesión",
      logoutWarning:
        "Cerrar sesión eliminará de este dispositivo posts, comentarios, favoritos y perfil. ¿Quieres continuar?",
      avatar: "Foto de perfil",
      backgroundImage: "Fondo de perfil",
      imageUrl: "URL de imagen",
      public: "Público",
      bio: "Sobre mí",
      bioPlaceholder: "Escribe tu biografía",
      bioHelp: "",
      readerLocked: "Como invitado no puedes modificar el perfil.",
      privacyNotice:
        "Salseo pide el uso responsable de la aplicación y recomienda evitar publicar fotos de personas o mascotas. Si necesita conocer más detalles sobre nosotros puede leer nuestra Política de privacidad en https://github.com/softfxc/salseo.",
    },
    actions: { save: "Guardar", search: "Buscar", open: "Abrir" },
  },
  en: {
    nav: {
      buscar: "Home",
      chats: "Chats",
      favoritos: "Saved",
      posts: "Posts",
      perfil: "Profile",
      ajustes: "Settings",
      preparados: "Prepared",
      editarPerfil: "Edit profile",
      perfilVista: "Preview",
      detalleReceta: "Recipe",
    },
    auth: {
      signup: "Sign up",
      login: "Login",
      submitSignup: "Create account",
      submitLogin: "Continue",
      reader: "Enter as guest",
      username: "Public username",
      email: "Email",
      password: "Password",
      pin: "PIN",
      pin2fa: "2FA PIN",
      verifyPin: "Verify PIN",
      back: "Back",
      localOnly:
        "The account is local. It lets you comment, upload photos and sign contributions on this device, without a central server.",
    },
    search: {
      title: "Search recipes and videos",
      placeholder: "Example: omelette, croquettes, chicken rice...",
      history: "Search history",
      suggestions: "Suggestions",
      noResults:
        "No results for this search. Try another phrase or check the connection.",
      searching: "Loading...",
      sources: "Sources checked",
    },
    recipe: {
      ingredients: "Ingredients",
      steps: "Preparation",
      sourceOnly: "Tap View to open the Salseo recipe card.",
      discuss: "Comment",
    },
    posts: {
      publish: "Publish",
      title: "Post title",
      body: "Comment, question or trick",
      photo: "Photo",
      photoReady: "Photo ready",
      imageUrl: "Image URL",
      postUrl: "Related URL",
      upload: "Upload post",
      pending: "Review",
      favs: "favs",
      replies: "replies",
      loginRequired:
        "As a guest you can only read and save favorites. Create an account to comment or upload photos.",
    },
    chat: {
      title: "Chats",
      placeholder: "Write a message...",
      send: "Send",
      p2pFilter: "Discard users from feed",
      discard: "Discard",
      restore: "Restore",
      readerNotice: "As a guest you can only read. Sign up to join chats.",
    },
    favorites: {
      title: "Saved",
      empty:
        "You have not saved anything yet. Tap the heart to save recipes, videos and posts.",
    },
    profile: {
      prepared: "Prepared",
      network: "Network",
      favorites: "Saved",
      review: "Review",
      moderation: "Moderation",
      empty: "No pending posts.",
      logout: "Log out",
      editPhotos: "Edit photographs",
      memberSince: "Member since",
      about: "About me",
      noBio: "No biography yet.",
    },
    settings: {
      title: "Settings",
      language: "Language",
      notifications: "Notifications",
      background: "Background",
      clearHistory: "Clear search history",
      logout: "Log out",
      logoutWarning:
        "Logging out will remove posts, comments, favorites and profile from this device. Continue?",
      avatar: "Profile photo",
      backgroundImage: "Profile background",
      imageUrl: "Image URL",
      public: "Public",
      bio: "About me",
      bioPlaceholder: "Write your biography",
      bioHelp: "",
      readerLocked: "Guests cannot edit the profile.",
      privacyNotice:
        "Salseo requests responsible use of the application and recommends avoiding photos of people or pets. To learn more, read our Privacy Policy at https://github.com/softfxc/salseo.",
    },
    actions: { save: "Save", search: "Search", open: "Open" },
  },
  fr: {
    nav: {
      buscar: "Accueil",
      chats: "Chats",
      favoritos: "Favoris",
      posts: "Posts",
      perfil: "Profil",
      ajustes: "Réglages",
      preparados: "Préparés",
      editarPerfil: "Modifier profil",
      perfilVista: "Aperçu",
      detalleReceta: "Recette",
    },
    auth: {
      signup: "Inscription",
      login: "Login",
      submitSignup: "Créer compte",
      submitLogin: "Continuer",
      reader: "Entrer comme invité",
      username: "Nom public",
      email: "Email",
      password: "Mot de passe",
      pin: "PIN",
      pin2fa: "PIN",
      verifyPin: "Vérifier PIN",
      back: "Retour",
      localOnly:
        "Le compte est local. Il permet de commenter, publier des photos et signer des apports sur cet appareil, sans serveur central.",
    },
    search: {
      title: "Chercher recettes et vidéos",
      placeholder: "Exemple : omelette, croquettes, riz au poulet...",
      history: "Historique de recherche",
      suggestions: "Suggestions",
      noResults:
        "Aucun résultat pour cette recherche. Essaie une autre phrase ou vérifie la connexion.",
      searching: "Chargement...",
      sources: "Sources consultées",
    },
    recipe: {
      ingredients: "Ingrédients",
      steps: "Préparation",
      sourceOnly: "Ouvre la source pour voir la recette complète.",
      discuss: "Commenter",
    },
    posts: {
      publish: "Publier",
      title: "Titre du post",
      body: "Commentaire, question ou astuce",
      photo: "Photo",
      photoReady: "Photo prête",
      imageUrl: "URL image",
      postUrl: "URL liée",
      upload: "Publier",
      pending: "Révision",
      favs: "favoris",
      replies: "réponses",
      loginRequired:
        "Comme invité, tu peux seulement lire et garder des favoris. Crée un compte pour commenter ou publier des photos.",
    },
    chat: {
      title: "Chats",
      placeholder: "Écris un message...",
      send: "Envoyer",
      p2pFilter: "Écarter utilisateurs du feed",
      discard: "Écarter",
      restore: "Restaurer",
      readerNotice:
        "Comme invité, tu peux seulement lire. Inscris-toi pour participer aux chats.",
    },
    favorites: {
      title: "Favoris",
      empty:
        "Tu n'as encore rien gardé. Touche le cœur pour garder recettes, vidéos et posts.",
    },
    profile: {
      prepared: "Préparés récemment",
      network: "Réseau",
      favorites: "Favoris",
      review: "Révision",
      moderation: "Modération",
      empty: "Aucun post en attente.",
      logout: "Fermer session",
      editPhotos: "Modifier photographies",
      memberSince: "Membre depuis",
      about: "À propos de moi",
      noBio: "Aucune biographie pour le moment.",
    },
    settings: {
      title: "Réglages",
      language: "Langue",
      notifications: "Notifications",
      background: "Arrière-plan",
      clearHistory: "Effacer l'historique de recherche",
      logout: "Fermer session",
      logoutWarning:
        "Fermer la session supprimera de cet appareil posts, commentaires, favoris et profil. Continuer ?",
      avatar: "Photo de profil",
      backgroundImage: "Fond de profil",
      imageUrl: "URL image",
      public: "Public",
      bio: "À propos de moi",
      bioPlaceholder: "Écris ta biographie",
      bioHelp: "",
      readerLocked: "Les invités ne peuvent pas modifier le profil.",
      privacyNotice:
        "Salseo demande un usage responsable de l'application et recommande d'éviter les photos de personnes ou d'animaux. Pour plus d'informations, lisez notre Politique de confidentialité sur https://github.com/softfxc/salseo.",
    },
    actions: { save: "Enregistrer", search: "Chercher", open: "Ouvrir" },
  },
};
