import { Capacitor, CapacitorHttp } from "@capacitor/core";
import { externalSources } from "./data";
import type { DishKind, RecipeResult } from "./types";

export type SearchReport = {
  results: RecipeResult[];
  searchedSources: string[];
  errors: string[];
};

type ExtractedBlogLink = {
  url: string;
  title: string;
  summary: string;
  sourceLabel: string;
};

type ExtractedRecipe = {
  title: string;
  summary: string;
  ingredients: string[];
  steps: string[];
  imageUrl?: string;
  author?: string;
  yieldText?: string;
  prepTime?: string;
  cookTime?: string;
  totalTime?: string;
};

type VideoHit = {
  id: string;
  title: string;
  author?: string;
  thumbnailUrl?: string;
};

const BLOG_LINKS_PER_SOURCE = 6;
const BLOG_RESULT_LIMIT = 36;
const YOUTUBE_RESULT_LIMIT = 18;
const YOUTUBE_VERIFY_LIMIT = 24;
const VIDEO_PROVIDER_LIMIT = 32;
const PIPED_API_BASES = [
  "https://pipedapi.kavin.rocks",
  "https://pipedapi.adminforge.de",
  "https://pipedapi.syncpundit.io",
  "https://api-piped.mha.fi",
  "https://pipedapi.rivo.lol",
  "https://pipedapi-libre.kavin.rocks",
];
const INVIDIOUS_API_BASES = [
  "https://yewtu.be",
  "https://inv.nadeko.net",
  "https://invidious.nerdvpn.de",
  "https://iv.ggtyler.dev",
  "https://inv.tux.pizza",
  "https://inv.us.projectsegfau.lt",
  "https://invidious.privacyredirect.com",
];
const VIDEO_SEARCH_ENGINE_BASES = [
  "https://duckduckgo.com/html/",
  "https://lite.duckduckgo.com/lite/",
  "https://www.bing.com/search",
  "https://search.brave.com/search",
];
const REQUEST_TIMEOUT_MS = 13_000;
const YOUTUBE_EMBED_VERIFY_TIMEOUT_MS = 6_000;
const RECIPE_DETAIL_LIMIT = 120;

export async function runExternalSearch(query: string): Promise<SearchReport> {
  const clean = query.trim();
  if (!clean) return { results: [], searchedSources: [], errors: [] };

  const [blogReport, videoReport] = await Promise.all([
    searchRecipeBlogs(clean),
    searchYoutubeVideos(clean),
  ]);
  const unique = dedupeResults([...videoReport.results, ...blogReport.results]);

  return {
    results: unique,
    searchedSources: [
      ...blogReport.searchedSources,
      ...videoReport.searchedSources,
    ],
    errors: [...blogReport.errors, ...videoReport.errors],
  };
}

export function derivedSuggestions(query: string, history: string[]) {
  const clean = query.trim();
  if (!clean) return history.slice(0, 5);
  return [
    `${clean} receta casera`,
    `${clean} ingredientes preparación`,
    `${clean} fácil paso a paso`,
    `${clean} con vídeo`,
    `${clean} tradicional`,
  ];
}

async function searchRecipeBlogs(query: string): Promise<SearchReport> {
  const searchedSources: string[] = [];
  const errors: string[] = [];
  const links: ExtractedBlogLink[] = [];

  await Promise.allSettled(
    externalSources.map(async (source) => {
      searchedSources.push(source.name);
      const searchUrl = buildSearchUrl(source.searchUrl, query);
      try {
        const html = await fetchText(searchUrl);
        extractRecipeLinks(html, searchUrl, query, source.name)
          .slice(0, BLOG_LINKS_PER_SOURCE)
          .forEach((link) => links.push(link));
      } catch (error) {
        errors.push(
          `${source.name}: ${error instanceof Error ? error.message : "no respondió"}`,
        );
      }
    }),
  );

  const uniqueLinks = dedupeLinks(links).slice(0, BLOG_RESULT_LIMIT);
  const detailReports = await Promise.allSettled(
    uniqueLinks.map((link) => recipeFromLink(link, query)),
  );
  const results = detailReports.flatMap((report) =>
    report.status === "fulfilled" ? [report.value] : [],
  );

  detailReports.forEach((report, index) => {
    if (report.status === "rejected")
      errors.push(
        `${uniqueLinks[index]?.sourceLabel || "web"}: ${String(report.reason)}`,
      );
  });

  return { results, searchedSources, errors };
}

async function recipeFromLink(
  link: ExtractedBlogLink,
  query: string,
): Promise<RecipeResult> {
  let extracted: ExtractedRecipe | null = null;

  try {
    const html = await fetchText(link.url);
    extracted = extractRecipeDetails(html, link.url);
  } catch {
    extracted = null;
  }

  if (!extracted || !isCompleteRecipeExtraction(extracted)) {
    throw new Error(`Extracción incompleta: ${link.title}`);
  }

  const title = extracted.title || link.title;
  const ingredients = extracted.ingredients;
  const steps = extracted.steps;
  const summary =
    extracted.summary ||
    link.summary ||
    buildSummaryFromDetails(ingredients, steps);
  const duration =
    extracted.totalTime ||
    extracted.prepTime ||
    extracted.cookTime ||
    "receta completa";

  return {
    id: `blog-${stableId(link.url)}`,
    title,
    tags: searchParts(query).slice(0, 4),
    summary: summary || `Entrada encontrada en ${link.sourceLabel}.`,
    sourceLabel: link.sourceLabel,
    sourceUrl: link.url,
    youtubeId: "",
    dish: inferDish(`${query} ${title}`),
    duration,
    level: "receta completa",
    author: extracted.author || link.sourceLabel,
    origin: "importado",
    ingredients,
    steps,
    imageUrl: extracted.imageUrl,
    yieldText: extracted.yieldText,
    prepTime: extracted.prepTime,
    cookTime: extracted.cookTime,
  };
}

function isCompleteRecipeExtraction(recipe: ExtractedRecipe) {
  return recipe.ingredients.length >= 2 && recipe.steps.length >= 1;
}

async function searchYoutubeVideos(query: string): Promise<SearchReport> {
  const searchedSources = ["YouTube", "Piped", "Invidious", "Motores web"];
  const errors: string[] = [];

  const providerReports = await Promise.allSettled([
    searchYoutubeHtmlVideos(query),
    searchPipedVideos(query),
    searchInvidiousVideos(query),
    searchSearchEngineYoutubeVideos(query),
  ]);

  const videos = providerReports.flatMap((report) =>
    report.status === "fulfilled" ? report.value : [],
  );

  providerReports.forEach((report, index) => {
    if (report.status === "rejected") {
      const source = searchedSources[index] || "vídeos";
      errors.push(
        `${source}: ${
          report.reason instanceof Error ? report.reason.message : "no respondió"
        }`,
      );
    }
  });

  const candidates = rankVideos(videos, query).slice(
    0,
    Math.max(YOUTUBE_VERIFY_LIMIT, YOUTUBE_RESULT_LIMIT),
  );
  const metadataReports = await Promise.allSettled(
    candidates.map(hydrateYoutubeVideo),
  );
  const usableVideos = metadataReports
    .flatMap((report) =>
      report.status === "fulfilled" && report.value ? [report.value] : [],
    )
    .slice(0, YOUTUBE_RESULT_LIMIT);

  if (usableVideos.length === 0)
    errors.push("Vídeos: no se encontraron resultados para esta búsqueda.");

  return {
    searchedSources,
    errors,
    results: usableVideos.map((video) => youtubeVideoResult(video, query)),
  };
}

async function searchYoutubeHtmlVideos(query: string): Promise<VideoHit[]> {
  const pages = await Promise.allSettled([
    fetchText(youtubeSearchUrl(`${query} receta cocina`)),
    fetchText(youtubeSearchUrl(`receta ${query} paso a paso`)),
    fetchText(youtubeSearchUrl(`${query} cocina facil video`)),
  ]);

  return pages.flatMap((page) =>
    page.status === "fulfilled" ? extractYoutubeVideos(page.value) : [],
  );
}

async function searchSearchEngineYoutubeVideos(query: string): Promise<VideoHit[]> {
  const searches = [
    `${query} receta cocina site:youtube.com/watch`,
    `${query} receta paso a paso youtube`,
    `cómo hacer ${query} receta youtube`,
  ];
  const urls = VIDEO_SEARCH_ENGINE_BASES.flatMap((base) =>
    searches.map((text) => {
      const url = new URL(base);
      url.searchParams.set("q", text);
      if (url.hostname.includes("bing.com")) {
        url.searchParams.set("setlang", "es-ES");
        url.searchParams.set("cc", "es");
      }
      return url.toString();
    }),
  );

  const pages = await Promise.allSettled(urls.map((url) => fetchText(url, 9_000)));

  return pages.flatMap((page) =>
    page.status === "fulfilled" ? extractYoutubeVideosFromSearchEngine(page.value) : [],
  );
}

async function searchPipedVideos(query: string): Promise<VideoHit[]> {
  const searches = [
    `${query} receta cocina`,
    `receta ${query} paso a paso`,
  ];
  const urls = PIPED_API_BASES.flatMap((base) =>
    searches.map(
      (text) =>
        `${base}/search?q=${encodeURIComponent(text)}&type=video&region=ES`,
    ),
  );

  const reports = await Promise.allSettled(
    urls.map((url) => fetchJson(url, 9_000)),
  );

  return reports.flatMap((report) =>
    report.status === "fulfilled"
      ? pipedSearchToVideos(report.value).slice(0, VIDEO_PROVIDER_LIMIT)
      : [],
  );
}

async function searchInvidiousVideos(query: string): Promise<VideoHit[]> {
  const searches = [
    `${query} receta cocina`,
    `receta ${query} paso a paso`,
  ];
  const urls = INVIDIOUS_API_BASES.flatMap((base) =>
    searches.map(
      (text) =>
        `${base}/api/v1/search?q=${encodeURIComponent(text)}&type=video&sort_by=relevance&region=ES`,
    ),
  );

  const reports = await Promise.allSettled(
    urls.map((url) => fetchJson(url, 9_000)),
  );

  return reports.flatMap((report) =>
    report.status === "fulfilled"
      ? invidiousSearchToVideos(report.value).slice(0, VIDEO_PROVIDER_LIMIT)
      : [],
  );
}

function pipedSearchToVideos(data: unknown): VideoHit[] {
  const items = Array.isArray(data)
    ? data
    : Array.isArray((data as any)?.items)
      ? (data as any).items
      : Array.isArray((data as any)?.results)
        ? (data as any).results
        : Array.isArray((data as any)?.relatedStreams)
          ? (data as any).relatedStreams
        : [];

  return items
    .filter((item: any) =>
      /video|stream/i.test(String(item?.type || item?.contentType || "video")),
    )
    .map((item: any) => {
      const id =
        normalizeYoutubeId(String(item.videoId || item.id || "")) ||
        youtubeIdFromUrl(String(item.url || item.shortUrl || item.shareUrl || ""));
      return {
        id,
        title: cleanText(String(item.title || "")),
        author: cleanText(String(item.author || item.uploader || "")),
        thumbnailUrl:
          bestVideoThumbnail(item.videoThumbnails || item.thumbnails) ||
          String(item.thumbnail || item.thumbnailUrl || ""),
      };
    })
    .filter((video: VideoHit) => video.id && video.title);
}

function invidiousSearchToVideos(data: unknown): VideoHit[] {
  const items = Array.isArray(data) ? data : [];
  return items
    .filter((item: any) => /video/i.test(String(item?.type || "video")))
    .map((item: any) => ({
      id: normalizeYoutubeId(String(item.videoId || item.id || "")) ||
        youtubeIdFromUrl(String(item.url || item.link || item.shareUrl || "")),
      title: cleanText(String(item.title || "")),
      author: cleanText(String(item.author || item.authorName || "")),
      thumbnailUrl: bestVideoThumbnail(item.videoThumbnails || item.thumbnails),
    }))
    .filter((video: VideoHit) => video.id && video.title);
}

function bestVideoThumbnail(value: any) {
  const thumbnails = Array.isArray(value) ? value : [];
  const sorted = thumbnails
    .map((item: any) => ({
      url: String(item.url || ""),
      area: Number(item.width || 0) * Number(item.height || 0),
    }))
    .filter((item: { url: string; area: number }) => item.url)
    .sort((a: { area: number }, b: { area: number }) => b.area - a.area);
  return sorted[0]?.url || "";
}

async function hydrateYoutubeVideo(video: VideoHit): Promise<VideoHit | null> {
  if (!video.id) return null;
  const metadata = await fetchYoutubeMetadata(video.id).catch(() => null);
  const title = cleanText(metadata?.title || video.title || "");
  return {
    ...video,
    title: title || "Vídeo de receta",
    author: metadata?.author || video.author || "YouTube",
    thumbnailUrl:
      metadata?.thumbnailUrl ||
      video.thumbnailUrl ||
      youtubeThumbnail(video.id),
  };
}

async function fetchYoutubeMetadata(
  id: string,
): Promise<{ title?: string; author?: string; thumbnailUrl?: string } | null> {
  const text = await fetchText(
    `https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(`https://www.youtube.com/watch?v=${id}`)}`,
    YOUTUBE_EMBED_VERIFY_TIMEOUT_MS,
  );
  const data = JSON.parse(text);
  return {
    title: cleanText(String(data.title || "")),
    author: cleanText(String(data.author_name || "")),
    thumbnailUrl:
      typeof data.thumbnail_url === "string" ? data.thumbnail_url : "",
  };
}

function youtubeEmbedUrlForVerification(id: string) {
  return `https://www.youtube-nocookie.com/embed/${id}?rel=0&modestbranding=1&playsinline=1`;
}

function isUnavailableYoutubeEmbed(html: string) {
  const status = html.match(
    /"playabilityStatus"\s*:\s*\{\s*"status"\s*:\s*"([^"]+)"/i,
  )?.[1];
  if (status && !/^OK$/i.test(status)) return true;
  return /id=["']player-unavailable|class=["'][^"']*ytp-error|"status"\s*:\s*"(?:ERROR|UNPLAYABLE|LOGIN_REQUIRED)"|this video is unavailable|este v[ií]deo no est[aá] disponible/i.test(
    html,
  );
}

function youtubeVideoResult(video: VideoHit, query: string): RecipeResult {
  return {
    id: `youtube-${video.id}`,
    title: video.title,
    tags: ["youtube", ...searchParts(query).slice(0, 3)],
    summary: "Vídeo de receta reproducible dentro de Salseo.",
    sourceLabel: "YouTube",
    sourceUrl: `https://www.youtube.com/watch?v=${video.id}`,
    youtubeId: video.id,
    dish: inferDish(`${query} ${video.title}`),
    duration: "vídeo",
    level: "embed",
    author: video.author || "YouTube",
    origin: "importado",
    ingredients: [],
    steps: [],
    imageUrl: video.thumbnailUrl || youtubeThumbnail(video.id),
  };
}

function youtubeThumbnail(id: string) {
  return `https://i.ytimg.com/vi/${id}/maxresdefault.jpg`;
}

function youtubeSearchUrl(query: string) {
  const url = new URL("https://www.youtube.com/results");
  url.searchParams.set("search_query", query);
  url.searchParams.set("sp", "EgIQAQ%3D%3D");
  return url.toString();
}

function rankVideos(videos: VideoHit[], query: string): VideoHit[] {
  const parts = searchParts(query);
  const seen = new Set<string>();
  return videos
    .filter((video) => {
      if (!video.id || seen.has(video.id)) return false;
      seen.add(video.id);
      const title = normalize(video.title);
      if (/shorts|tik tok|tiktok|reaccion|parodia|meme/.test(title))
        return false;
      return true;
    })
    .map((video) => ({
      video,
      score:
        scoreText(video.title || query, parts) +
        (/receta|cocina|preparaci|ingrediente|paso a paso|como hacer|cómo hacer/i.test(
          video.title || query,
        )
          ? 3
          : 0),
    }))
    .sort((a, b) => b.score - a.score)
    .map((item) => item.video);
}

function youtubeIdFromUrl(value: string) {
  const expanded = decodeRepeatedly(value).replace(/\\u0026/g, "&").replace(/&amp;/g, "&");
  try {
    const url = new URL(expanded, "https://www.youtube.com");
    if (!/(^|\.)youtube\.com$|(^|\.)youtu\.be$|(^|\.)youtube-nocookie\.com$/.test(url.hostname)) return "";
    if (url.hostname.includes("youtu.be"))
      return normalizeYoutubeId(url.pathname.split("/").filter(Boolean)[0] || "");
    const fromQuery = normalizeYoutubeId(url.searchParams.get("v") || "");
    if (fromQuery) return fromQuery;
    const parts = url.pathname.split("/").filter(Boolean);
    const marker = parts.findIndex((part) => ["embed", "shorts", "live", "v"].includes(part));
    if (marker >= 0) return normalizeYoutubeId(parts[marker + 1] || "");
    return "";
  } catch {
    const match = expanded.match(/(?:youtu\.be\/|watch\?v=|watch%3Fv%3D|embed\/|shorts\/|live\/)([a-zA-Z0-9_-]{11})/i);
    return normalizeYoutubeId(match?.[1] || "");
  }
}

function normalizeYoutubeId(value: string) {
  const clean = String(value || "").trim().slice(0, 11);
  return /^[a-zA-Z0-9_-]{11}$/.test(clean) ? clean : "";
}

function decodeRepeatedly(value: string) {
  let current = String(value || "");
  for (let index = 0; index < 4; index += 1) {
    const next = safeDecodeURIComponent(current);
    if (next === current) break;
    current = next;
  }
  return current;
}

function safeDecodeURIComponent(value: string) {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

async function fetchJson(url: string, timeoutMs = REQUEST_TIMEOUT_MS): Promise<unknown> {
  const text = await fetchText(url, timeoutMs);
  try {
    return JSON.parse(text);
  } catch {
    throw new Error("respuesta JSON no válida");
  }
}

async function fetchText(url: string, timeoutMs = REQUEST_TIMEOUT_MS) {
  if (Capacitor.isNativePlatform()) {
    const response = await withTimeout(
      CapacitorHttp.get({
        url,
        headers: {
          Accept:
            "text/html,application/xhtml+xml,application/xml,application/json;q=0.9,*/*;q=0.8",
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 14; SALSEO) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36",
        },
      }),
      timeoutMs,
    );

    if (response.status < 200 || response.status >= 300)
      throw new Error(`HTTP ${response.status}`);
    if (typeof response.data === "string") return response.data;
    return JSON.stringify(response.data);
  }

  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        accept:
          "text/html,application/xhtml+xml,application/xml,application/json;q=0.9,*/*;q=0.8",
      },
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.text();
  } finally {
    window.clearTimeout(timer);
  }
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number) {
  return new Promise<T>((resolve, reject) => {
    const timer = window.setTimeout(
      () => reject(new Error("tiempo de espera agotado")),
      timeoutMs,
    );
    promise.then(
      (value) => {
        window.clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        window.clearTimeout(timer);
        reject(error);
      },
    );
  });
}

function buildSearchUrl(template: string, query: string) {
  if (template.includes("{q}"))
    return template.replace("{q}", encodeURIComponent(query));
  if (/[?&](s|q|search)=?$/i.test(template))
    return `${template}${encodeURIComponent(query)}`;
  if (template.endsWith("=")) return `${template}${encodeURIComponent(query)}`;

  const url = new URL(template);
  if (!url.search) url.searchParams.set("s", query);
  return url.toString();
}

function extractRecipeLinks(
  html: string,
  baseUrl: string,
  query: string,
  sourceLabel: string,
): ExtractedBlogLink[] {
  const document = new DOMParser().parseFromString(html, "text/html");
  const queryParts = searchParts(query);
  const baseHost = new URL(baseUrl).hostname.replace(/^www\./, "");
  const candidates = new Map<string, ExtractedBlogLink & { score: number }>();

  collectSchemaRecipes(document, baseUrl).forEach((item) => {
    const score =
      scoreText(`${item.title} ${item.summary} ${item.url}`, queryParts) + 5;
    if (score > 2) candidates.set(item.url, { ...item, sourceLabel, score });
  });

  [
    ...document.querySelectorAll(
      "article a, .post a, .entry a, .hentry a, main a, a",
    ),
  ]
    .map((anchor) => anchorToRecipeLink(anchor as HTMLAnchorElement, baseUrl))
    .filter((item): item is Omit<ExtractedBlogLink, "sourceLabel"> =>
      Boolean(item),
    )
    .filter((item) => sameHost(item.url, baseHost))
    .forEach((item) => {
      const score =
        scoreText(`${item.title} ${item.summary} ${item.url}`, queryParts) +
        recipeUrlScore(item.url);
      if (score <= 0) return;
      const previous = candidates.get(item.url);
      if (!previous || score > previous.score)
        candidates.set(item.url, { ...item, sourceLabel, score });
    });

  return [...candidates.values()]
    .sort((a, b) => b.score - a.score)
    .map(({ score: _score, ...item }) => item);
}

function extractRecipeDetails(html: string, baseUrl: string): ExtractedRecipe {
  const document = new DOMParser().parseFromString(html, "text/html");
  const schema = collectSchemaRecipeDetails(document, baseUrl)[0];
  const htmlExtraction = extractRecipeDetailsFromHtml(document, baseUrl);

  return {
    title: schema?.title || htmlExtraction.title,
    summary: schema?.summary || htmlExtraction.summary,
    ingredients: schema?.ingredients?.length
      ? schema.ingredients
      : htmlExtraction.ingredients,
    steps: schema?.steps?.length ? schema.steps : htmlExtraction.steps,
    imageUrl: schema?.imageUrl || htmlExtraction.imageUrl,
    author: schema?.author || htmlExtraction.author,
    yieldText: schema?.yieldText || htmlExtraction.yieldText,
    prepTime: schema?.prepTime || htmlExtraction.prepTime,
    cookTime: schema?.cookTime || htmlExtraction.cookTime,
    totalTime: schema?.totalTime || htmlExtraction.totalTime,
  };
}

function collectSchemaRecipeDetails(
  document: Document,
  baseUrl: string,
): ExtractedRecipe[] {
  const items: ExtractedRecipe[] = [];
  [...document.querySelectorAll('script[type="application/ld+json"]')].forEach(
    (script) => {
      const text = script.textContent?.trim();
      if (!text) return;
      try {
        const parsed = JSON.parse(text);
        flattenJsonLd(parsed).forEach((node) => {
          const type = Array.isArray(node["@type"])
            ? node["@type"].join(" ")
            : String(node["@type"] || "");
          if (!/Recipe/i.test(type)) return;
          const title = cleanText(String(node.name || node.headline || ""));
          if (!title) return;
          const instructions = recipeInstructionsToText(
            node.recipeInstructions || node.instructions,
          );
          const ingredients = arrayOfText(
            node.recipeIngredient || node.ingredients,
          ).slice(0, 120);
          items.push({
            title,
            summary: cleanText(String(node.description || "")).slice(0, 420),
            ingredients,
            steps: instructions.slice(0, 120),
            imageUrl: imageFromJsonLd(node.image, baseUrl),
            author: authorFromJsonLd(node.author),
            yieldText: arrayOfText(node.recipeYield || node.yield).join(", "),
            prepTime: humanTime(String(node.prepTime || "")),
            cookTime: humanTime(String(node.cookTime || "")),
            totalTime: humanTime(String(node.totalTime || "")),
          });
        });
      } catch {
        // JSON-LD malformado: se ignora y se usa extracción HTML.
      }
    },
  );
  return items;
}

function collectSchemaRecipes(
  document: Document,
  baseUrl: string,
): Array<Omit<ExtractedBlogLink, "sourceLabel">> {
  const items: Array<Omit<ExtractedBlogLink, "sourceLabel">> = [];
  [...document.querySelectorAll('script[type="application/ld+json"]')].forEach(
    (script) => {
      const text = script.textContent?.trim();
      if (!text) return;
      try {
        const parsed = JSON.parse(text);
        flattenJsonLd(parsed).forEach((node) => {
          const type = Array.isArray(node["@type"])
            ? node["@type"].join(" ")
            : String(node["@type"] || "");
          if (!/Recipe|Article|BlogPosting/i.test(type)) return;
          const title = cleanText(String(node.name || node.headline || ""));
          if (!title) return;
          const url = absoluteUrl(
            String(node.url || node.mainEntityOfPage?.["@id"] || baseUrl),
            baseUrl,
          );
          const summary = cleanText(String(node.description || "")).slice(
            0,
            300,
          );
          items.push({ title, url, summary });
        });
      } catch {
        // JSON-LD malformado: se ignora y se usa extracción por enlaces.
      }
    },
  );
  return items;
}

function extractRecipeDetailsFromHtml(
  document: Document,
  baseUrl: string,
): ExtractedRecipe {
  const title = cleanText(
    document.querySelector("h1")?.textContent ||
      document
        .querySelector('meta[property="og:title"]')
        ?.getAttribute("content") ||
      document.title ||
      "",
  );
  const summary = cleanText(
    document
      .querySelector('meta[name="description"]')
      ?.getAttribute("content") ||
      document
        .querySelector('meta[property="og:description"]')
        ?.getAttribute("content") ||
      document.querySelector("article p, main p")?.textContent ||
      "",
  ).slice(0, 420);
  const imageUrl = absoluteUrl(
    document
      .querySelector('meta[property="og:image"]')
      ?.getAttribute("content") ||
      document
        .querySelector('meta[name="twitter:image"]')
        ?.getAttribute("content") ||
      (
        document.querySelector(
          "article img, main img, .recipe img, .entry-content img",
        ) as HTMLImageElement | null
      )?.src ||
      "",
    baseUrl,
  );

  const ingredients = uniqueClean([
    ...extractBySelectors(document, [
      ".wprm-recipe-ingredient",
      ".wprm-recipe-ingredient-name",
      ".tasty-recipes-ingredients li",
      ".mv-create-ingredients li",
      ".recipe-ingredients li",
      ".recipe-card-ingredients li",
      ".asset-recipe-ingredients li",
      ".recipe__ingredients li",
      ".recipe-ingredients__item",
      ".ingredientes-receta li",
      ".ingredients li",
      ".ingredientes li",
      "[class*='ingredient'] li",
      "[class*='ingrediente'] li",
      "[itemprop='recipeIngredient']",
      "[itemprop='ingredients']",
    ]),
    ...extractListAfterHeading(
      document,
      /(ingredientes|ingredients|necesitas|vas a necesitar)/i,
      RECIPE_DETAIL_LIMIT,
    ),
  ]).slice(0, RECIPE_DETAIL_LIMIT);

  const explicitSteps = uniqueClean([
    ...extractBySelectors(document, [
      ".wprm-recipe-instruction-text",
      ".wprm-recipe-instruction",
      ".tasty-recipes-instructions li",
      ".mv-create-instructions li",
      ".recipe-instructions li",
      ".recipe-card-instructions li",
      ".asset-recipe-steps li",
      ".article-asset-recipe-step",
      ".recipe__steps li",
      ".recipe-method li",
      ".recipe-directions li",
      ".receta-pasos li",
      ".entry-content ol li",
      ".instructions li",
      ".preparacion li",
      ".preparación li",
      ".elaboracion li",
      ".elaboración li",
      "[class*='instruction'] li",
      "[class*='preparacion'] li",
      "[class*='preparación'] li",
      "[class*='elaboracion'] li",
      "[class*='elaboración'] li",
      "[itemprop='recipeInstructions'] li",
      "[itemprop='recipeInstructions'] p",
    ]),
    ...extractListAfterHeading(
      document,
      /(preparaci[oó]n|elaboraci[oó]n|instrucciones|paso a paso|directions|method|instructions|cómo hacer|como hacer)/i,
      RECIPE_DETAIL_LIMIT,
    ),
  ]).slice(0, RECIPE_DETAIL_LIMIT);

  return {
    title,
    summary,
    ingredients,
    steps: explicitSteps.length
      ? explicitSteps
      : stepsFromArticleParagraphs(document).slice(0, 24),
    imageUrl,
    author: cleanText(
      document.querySelector(
        '[rel="author"], .author, .byline, [class*="autor"], [class*="author"]',
      )?.textContent || "",
    ),
    yieldText: extractMetaText(document, [
      '[itemprop="recipeYield"]',
      ".wprm-recipe-servings",
      ".tasty-recipes-yield",
      '[class*="racion"]',
      '[class*="serving"]',
    ]),
    prepTime: humanTime(
      extractMetaText(document, [
        'meta[itemprop="prepTime"]',
        '[itemprop="prepTime"]',
        ".wprm-recipe-prep_time",
        ".tasty-recipes-prep-time",
      ]),
    ),
    cookTime: humanTime(
      extractMetaText(document, [
        'meta[itemprop="cookTime"]',
        '[itemprop="cookTime"]',
        ".wprm-recipe-cook_time",
        ".tasty-recipes-cook-time",
      ]),
    ),
    totalTime: humanTime(
      extractMetaText(document, [
        'meta[itemprop="totalTime"]',
        '[itemprop="totalTime"]',
        ".wprm-recipe-total_time",
        ".tasty-recipes-total-time",
      ]),
    ),
  };
}

function extractBySelectors(document: Document, selectors: string[]): string[] {
  const items: string[] = [];
  selectors.forEach((selector) => {
    document.querySelectorAll(selector).forEach((element) => {
      extractElementRecipeItems(element).forEach((item) => items.push(item));
    });
  });
  return uniqueClean(items).filter(meaningfulRecipeLine);
}

function extractElementRecipeItems(element: Element): string[] {
  const directListItems = [...element.querySelectorAll(":scope > li")];
  if (directListItems.length)
    return directListItems.map((item) => cleanText(item.textContent || ""));

  const nestedListItems = [...element.querySelectorAll("li")];
  if (nestedListItems.length && !element.matches("li"))
    return nestedListItems.map((item) => cleanText(item.textContent || ""));

  const aria =
    element.getAttribute("aria-label") || element.getAttribute("title") || "";
  const content =
    element.getAttribute("content") || element.getAttribute("datetime") || "";
  const text = cleanText(content || element.textContent || aria);
  return text ? [text] : [];
}

function extractListAfterHeading(
  document: Document,
  pattern: RegExp,
  maxItems: number,
): string[] {
  const headings = [
    ...document.querySelectorAll(
      "h1, h2, h3, h4, strong, b, .wprm-recipe-header, .tasty-recipes-label, [class*='title'], [class*='titulo']",
    ),
  ];
  const matchedHeadings = headings
    .filter((item) => pattern.test(cleanText(item.textContent || "")))
    .slice(0, 4);
  const items: string[] = [];

  matchedHeadings.forEach((heading) => {
    const localContainer = heading.closest(
      "section, .recipe, .receta, .wprm-recipe, .tasty-recipes, .mv-create-card, .entry-content, article",
    );
    if (localContainer && localContainer !== document.body) {
      extractLikelyItemsNearHeading(localContainer, heading, pattern).forEach(
        (item) => items.push(item),
      );
    }

    let current: Element | null = heading.nextElementSibling;
    let guard = 0;
    while (current && items.length < maxItems && guard < 80) {
      guard += 1;
      const currentText = cleanText(current.textContent || "");
      if (
        /^(H1|H2|H3|H4)$/i.test(current.tagName) &&
        !pattern.test(currentText)
      )
        break;
      extractElementRecipeItems(current)
        .filter(meaningfulRecipeLine)
        .forEach((item) => items.push(item));
      current = current.nextElementSibling;
    }
  });

  return uniqueClean(items).slice(0, maxItems);
}

function extractLikelyItemsNearHeading(
  container: Element,
  heading: Element,
  pattern: RegExp,
): string[] {
  const siblings: Element[] = [];
  let current = heading.nextElementSibling;
  let guard = 0;
  while (current && guard < 18) {
    guard += 1;
    const text = cleanText(current.textContent || "");
    if (/^(H1|H2|H3|H4)$/i.test(current.tagName) && !pattern.test(text)) break;
    siblings.push(current);
    current = current.nextElementSibling;
  }

  const direct = siblings
    .flatMap(extractElementRecipeItems)
    .filter(meaningfulRecipeLine);
  if (direct.length) return direct;

  const listItems = [...container.querySelectorAll("li")]
    .map((item) => cleanText(item.textContent || ""))
    .filter(meaningfulRecipeLine);
  if (listItems.length && listItems.length <= 160) return listItems;

  return [...container.querySelectorAll("p")]
    .map((item) => cleanText(item.textContent || ""))
    .filter((item) => meaningfulRecipeLine(item) && item.length < 420)
    .slice(0, 40);
}

function stepsFromArticleParagraphs(document: Document): string[] {
  return uniqueClean(
    [
      ...document.querySelectorAll(
        "article p, main p, .entry-content p, .post-content p",
      ),
    ]
      .map((item) => cleanText(item.textContent || ""))
      .filter((item) => item.length >= 35 && item.length <= 620)
      .filter((item) => !isBoilerplate(item))
      .filter((item) =>
        /mezcl|añad|agreg|pon|calent|cocin|horne|fr[ií]e|sofr[ií]e|cort|bat|sirv|dej|reserv|coloc|prepar|cuec|dora|salpiment|ingrediente|receta/i.test(
          item,
        ),
      ),
  ).slice(0, 24);
}

function extractMetaText(document: Document, selectors: string[]) {
  for (const selector of selectors) {
    const element = document.querySelector(selector);
    if (!element) continue;
    const text = cleanText(
      element.getAttribute("content") ||
        element.getAttribute("datetime") ||
        element.textContent ||
        "",
    );
    if (text) return text;
  }
  return "";
}

function meaningfulRecipeLine(value: string) {
  const text = cleanText(value);
  if (text.length < 2 || text.length > 720) return false;
  if (isBoilerplate(text)) return false;
  return true;
}

function isBoilerplate(value: string) {
  return /cookies|privacidad|newsletter|suscr[ií]b|publicidad|compartir|comentarios|síguenos|registr|iniciar sesi[oó]n|aceptar|rechazar|facebook|instagram|pinterest|whatsapp/i.test(
    value,
  );
}

function uniqueClean(values: string[]) {
  const seen = new Set<string>();
  const result: string[] = [];
  values
    .map(cleanText)
    .filter(Boolean)
    .forEach((item) => {
      const key = normalize(item);
      if (!key || seen.has(key)) return;
      seen.add(key);
      result.push(item);
    });
  return result;
}

function flattenJsonLd(value: unknown): Array<Record<string, any>> {
  if (!value) return [];
  if (Array.isArray(value)) return value.flatMap(flattenJsonLd);
  if (typeof value !== "object") return [];
  const node = value as Record<string, any>;
  const graph = Array.isArray(node["@graph"])
    ? node["@graph"].flatMap(flattenJsonLd)
    : [];
  return [node, ...graph];
}

function recipeInstructionsToText(value: any): string[] {
  if (!value) return [];
  if (typeof value === "string") return splitInstructionText(value);
  if (Array.isArray(value))
    return value
      .flatMap(recipeInstructionsToText)
      .map(cleanText)
      .filter(Boolean);
  if (typeof value === "object") {
    if (Array.isArray(value.itemListElement))
      return value.itemListElement.flatMap(recipeInstructionsToText);
    return splitInstructionText(String(value.text || value.name || ""));
  }
  return [];
}

function splitInstructionText(value: string) {
  return cleanText(value)
    .split(/(?:\n+|\s(?=\d+[.)]\s)|\.\s+(?=[A-ZÁÉÍÓÚÑ]))/)
    .map((part) => cleanText(part))
    .filter((part) => part.length > 8)
    .slice(0, 120);
}

function arrayOfText(value: any): string[] {
  if (!value) return [];
  if (typeof value === "string") return [cleanText(value)].filter(Boolean);
  if (Array.isArray(value))
    return value.flatMap(arrayOfText).map(cleanText).filter(Boolean);
  if (typeof value === "object")
    return [cleanText(String(value.name || value.text || ""))].filter(Boolean);
  return [];
}

function imageFromJsonLd(value: any, baseUrl: string) {
  if (!value) return "";
  if (typeof value === "string") return absoluteUrl(value, baseUrl);
  if (Array.isArray(value)) return imageFromJsonLd(value[0], baseUrl);
  if (typeof value === "object")
    return absoluteUrl(String(value.url || value.contentUrl || ""), baseUrl);
  return "";
}

function authorFromJsonLd(value: any) {
  if (!value) return "";
  if (typeof value === "string") return cleanText(value);
  if (Array.isArray(value)) return authorFromJsonLd(value[0]);
  if (typeof value === "object") return cleanText(String(value.name || ""));
  return "";
}

function anchorToRecipeLink(
  anchor: HTMLAnchorElement,
  baseUrl: string,
): Omit<ExtractedBlogLink, "sourceLabel"> | null {
  const href = anchor.getAttribute("href") || "";
  const title = cleanText(
    anchor.textContent ||
      anchor.getAttribute("title") ||
      anchor.getAttribute("aria-label") ||
      "",
  );
  if (title.length < 5 || title.length > 180) return null;

  try {
    const url = new URL(href, baseUrl);
    url.hash = "";
    if (!/^https?:$/i.test(url.protocol)) return null;
    if (isNoiseUrl(url.toString())) return null;
    const summary = cleanText(
      anchor.closest("article, .post, .entry, .recipe, .result, .hentry, li")
        ?.textContent || "",
    ).slice(0, 300);
    return {
      url: url.toString(),
      title: decodeHtml(title),
      summary: decodeHtml(summary),
    };
  } catch {
    return null;
  }
}

function extractYoutubeVideos(html: string): VideoHit[] {
  const videos = new Map<string, VideoHit>();
  const putVideo = (id: string, title = "", author = "", thumbnailUrl = "") => {
    const cleanId = String(id || "").slice(0, 11);
    if (!/^[a-zA-Z0-9_-]{11}$/.test(cleanId)) return;
    const cleanTitle = cleanText(decodeJsonText(title || ""));
    const previous = videos.get(cleanId);
    if (!previous) {
      videos.set(cleanId, {
        id: cleanId,
        title: cleanTitle,
        author: cleanText(author),
        thumbnailUrl,
      });
      return;
    }
    if (!previous.title && cleanTitle) previous.title = cleanTitle;
    if (!previous.author && author) previous.author = cleanText(author);
    if (!previous.thumbnailUrl && thumbnailUrl) previous.thumbnailUrl = thumbnailUrl;
  };

  parseYoutubeInitialData(html).forEach((video) =>
    putVideo(video.id, video.title, video.author || "", video.thumbnailUrl || ""),
  );

  const rendererRegex =
    /"videoRenderer"\s*:\s*\{[\s\S]{0,4500}?"videoId"\s*:\s*"([a-zA-Z0-9_-]{11})"[\s\S]{0,4500}?"title"\s*:\s*\{(?:"runs"\s*:\s*\[\s*\{\s*"text"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"|"simpleText"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)")/g;
  let rendererMatch: RegExpExecArray | null;
  while ((rendererMatch = rendererRegex.exec(html))) {
    putVideo(rendererMatch[1], rendererMatch[2] || rendererMatch[3] || "");
  }

  const compactRegex =
    /"(?:compactVideoRenderer|gridVideoRenderer)"\s*:\s*\{[\s\S]{0,3500}?"videoId"\s*:\s*"([a-zA-Z0-9_-]{11})"[\s\S]{0,3500}?"title"\s*:\s*\{(?:"runs"\s*:\s*\[\s*\{\s*"text"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"|"simpleText"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)")/g;
  let compactMatch: RegExpExecArray | null;
  while ((compactMatch = compactRegex.exec(html))) {
    putVideo(compactMatch[1], compactMatch[2] || compactMatch[3] || "");
  }

  const watchRegex = /(?:watch\?v=|\\u002Fwatch\?v=|"videoId"\s*:\s*")([a-zA-Z0-9_-]{11})/g;
  let watchMatch: RegExpExecArray | null;
  while ((watchMatch = watchRegex.exec(html))) {
    const id = watchMatch[1];
    const from = Math.max(0, watchMatch.index - 1200);
    const to = Math.min(html.length, watchMatch.index + 2200);
    const nearby = html.slice(from, to);
    const title =
      nearby.match(/"title"\s*:\s*\{\s*"runs"\s*:\s*\[\s*\{\s*"text"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"/i)?.[1] ||
      nearby.match(/"title"\s*:\s*\{\s*"simpleText"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"/i)?.[1] ||
      nearby.match(/"ariaLabel"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"/i)?.[1] ||
      "";
    putVideo(id, title);
  }

  return [...videos.values()].filter((video) => !/shorts/i.test(video.title));
}

function extractYoutubeVideosFromSearchEngine(html: string): VideoHit[] {
  const videos = new Map<string, VideoHit>();
  const putVideo = (id: string, title = "", author = "", thumbnailUrl = "") => {
    const cleanId = normalizeYoutubeId(id);
    if (!cleanId) return;
    const cleanTitle = cleanText(decodeJsonText(stripHtml(title || "")));
    const previous = videos.get(cleanId);
    if (!previous) {
      videos.set(cleanId, {
        id: cleanId,
        title: cleanTitle || "Vídeo de receta",
        author: cleanText(author || "YouTube"),
        thumbnailUrl: thumbnailUrl || youtubeThumbnail(cleanId),
      });
      return;
    }
    if ((!previous.title || previous.title === "Vídeo de receta") && cleanTitle)
      previous.title = cleanTitle;
    if (!previous.author && author) previous.author = cleanText(author);
    if (!previous.thumbnailUrl && thumbnailUrl) previous.thumbnailUrl = thumbnailUrl;
  };

  try {
    const document = new DOMParser().parseFromString(html, "text/html");
    [...document.querySelectorAll("a")].forEach((anchor) => {
      const href = (anchor as HTMLAnchorElement).getAttribute("href") || "";
      const resolved = extractPossiblyRedirectedUrl(href);
      const id = youtubeIdFromUrl(resolved) || youtubeIdFromUrl(href);
      if (!id) return;
      putVideo(id, (anchor.textContent || "").trim());
    });
  } catch {
    // Si el HTML no se puede parsear como documento, se intenta con expresiones regulares.
  }

  const decoded = decodeRepeatedly(html)
    .replace(/\\u002F/g, "/")
    .replace(/\\u003D/g, "=")
    .replace(/\\u0026/g, "&")
    .replace(/&amp;/g, "&");

  const urlRegex = /(?:https?:)?\/\/(?:www\.|m\.)?(?:youtube\.com\/watch\?[^\s"'<>]*v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/gi;
  let urlMatch: RegExpExecArray | null;
  while ((urlMatch = urlRegex.exec(decoded))) {
    const from = Math.max(0, urlMatch.index - 900);
    const to = Math.min(decoded.length, urlMatch.index + 900);
    const nearby = decoded.slice(from, to);
    const title =
      nearby.match(/<a[^>]*>([\s\S]{0,220}?)<\/a>/i)?.[1] ||
      nearby.match(/title=["']([^"']{4,180})["']/i)?.[1] ||
      nearby.match(/aria-label=["']([^"']{4,180})["']/i)?.[1] ||
      "";
    putVideo(urlMatch[1], title);
  }

  const rawIdRegex = /(?:watch\?v=|watch%3Fv%3D|watch%253Fv%253D|youtu\.be\/|embed\/|shorts\/)([a-zA-Z0-9_-]{11})/gi;
  let rawMatch: RegExpExecArray | null;
  while ((rawMatch = rawIdRegex.exec(decoded))) {
    const from = Math.max(0, rawMatch.index - 700);
    const to = Math.min(decoded.length, rawMatch.index + 700);
    const nearby = decoded.slice(from, to);
    const title =
      nearby.match(/<h[23][^>]*>([\s\S]{0,220}?)<\/h[23]>/i)?.[1] ||
      nearby.match(/<a[^>]*>([\s\S]{0,220}?)<\/a>/i)?.[1] ||
      nearby.match(/title=["']([^"']{4,180})["']/i)?.[1] ||
      "";
    putVideo(rawMatch[1], title);
  }

  return [...videos.values()].filter((video) => !/shorts/i.test(video.title));
}

function extractPossiblyRedirectedUrl(href: string) {
  const decoded = decodeRepeatedly(href)
    .replace(/\\u0026/g, "&")
    .replace(/&amp;/g, "&");
  try {
    const url = new URL(decoded, "https://duckduckgo.com");
    const redirectParam =
      url.searchParams.get("uddg") ||
      url.searchParams.get("u") ||
      url.searchParams.get("url") ||
      url.searchParams.get("r") ||
      "";
    return redirectParam ? decodeRepeatedly(redirectParam) : decoded;
  } catch {
    return decoded;
  }
}

function stripHtml(value: string) {
  return String(value || "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function parseYoutubeInitialData(html: string): VideoHit[] {
  const jsonText = extractYoutubeInitialDataJson(html);
  if (!jsonText) return [];

  try {
    const data = JSON.parse(jsonText);
    const hits: VideoHit[] = [];
    walk(data, (node) => {
      const renderer =
        node.videoRenderer ||
        node.compactVideoRenderer ||
        node.gridVideoRenderer ||
        node.playlistVideoRenderer;
      if (!renderer?.videoId) return;
      const title =
        textFromRuns(renderer.title) || textFromRuns(renderer.headline);
      if (!title || /shorts/i.test(title)) return;
      hits.push({
        id: String(renderer.videoId).slice(0, 11),
        title,
        author: textFromRuns(
          renderer.ownerText ||
            renderer.longBylineText ||
            renderer.shortBylineText ||
            renderer.ownerBadges,
        ),
        thumbnailUrl: bestYoutubeThumbnail(renderer.thumbnail),
      });
    });
    return hits;
  } catch {
    return [];
  }
}

function extractYoutubeInitialDataJson(html: string) {
  const markers = [
    "var ytInitialData =",
    'window["ytInitialData"] =',
    "ytInitialData =",
  ];
  for (const marker of markers) {
    const markerIndex = html.indexOf(marker);
    if (markerIndex < 0) continue;
    const start = html.indexOf("{", markerIndex + marker.length);
    if (start < 0) continue;
    const json = extractBalancedJson(html, start);
    if (json) return json;
  }
  return "";
}

function extractBalancedJson(text: string, start: number) {
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = start; index < text.length; index += 1) {
    const char = text[index];
    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (char === "\\") {
        escaped = true;
      } else if (char === '"') {
        inString = false;
      }
      continue;
    }
    if (char === '"') {
      inString = true;
      continue;
    }
    if (char === "{") depth += 1;
    if (char === "}") {
      depth -= 1;
      if (depth === 0) return text.slice(start, index + 1);
    }
  }
  return "";
}

function walk(value: unknown, visitor: (node: Record<string, any>) => void) {
  if (!value || typeof value !== "object") return;
  if (Array.isArray(value)) {
    value.forEach((item) => walk(item, visitor));
    return;
  }
  const node = value as Record<string, any>;
  visitor(node);
  Object.values(node).forEach((item) => walk(item, visitor));
}

function textFromRuns(value: any) {
  if (!value) return "";
  if (typeof value.simpleText === "string") return cleanText(value.simpleText);
  if (Array.isArray(value.runs))
    return cleanText(value.runs.map((run: any) => run.text || "").join(""));
  return "";
}

function bestYoutubeThumbnail(value: any) {
  const thumbnails = Array.isArray(value?.thumbnails) ? value.thumbnails : [];
  const sorted = thumbnails
    .map((item: any) => ({
      url: String(item.url || ""),
      area: Number(item.width || 0) * Number(item.height || 0),
    }))
    .filter((item: { url: string; area: number }) => item.url)
    .sort((a: { area: number }, b: { area: number }) => b.area - a.area);
  return sorted[0]?.url || "";
}

function scoreText(value: string, parts: string[]) {
  const normalized = normalize(value);
  return parts.reduce(
    (score, part) => score + (normalized.includes(part) ? 2 : 0),
    0,
  );
}

function recipeUrlScore(value: string) {
  const normalized = normalize(value);
  if (
    /receta|recipe|cocina|postre|comida|plato|tortilla|ingredientes/.test(
      normalized,
    )
  )
    return 2;
  if (
    /tag|category|categoria|author|page|comentarios|privacy|contacto|politica|aviso-legal/.test(
      normalized,
    )
  )
    return -4;
  return 0;
}

function sameHost(url: string, baseHost: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, "").endsWith(baseHost);
  } catch {
    return false;
  }
}

function isNoiseUrl(url: string) {
  return /\/wp-admin|\/wp-login|\/feed\/?|\/tag\/|\/category\/|\/author\/|\/page\/|#comment|replytocom=|facebook\.com|instagram\.com|pinterest\.com|twitter\.com|x\.com|mailto:/i.test(
    url,
  );
}

function dedupeLinks(links: ExtractedBlogLink[]) {
  const seen = new Set<string>();
  return links.filter((link) => {
    const key = normalizeUrl(link.url);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function dedupeResults(results: RecipeResult[]) {
  const seen = new Set<string>();
  return results.filter((result) => {
    const key = result.youtubeId || normalizeUrl(result.sourceUrl) || result.id;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function searchParts(value: string) {
  const stopwords = new Set([
    "a",
    "al",
    "con",
    "de",
    "del",
    "el",
    "en",
    "la",
    "las",
    "los",
    "para",
    "por",
    "un",
    "una",
    "y",
  ]);
  return normalize(value)
    .split(/\s+/)
    .map((part) => part.trim())
    .filter((part) => part.length > 1 && !stopwords.has(part));
}

function buildSummaryFromDetails(ingredients: string[], steps: string[]) {
  if (ingredients.length)
    return `Ingredientes detectados: ${ingredients.slice(0, 6).join(", ")}.`;
  if (steps.length) return steps[0];
  return "";
}

function humanTime(value: string) {
  if (!value) return "";
  const match = value.match(/PT(?:(\d+)H)?(?:(\d+)M)?/i);
  if (!match) return value;
  const hours = Number(match[1] || 0);
  const minutes = Number(match[2] || 0);
  return [hours ? `${hours} h` : "", minutes ? `${minutes} min` : ""]
    .filter(Boolean)
    .join(" ");
}

function cleanText(value: string) {
  let text = String(value || "");
  text = decodeHtml(text);
  text = text
    .replace(/\r|\n|\t/g, " ")
    .replace(/\/?\s*<br\s*\/?\s*>/gi, ". ")
    .replace(/&lt;\/?\s*br\s*\/?\s*&gt;/gi, ". ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/\s*\/\s*(?=\.|,|;|:)/g, " ")
    .replace(/\s+/g, " ")
    .replace(/\s+([.,;:])/g, "$1")
    .replace(/(?:\.\s*){2,}/g, ". ")
    .trim();
  return text;
}

function normalize(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .trim();
}

function decodeJsonText(value: string) {
  try {
    return JSON.parse(`"${value.replace(/"/g, '\\"')}"`);
  } catch {
    return value.replace(/\\u0026/g, "&").replace(/\\"/g, '"');
  }
}

function decodeHtml(value: string) {
  const textarea = document.createElement("textarea");
  textarea.innerHTML = value;
  return textarea.value;
}

function absoluteUrl(value: string, baseUrl: string) {
  if (!value) return "";
  try {
    return new URL(value, baseUrl).toString();
  } catch {
    return "";
  }
}

function normalizeUrl(value: string) {
  try {
    const url = new URL(value);
    url.hash = "";
    [
      "utm_source",
      "utm_medium",
      "utm_campaign",
      "utm_content",
      "utm_term",
    ].forEach((param) => url.searchParams.delete(param));
    return url.toString();
  } catch {
    return value;
  }
}

function stableId(value: string) {
  let hash = 0;
  for (let index = 0; index < value.length; index += 1)
    hash = (hash * 31 + value.charCodeAt(index)) >>> 0;
  return hash.toString(36);
}

function inferDish(query: string): DishKind {
  const normalized = normalize(query);
  if (/tortilla|huevo|omelette/.test(normalized)) return "egg";
  if (/arroz|paella|risotto/.test(normalized)) return "rice";
  if (/pan|empanada|masa|pizza/.test(normalized)) return "bread";
  if (/bizcocho|tarta|flan|postre|galleta/.test(normalized)) return "dessert";
  if (/lenteja|guiso|potaje|caldo|sopa|cocido/.test(normalized)) return "stew";
  if (/merluza|atun|bacalao|sardina|pescado/.test(normalized)) return "fish";
  if (/pollo|ternera|cerdo|carne|cordero/.test(normalized)) return "meat";
  if (/ensalada|verdura|vegetal/.test(normalized)) return "salad";
  return "generic";
}
