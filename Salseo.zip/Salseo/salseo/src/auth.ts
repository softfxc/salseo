import { defaultAvatarUrl, defaultBackgroundUrl } from "./data";
import type { Language, UserProfile } from "./types";

type StoredAccount = {
  id: string;
  username: string;
  alias: string;
  role: UserProfile["role"];
  joinedAt: string;
  preferredLanguage: Language;
  salt: string;
  passwordHash: string;
  pinSalt: string;
  pinHash: string;
  publicKey: string;
};

const ACCOUNTS_KEY = "salseo:accounts:v13";
const ITERATIONS = 120_000;
const PIN_MIN_LENGTH = 16;

export async function createAccount(input: {
  username: string;
  password: string;
  pin: string;
  preferredLanguage: Language;
}): Promise<UserProfile> {
  const username = normalizeUsername(input.username);
  const password = input.password;
  const pin = input.pin;

  validateAccountInput({ username, password, pin });

  const accounts = readAccounts();
  if (accounts.some((account) => normalizeUsername(account.username) === username)) {
    throw new Error("Ya existe una cuenta con ese usuario.");
  }

  const salt = randomBase64(16);
  const pinSalt = randomBase64(16);
  const account: StoredAccount = {
    id: crypto.randomUUID(),
    username,
    alias: username,
    role: "Usuario registrado",
    joinedAt: new Date().toISOString().slice(0, 10),
    preferredLanguage: input.preferredLanguage,
    salt,
    passwordHash: await hashSecret(password, salt),
    pinSalt,
    pinHash: await hashSecret(pin, pinSalt),
    publicKey: `salseo-pub-${crypto.randomUUID()}`,
  };

  writeAccounts([account, ...accounts]);
  return accountToProfile(account);
}

export async function verifyCredentials(input: { username: string; password: string }): Promise<string> {
  const username = normalizeUsername(input.username);
  const password = input.password;

  if (!username || !password) {
    throw new Error("Introduce usuario y contraseña.");
  }

  const account = readAccounts().find((item) => normalizeUsername(item.username) === username);
  if (!account) {
    throw new Error("No existe ninguna cuenta con ese usuario.");
  }

  const passwordHash = await hashSecret(password, account.salt);
  if (passwordHash !== account.passwordHash) {
    throw new Error("La contraseña no es correcta.");
  }

  return account.id;
}

export async function verifyPin(accountId: string, pin: string): Promise<UserProfile> {
  const account = readAccounts().find((item) => item.id === accountId);
  if (!account) throw new Error("Sesión de verificación caducada. Vuelve a introducir usuario y contraseña.");

  if (pin.length < PIN_MIN_LENGTH) {
    throw new Error(`El PIN debe tener al menos ${PIN_MIN_LENGTH} caracteres.`);
  }

  const pinHash = await hashSecret(pin, account.pinSalt);
  if (pinHash !== account.pinHash) {
    throw new Error("El PIN no es correcto.");
  }

  return accountToProfile(account);
}

export function createReaderProfile(lang: Language): UserProfile {
  return {
    username: `lector-${crypto.randomUUID().slice(0, 6)}`,
    alias: "lector",
    role: "Solo lector",
    joinedAt: new Date().toISOString().slice(0, 10),
    preferredLanguage: lang,
    avatarUrl: "",
    backgroundUrl: "",
    bio: "",
  };
}

function validateAccountInput(input: { username: string; password: string; pin: string }) {
  const looksLikeEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.username);
  const looksLikeUsername = /^[a-z0-9._-]{3,32}$/.test(input.username);
  if (!looksLikeEmail && !looksLikeUsername) {
    throw new Error("Introduce un usuario válido o un correo electrónico válido.");
  }
  if (input.password.length < 8) {
    throw new Error("La contraseña debe tener al menos 8 caracteres.");
  }
  if (input.pin.length < PIN_MIN_LENGTH) {
    throw new Error(`El PIN 2FA debe tener al menos ${PIN_MIN_LENGTH} caracteres.`);
  }
}

function accountToProfile(account: StoredAccount): UserProfile {
  return {
    username: account.username,
    alias: account.alias,
    role: account.role,
    joinedAt: account.joinedAt,
    preferredLanguage: account.preferredLanguage,
    avatarUrl: defaultAvatarUrl,
    backgroundUrl: defaultBackgroundUrl,
    bio: "",
  };
}

function readAccounts(): StoredAccount[] {
  try {
    const raw = window.localStorage.getItem(ACCOUNTS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeAccounts(accounts: StoredAccount[]) {
  window.localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
}

function normalizeUsername(value: string) {
  return value.trim().toLowerCase();
}

async function hashSecret(secret: string, salt: string) {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey("raw", encoder.encode(secret), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt: base64ToBytes(salt),
      iterations: ITERATIONS,
      hash: "SHA-256",
    },
    keyMaterial,
    256,
  );
  return bytesToBase64(new Uint8Array(bits));
}

function randomBase64(size: number) {
  const bytes = new Uint8Array(size);
  crypto.getRandomValues(bytes);
  return bytesToBase64(bytes);
}

function bytesToBase64(bytes: Uint8Array) {
  let binary = "";
  bytes.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });
  return window.btoa(binary);
}

function base64ToBytes(value: string) {
  const binary = window.atob(value);
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}
