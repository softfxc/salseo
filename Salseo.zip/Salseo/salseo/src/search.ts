import { Capacitor, CapacitorHttp } from "@capacitor/core";
import { externalSources } from "./data";
import type { DishKind, RecipeResult } from "./types";

export type SearchReport = {
  results: RecipeResult[];
  searchedSources: string[];
  errors: string[];
};

type ExtractedBlogLink = {
  url: string;
  title: string;
  summary: string;
  sourceLabel: string;
};

type ExtractedRecipe = {
  title: string;
  summary: string;
  ingredients: string[];
  steps: string[];
  imageUrl?: string;
  author?: string;
  yieldText?: string;
  prepTime?: string;
  cookTime?: string;
  totalTime?: string;
};

type VideoHit = {
  id: string;
  title: string;
  author?: string;
};

const BLOG_LINKS_PER_SOURCE = 6;
const BLOG_RESULT_LIMIT = 36;
const YOUTUBE_RESULT_LIMIT = 24;
const REQUEST_TIMEOUT_MS = 13_000;

export async function runExternalSearch(query: string): Promise<SearchReport> {
  const clean = query.trim();
  if (!clean) return { results: [], searchedSources: [], errors: [] };

  const [blogReport, videoReport] = await Promise.all([searchRecipeBlogs(clean), searchYoutubeVideos(clean)]);
  const unique = dedupeResults([...videoReport.results, ...blogReport.results]);

  return {
    results: unique,
    searchedSources: [...blogReport.searchedSources, ...videoReport.searchedSources],
    errors: [...blogReport.errors, ...videoReport.errors],
  };
}

export function derivedSuggestions(query: string, history: string[]) {
  const clean = query.trim();
  if (!clean) return history.slice(0, 5);
  return [
    `${clean} receta casera`,
    `${clean} ingredientes preparación`,
    `${clean} fácil paso a paso`,
    `${clean} con vídeo`,
    `${clean} tradicional`,
  ];
}

async function searchRecipeBlogs(query: string): Promise<SearchReport> {
  const searchedSources: string[] = [];
  const errors: string[] = [];
  const links: ExtractedBlogLink[] = [];

  await Promise.allSettled(
    externalSources.map(async (source) => {
      searchedSources.push(source.name);
      const searchUrl = buildSearchUrl(source.searchUrl, query);
      try {
        const html = await fetchText(searchUrl);
        extractRecipeLinks(html, searchUrl, query, source.name).slice(0, BLOG_LINKS_PER_SOURCE).forEach((link) => links.push(link));
      } catch (error) {
        errors.push(`${source.name}: ${error instanceof Error ? error.message : "no respondió"}`);
      }
    }),
  );

  const uniqueLinks = dedupeLinks(links).slice(0, BLOG_RESULT_LIMIT);
  const detailReports = await Promise.allSettled(uniqueLinks.map((link) => recipeFromLink(link, query)));
  const results = detailReports.flatMap((report) => (report.status === "fulfilled" ? [report.value] : []));

  detailReports.forEach((report, index) => {
    if (report.status === "rejected") errors.push(`${uniqueLinks[index]?.sourceLabel || "web"}: ${String(report.reason)}`);
  });

  return { results, searchedSources, errors };
}

async function recipeFromLink(link: ExtractedBlogLink, query: string): Promise<RecipeResult> {
  let extracted: ExtractedRecipe | null = null;

  try {
    const html = await fetchText(link.url);
    extracted = extractRecipeDetails(html, link.url);
  } catch {
    extracted = null;
  }

  const title = extracted?.title || link.title;
  const ingredients = extracted?.ingredients || [];
  const steps = extracted?.steps || [];
  const summary = extracted?.summary || link.summary || buildSummaryFromDetails(ingredients, steps);
  const duration = extracted?.totalTime || extracted?.prepTime || extracted?.cookTime || (ingredients.length || steps.length ? "receta" : "web");

  return {
    id: `blog-${stableId(link.url)}`,
    title,
    tags: searchParts(query).slice(0, 4),
    summary: summary || `Entrada encontrada en ${link.sourceLabel}.`,
    sourceLabel: link.sourceLabel,
    sourceUrl: link.url,
    youtubeId: "",
    dish: inferDish(`${query} ${title}`),
    duration,
    level: ingredients.length || steps.length ? "extraído" : "fuente externa",
    author: extracted?.author || link.sourceLabel,
    origin: "importado",
    ingredients,
    steps,
    imageUrl: extracted?.imageUrl,
    yieldText: extracted?.yieldText,
    prepTime: extracted?.prepTime,
    cookTime: extracted?.cookTime,
  };
}

async function searchYoutubeVideos(query: string): Promise<SearchReport> {
  const searchedSources = ["YouTube"];
  const errors: string[] = [];

  try {
    const searchUrl = youtubeSearchUrl(`${query} receta cocina`);
    const html = await fetchText(searchUrl);
    const videos = rankVideos(extractYoutubeVideos(html), query).slice(0, YOUTUBE_RESULT_LIMIT);
    const fallbackVideos = videos.length >= 10 ? [] : await searchYoutubeViaDuckDuckGo(query);
    const selectedVideos = rankVideos([...videos, ...fallbackVideos], query).slice(0, YOUTUBE_RESULT_LIMIT);
    const results = selectedVideos.map((video) => youtubeVideoResult(video, query));
    return {
      searchedSources,
      errors,
      results: padYoutubeResults(results, query),
    };
  } catch (error) {
    errors.push(`YouTube: ${error instanceof Error ? error.message : "no respondió"}`);
    return { results: youtubeSearchFallbacks(query), searchedSources, errors };
  }
}

function youtubeVideoResult(video: VideoHit, query: string): RecipeResult {
  return {
    id: `youtube-${video.id}`,
    title: video.title,
    tags: ["youtube", ...searchParts(query).slice(0, 3)],
    summary: "Vídeo encontrado en YouTube para esta búsqueda.",
    sourceLabel: "YouTube",
    sourceUrl: `https://www.youtube.com/watch?v=${video.id}`,
    youtubeId: video.id,
    dish: inferDish(`${query} ${video.title}`),
    duration: "vídeo",
    level: "embed",
    author: video.author || "YouTube",
    origin: "importado",
    ingredients: [],
    steps: [],
  };
}

function padYoutubeResults(results: RecipeResult[], query: string): RecipeResult[] {
  const padded = [...results];
  youtubeSearchFallbacks(query).forEach((item) => {
    if (padded.length < 12 && !padded.some((current) => current.id === item.id)) padded.push(item);
  });
  return padded.slice(0, YOUTUBE_RESULT_LIMIT);
}

function youtubeSearchFallbacks(query: string): RecipeResult[] {
  const clean = query.trim();
  const variants = [
    `${clean} receta cocina`,
    `${clean} receta fácil paso a paso`,
    `${clean} ingredientes preparación`,
    `${clean} receta casera`,
    `${clean} receta española`,
    `${clean} receta tradicional`,
    `${clean} cómo hacer`,
    `${clean} receta rápida`,
    `${clean} trucos cocina`,
    `${clean} receta completa`,
    `${clean} cocinero casero`,
    `${clean} directo al paladar`,
  ];
  return variants.map((search, index) => ({
    id: `youtube-search-${stableId(search)}`,
    title: index === 0 ? `Vídeos de YouTube: ${clean}` : `${clean}: ${search.replace(clean, "").trim()}`,
    tags: ["youtube", ...searchParts(clean).slice(0, 3)],
    summary: "Vídeos de YouTube cargados dentro de Salseo para esta búsqueda.",
    sourceLabel: "YouTube",
    sourceUrl: youtubeSearchUrl(search),
    youtubeId: `search:${search}`,
    dish: inferDish(clean),
    duration: "vídeo",
    level: "embed",
    author: "YouTube",
    origin: "importado" as const,
    ingredients: [],
    steps: [],
  }));
}

function youtubeSearchUrl(query: string) {
  return `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
}

function rankVideos(videos: VideoHit[], query: string): VideoHit[] {
  const parts = searchParts(query);
  const seen = new Set<string>();
  return videos
    .filter((video) => {
      if (!video.id || seen.has(video.id)) return false;
      seen.add(video.id);
      const title = normalize(video.title);
      if (/shorts|tik tok|tiktok|reaccion|parodia|meme/.test(title)) return false;
      return true;
    })
    .map((video) => ({ video, score: scoreText(video.title, parts) + (/receta|cocina|preparaci|ingrediente|paso a paso|como hacer|cómo hacer/i.test(video.title) ? 3 : 0) }))
    .sort((a, b) => b.score - a.score)
    .map((item) => item.video);
}

async function searchYoutubeViaDuckDuckGo(query: string): Promise<VideoHit[]> {
  const url = `https://duckduckgo.com/html/?q=${encodeURIComponent(`site:youtube.com/watch ${query} receta cocina`)}`;
  try {
    const html = await fetchText(url);
    const document = new DOMParser().parseFromString(html, "text/html");
    const hits = new Map<string, VideoHit>();

    [...document.querySelectorAll("a")].forEach((anchor) => {
      const link = decodeDuckDuckGoUrl((anchor as HTMLAnchorElement).href || anchor.getAttribute("href") || "");
      const id = youtubeIdFromUrl(link);
      if (!id || hits.has(id)) return;
      const rawTitle = cleanText(anchor.textContent || "");
      const title = rawTitle.replace(/\s*-\s*YouTube\s*$/i, "") || `Vídeo de YouTube sobre ${query}`;
      hits.set(id, { id, title });
    });

    return [...hits.values()].filter((video) => video.title && !/shorts/i.test(video.title));
  } catch {
    return [];
  }
}

function decodeDuckDuckGoUrl(value: string) {
  try {
    const url = new URL(value, "https://duckduckgo.com");
    const uddg = url.searchParams.get("uddg");
    return uddg ? decodeURIComponent(uddg) : url.toString();
  } catch {
    return value;
  }
}

function youtubeIdFromUrl(value: string) {
  try {
    const url = new URL(value);
    if (!/(^|\.)youtube\.com$|(^|\.)youtu\.be$/.test(url.hostname)) return "";
    if (url.hostname.includes("youtu.be")) return url.pathname.split("/").filter(Boolean)[0]?.slice(0, 11) || "";
    return url.searchParams.get("v")?.slice(0, 11) || "";
  } catch {
    const match = value.match(/(?:youtu\.be\/|watch\?v=)([a-zA-Z0-9_-]{11})/);
    return match?.[1] || "";
  }
}

async function fetchText(url: string) {
  if (Capacitor.isNativePlatform()) {
    const response = await withTimeout(
      CapacitorHttp.get({
        url,
        headers: {
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          "User-Agent": "Mozilla/5.0 (Linux; Android 14; SALSEO) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36",
        },
      }),
      REQUEST_TIMEOUT_MS,
    );

    if (response.status < 200 || response.status >= 300) throw new Error(`HTTP ${response.status}`);
    if (typeof response.data === "string") return response.data;
    return JSON.stringify(response.data);
  }

  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" },
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.text();
  } finally {
    window.clearTimeout(timer);
  }
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number) {
  return new Promise<T>((resolve, reject) => {
    const timer = window.setTimeout(() => reject(new Error("tiempo de espera agotado")), timeoutMs);
    promise.then(
      (value) => {
        window.clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        window.clearTimeout(timer);
        reject(error);
      },
    );
  });
}

function buildSearchUrl(template: string, query: string) {
  if (template.includes("{q}")) return template.replace("{q}", encodeURIComponent(query));
  if (/[?&](s|q|search)=?$/i.test(template)) return `${template}${encodeURIComponent(query)}`;
  if (template.endsWith("=")) return `${template}${encodeURIComponent(query)}`;

  const url = new URL(template);
  if (!url.search) url.searchParams.set("s", query);
  return url.toString();
}

function extractRecipeLinks(html: string, baseUrl: string, query: string, sourceLabel: string): ExtractedBlogLink[] {
  const document = new DOMParser().parseFromString(html, "text/html");
  const queryParts = searchParts(query);
  const baseHost = new URL(baseUrl).hostname.replace(/^www\./, "");
  const candidates = new Map<string, ExtractedBlogLink & { score: number }>();

  collectSchemaRecipes(document, baseUrl).forEach((item) => {
    const score = scoreText(`${item.title} ${item.summary} ${item.url}`, queryParts) + 5;
    if (score > 2) candidates.set(item.url, { ...item, sourceLabel, score });
  });

  [...document.querySelectorAll("article a, .post a, .entry a, .hentry a, main a, a")]
    .map((anchor) => anchorToRecipeLink(anchor as HTMLAnchorElement, baseUrl))
    .filter((item): item is Omit<ExtractedBlogLink, "sourceLabel"> => Boolean(item))
    .filter((item) => sameHost(item.url, baseHost))
    .forEach((item) => {
      const score = scoreText(`${item.title} ${item.summary} ${item.url}`, queryParts) + recipeUrlScore(item.url);
      if (score <= 0) return;
      const previous = candidates.get(item.url);
      if (!previous || score > previous.score) candidates.set(item.url, { ...item, sourceLabel, score });
    });

  return [...candidates.values()].sort((a, b) => b.score - a.score).map(({ score: _score, ...item }) => item);
}

function extractRecipeDetails(html: string, baseUrl: string): ExtractedRecipe {
  const document = new DOMParser().parseFromString(html, "text/html");
  const schema = collectSchemaRecipeDetails(document, baseUrl)[0];
  const fallback = extractRecipeDetailsFromHtml(document, baseUrl);

  return {
    title: schema?.title || fallback.title,
    summary: schema?.summary || fallback.summary,
    ingredients: schema?.ingredients?.length ? schema.ingredients : fallback.ingredients,
    steps: schema?.steps?.length ? schema.steps : fallback.steps,
    imageUrl: schema?.imageUrl || fallback.imageUrl,
    author: schema?.author || fallback.author,
    yieldText: schema?.yieldText || fallback.yieldText,
    prepTime: schema?.prepTime || fallback.prepTime,
    cookTime: schema?.cookTime || fallback.cookTime,
    totalTime: schema?.totalTime || fallback.totalTime,
  };
}

function collectSchemaRecipeDetails(document: Document, baseUrl: string): ExtractedRecipe[] {
  const items: ExtractedRecipe[] = [];
  [...document.querySelectorAll('script[type="application/ld+json"]')].forEach((script) => {
    const text = script.textContent?.trim();
    if (!text) return;
    try {
      const parsed = JSON.parse(text);
      flattenJsonLd(parsed).forEach((node) => {
        const type = Array.isArray(node["@type"]) ? node["@type"].join(" ") : String(node["@type"] || "");
        if (!/Recipe/i.test(type)) return;
        const title = cleanText(String(node.name || node.headline || ""));
        if (!title) return;
        const instructions = recipeInstructionsToText(node.recipeInstructions || node.instructions);
        const ingredients = arrayOfText(node.recipeIngredient || node.ingredients).slice(0, 120);
        items.push({
          title,
          summary: cleanText(String(node.description || "")).slice(0, 420),
          ingredients,
          steps: instructions.slice(0, 120),
          imageUrl: imageFromJsonLd(node.image, baseUrl),
          author: authorFromJsonLd(node.author),
          yieldText: arrayOfText(node.recipeYield || node.yield).join(", "),
          prepTime: humanTime(String(node.prepTime || "")),
          cookTime: humanTime(String(node.cookTime || "")),
          totalTime: humanTime(String(node.totalTime || "")),
        });
      });
    } catch {
      // JSON-LD malformado: se ignora y se usa extracción HTML.
    }
  });
  return items;
}

function collectSchemaRecipes(document: Document, baseUrl: string): Array<Omit<ExtractedBlogLink, "sourceLabel">> {
  const items: Array<Omit<ExtractedBlogLink, "sourceLabel">> = [];
  [...document.querySelectorAll('script[type="application/ld+json"]')].forEach((script) => {
    const text = script.textContent?.trim();
    if (!text) return;
    try {
      const parsed = JSON.parse(text);
      flattenJsonLd(parsed).forEach((node) => {
        const type = Array.isArray(node["@type"]) ? node["@type"].join(" ") : String(node["@type"] || "");
        if (!/Recipe|Article|BlogPosting/i.test(type)) return;
        const title = cleanText(String(node.name || node.headline || ""));
        if (!title) return;
        const url = absoluteUrl(String(node.url || node.mainEntityOfPage?.["@id"] || baseUrl), baseUrl);
        const summary = cleanText(String(node.description || "")).slice(0, 300);
        items.push({ title, url, summary });
      });
    } catch {
      // JSON-LD malformado: se ignora y se usa extracción por enlaces.
    }
  });
  return items;
}

function extractRecipeDetailsFromHtml(document: Document, baseUrl: string): ExtractedRecipe {
  const title = cleanText(
    document.querySelector("h1")?.textContent ||
      document.querySelector('meta[property="og:title"]')?.getAttribute("content") ||
      document.title ||
      "",
  );
  const summary = cleanText(
    document.querySelector('meta[name="description"]')?.getAttribute("content") ||
      document.querySelector('meta[property="og:description"]')?.getAttribute("content") ||
      document.querySelector("article p, main p")?.textContent ||
      "",
  ).slice(0, 420);
  const imageUrl = absoluteUrl(
    document.querySelector('meta[property="og:image"]')?.getAttribute("content") ||
      (document.querySelector("article img, main img") as HTMLImageElement | null)?.src ||
      "",
    baseUrl,
  );

  return {
    title,
    summary,
    ingredients: extractListAfterHeading(document, /(ingredientes|ingredients)/i, 120),
    steps: extractListAfterHeading(document, /(preparaci[oó]n|elaboraci[oó]n|instrucciones|paso a paso|directions|method|instructions)/i, 120),
    imageUrl,
    author: cleanText(document.querySelector('[rel="author"], .author, .byline')?.textContent || ""),
  };
}

function extractListAfterHeading(document: Document, pattern: RegExp, maxItems: number): string[] {
  const headings = [...document.querySelectorAll("h2, h3, h4, strong, b")];
  const heading = headings.find((item) => pattern.test(cleanText(item.textContent || "")));
  if (!heading) return [];

  const items: string[] = [];
  let current: Element | null = heading.nextElementSibling;
  let guard = 0;
  while (current && items.length < maxItems && guard < 60) {
    guard += 1;
    if (/^(H2|H3|H4)$/i.test(current.tagName) && !pattern.test(cleanText(current.textContent || ""))) break;
    const listItems = [...current.querySelectorAll("li")].map((item) => cleanText(item.textContent || "")).filter((item) => item.length > 2);
    if (listItems.length) items.push(...listItems);
    else if (["P", "DIV"].includes(current.tagName)) {
      const text = cleanText(current.textContent || "");
      if (text.length > 12 && text.length < 600) items.push(text);
    }
    current = current.nextElementSibling;
  }
  return [...new Set(items)].slice(0, maxItems);
}

function flattenJsonLd(value: unknown): Array<Record<string, any>> {
  if (!value) return [];
  if (Array.isArray(value)) return value.flatMap(flattenJsonLd);
  if (typeof value !== "object") return [];
  const node = value as Record<string, any>;
  const graph = Array.isArray(node["@graph"]) ? node["@graph"].flatMap(flattenJsonLd) : [];
  return [node, ...graph];
}

function recipeInstructionsToText(value: any): string[] {
  if (!value) return [];
  if (typeof value === "string") return splitInstructionText(value);
  if (Array.isArray(value)) return value.flatMap(recipeInstructionsToText).map(cleanText).filter(Boolean);
  if (typeof value === "object") {
    if (Array.isArray(value.itemListElement)) return value.itemListElement.flatMap(recipeInstructionsToText);
    return splitInstructionText(String(value.text || value.name || ""));
  }
  return [];
}

function splitInstructionText(value: string) {
  return cleanText(value)
    .split(/(?:\n+|\s(?=\d+[.)]\s)|\.\s+(?=[A-ZÁÉÍÓÚÑ]))/)
    .map((part) => cleanText(part))
    .filter((part) => part.length > 8)
    .slice(0, 120);
}

function arrayOfText(value: any): string[] {
  if (!value) return [];
  if (typeof value === "string") return [cleanText(value)].filter(Boolean);
  if (Array.isArray(value)) return value.flatMap(arrayOfText).map(cleanText).filter(Boolean);
  if (typeof value === "object") return [cleanText(String(value.name || value.text || ""))].filter(Boolean);
  return [];
}

function imageFromJsonLd(value: any, baseUrl: string) {
  if (!value) return "";
  if (typeof value === "string") return absoluteUrl(value, baseUrl);
  if (Array.isArray(value)) return imageFromJsonLd(value[0], baseUrl);
  if (typeof value === "object") return absoluteUrl(String(value.url || value.contentUrl || ""), baseUrl);
  return "";
}

function authorFromJsonLd(value: any) {
  if (!value) return "";
  if (typeof value === "string") return cleanText(value);
  if (Array.isArray(value)) return authorFromJsonLd(value[0]);
  if (typeof value === "object") return cleanText(String(value.name || ""));
  return "";
}

function anchorToRecipeLink(anchor: HTMLAnchorElement, baseUrl: string): Omit<ExtractedBlogLink, "sourceLabel"> | null {
  const href = anchor.getAttribute("href") || "";
  const title = cleanText(anchor.textContent || anchor.getAttribute("title") || anchor.getAttribute("aria-label") || "");
  if (title.length < 5 || title.length > 180) return null;

  try {
    const url = new URL(href, baseUrl);
    url.hash = "";
    if (!/^https?:$/i.test(url.protocol)) return null;
    if (isNoiseUrl(url.toString())) return null;
    const summary = cleanText(anchor.closest("article, .post, .entry, .recipe, .result, .hentry, li")?.textContent || "").slice(0, 300);
    return { url: url.toString(), title: decodeHtml(title), summary: decodeHtml(summary) };
  } catch {
    return null;
  }
}

function extractYoutubeVideos(html: string): VideoHit[] {
  const videos = new Map<string, VideoHit>();
  parseYoutubeInitialData(html).forEach((video) => {
    if (!videos.has(video.id)) videos.set(video.id, video);
  });

  const regex = /"videoId":"([a-zA-Z0-9_-]{11})"[\s\S]{0,1200}?"title":\{"runs":\[\{"text":"([^"\\]*(?:\\.[^"\\]*)*)"/g;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(html))) {
    const [, id, rawTitle] = match;
    if (!videos.has(id)) videos.set(id, { id, title: decodeJsonText(rawTitle) });
  }

  return [...videos.values()].filter((video) => video.title && !/shorts/i.test(video.title));
}

function parseYoutubeInitialData(html: string): VideoHit[] {
  const match = html.match(/var ytInitialData = (\{[\s\S]*?\});<\/script>/) || html.match(/window\["ytInitialData"\]\s*=\s*(\{[\s\S]*?\});/);
  if (!match) return [];

  try {
    const data = JSON.parse(match[1]);
    const hits: VideoHit[] = [];
    walk(data, (node) => {
      const renderer = node.videoRenderer;
      if (!renderer?.videoId) return;
      const title = textFromRuns(renderer.title);
      if (!title) return;
      hits.push({ id: renderer.videoId, title, author: textFromRuns(renderer.ownerText || renderer.longBylineText || renderer.shortBylineText) });
    });
    return hits;
  } catch {
    return [];
  }
}

function walk(value: unknown, visitor: (node: Record<string, any>) => void) {
  if (!value || typeof value !== "object") return;
  if (Array.isArray(value)) {
    value.forEach((item) => walk(item, visitor));
    return;
  }
  const node = value as Record<string, any>;
  visitor(node);
  Object.values(node).forEach((item) => walk(item, visitor));
}

function textFromRuns(value: any) {
  if (!value) return "";
  if (typeof value.simpleText === "string") return cleanText(value.simpleText);
  if (Array.isArray(value.runs)) return cleanText(value.runs.map((run: any) => run.text || "").join(""));
  return "";
}

function scoreText(value: string, parts: string[]) {
  const normalized = normalize(value);
  return parts.reduce((score, part) => score + (normalized.includes(part) ? 2 : 0), 0);
}

function recipeUrlScore(value: string) {
  const normalized = normalize(value);
  if (/receta|recipe|cocina|postre|comida|plato|tortilla|ingredientes/.test(normalized)) return 2;
  if (/tag|category|categoria|author|page|comentarios|privacy|contacto|politica|aviso-legal/.test(normalized)) return -4;
  return 0;
}

function sameHost(url: string, baseHost: string) {
  try {
    return new URL(url).hostname.replace(/^www\./, "").endsWith(baseHost);
  } catch {
    return false;
  }
}

function isNoiseUrl(url: string) {
  return /\/wp-admin|\/wp-login|\/feed\/?|\/tag\/|\/category\/|\/author\/|\/page\/|#comment|replytocom=|facebook\.com|instagram\.com|pinterest\.com|twitter\.com|x\.com|mailto:/i.test(url);
}

function dedupeLinks(links: ExtractedBlogLink[]) {
  const seen = new Set<string>();
  return links.filter((link) => {
    const key = normalizeUrl(link.url);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function dedupeResults(results: RecipeResult[]) {
  const seen = new Set<string>();
  return results.filter((result) => {
    const key = result.youtubeId || normalizeUrl(result.sourceUrl) || result.id;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function searchParts(value: string) {
  const stopwords = new Set(["a", "al", "con", "de", "del", "el", "en", "la", "las", "los", "para", "por", "un", "una", "y"]);
  return normalize(value).split(/\s+/).map((part) => part.trim()).filter((part) => part.length > 1 && !stopwords.has(part));
}

function buildSummaryFromDetails(ingredients: string[], steps: string[]) {
  if (ingredients.length) return `Ingredientes detectados: ${ingredients.slice(0, 6).join(", ")}.`;
  if (steps.length) return steps[0];
  return "";
}

function humanTime(value: string) {
  if (!value) return "";
  const match = value.match(/PT(?:(\d+)H)?(?:(\d+)M)?/i);
  if (!match) return value;
  const hours = Number(match[1] || 0);
  const minutes = Number(match[2] || 0);
  return [hours ? `${hours} h` : "", minutes ? `${minutes} min` : ""].filter(Boolean).join(" ");
}

function cleanText(value: string) {
  let text = String(value || "");
  text = decodeHtml(text);
  text = text
    .replace(/\r|\n|\t/g, " ")
    .replace(/\/?\s*<br\s*\/?\s*>/gi, ". ")
    .replace(/&lt;\/?\s*br\s*\/?\s*&gt;/gi, ". ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/\s*\/\s*(?=\.|,|;|:)/g, " ")
    .replace(/\s+/g, " ")
    .replace(/\s+([.,;:])/g, "$1")
    .replace(/(?:\.\s*){2,}/g, ". ")
    .trim();
  return text;
}

function normalize(value: string) {
  return value.toLowerCase().normalize("NFD").replace(/\p{Diacritic}/gu, "").trim();
}

function decodeJsonText(value: string) {
  try {
    return JSON.parse(`"${value.replace(/"/g, '\\"')}"`);
  } catch {
    return value.replace(/\\u0026/g, "&").replace(/\\"/g, '"');
  }
}

function decodeHtml(value: string) {
  const textarea = document.createElement("textarea");
  textarea.innerHTML = value;
  return textarea.value;
}

function absoluteUrl(value: string, baseUrl: string) {
  if (!value) return "";
  try {
    return new URL(value, baseUrl).toString();
  } catch {
    return "";
  }
}

function normalizeUrl(value: string) {
  try {
    const url = new URL(value);
    url.hash = "";
    ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"].forEach((param) => url.searchParams.delete(param));
    return url.toString();
  } catch {
    return value;
  }
}

function stableId(value: string) {
  let hash = 0;
  for (let index = 0; index < value.length; index += 1) hash = (hash * 31 + value.charCodeAt(index)) >>> 0;
  return hash.toString(36);
}

function inferDish(query: string): DishKind {
  const normalized = normalize(query);
  if (/tortilla|huevo|omelette/.test(normalized)) return "egg";
  if (/arroz|paella|risotto/.test(normalized)) return "rice";
  if (/pan|empanada|masa|pizza/.test(normalized)) return "bread";
  if (/bizcocho|tarta|flan|postre|galleta/.test(normalized)) return "dessert";
  if (/lenteja|guiso|potaje|caldo|sopa|cocido/.test(normalized)) return "stew";
  if (/merluza|atun|bacalao|sardina|pescado/.test(normalized)) return "fish";
  if (/pollo|ternera|cerdo|carne|cordero/.test(normalized)) return "meat";
  if (/ensalada|verdura|vegetal/.test(normalized)) return "salad";
  return "generic";
}
