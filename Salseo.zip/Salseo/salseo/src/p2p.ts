import { useCallback, useEffect, useRef, useState } from "react";
import type { MeshPayload } from "./types";
import { useStoredState } from "./storage";

type Envelope =
  | { type: "hello"; peerId: string; at: number }
  | { type: "payload"; peerId: string; at: number; payload: MeshPayload };

type WireMessage =
  | { kind: "hello"; peerId: string }
  | { kind: "payload"; data: string }
  | { kind: "chunk"; transferId: string; index: number; total: number; data: string };

type ChunkBuffer = {
  total: number;
  parts: string[];
  received: number;
};

const CHANNEL_NAME = "salseo-p2p-v1";
const LOCAL_CHANNEL_NAME = "salseo-local-mesh";
const CHUNK_SIZE = 48_000;

export function useLocalMesh(onPayload: (payload: MeshPayload) => void) {
  const [peerId] = useStoredState("salseo:peer-id", () => `peer-${crypto.randomUUID().slice(0, 8)}`);
  const [peers, setPeers] = useState<string[]>([]);
  const [connectionState, setConnectionState] = useState("sin pares");
  const localChannelRef = useRef<BroadcastChannel | null>(null);
  const seenPeersRef = useRef(new Map<string, number>());
  const onPayloadRef = useRef(onPayload);
  const rtcChannelsRef = useRef(new Set<RTCDataChannel>());
  const pendingOfferRef = useRef<RTCPeerConnection | null>(null);
  const chunkBuffersRef = useRef(new Map<string, ChunkBuffer>());

  useEffect(() => {
    onPayloadRef.current = onPayload;
  }, [onPayload]);

  const rememberPeer = useCallback(
    (remotePeerId: string) => {
      if (!remotePeerId || remotePeerId === peerId) return;
      seenPeersRef.current.set(remotePeerId, Date.now());
      setPeers([...new Set([...seenPeersRef.current.keys()].filter((id) => id !== peerId))]);
    },
    [peerId],
  );

  const handlePayload = useCallback((payload: MeshPayload) => {
    onPayloadRef.current(payload);
  }, []);

  const handleWire = useCallback(
    (raw: string) => {
      let message: WireMessage;
      try {
        message = JSON.parse(raw) as WireMessage;
      } catch {
        return;
      }

      if (message.kind === "hello") {
        rememberPeer(message.peerId);
        return;
      }

      if (message.kind === "payload") {
        try {
          handlePayload(JSON.parse(message.data) as MeshPayload);
        } catch {
          // Mensaje corrupto o incompatible: se ignora para no bloquear la app.
        }
        return;
      }

      if (message.kind === "chunk") {
        const current = chunkBuffersRef.current.get(message.transferId) || {
          total: message.total,
          parts: Array.from({ length: message.total }, () => ""),
          received: 0,
        };

        if (!current.parts[message.index]) {
          current.parts[message.index] = message.data;
          current.received += 1;
        }

        chunkBuffersRef.current.set(message.transferId, current);

        if (current.received >= current.total) {
          chunkBuffersRef.current.delete(message.transferId);
          try {
            handlePayload(JSON.parse(current.parts.join("")) as MeshPayload);
          } catch {
            // Paquete incompleto/corrupto.
          }
        }
      }
    },
    [handlePayload, rememberPeer],
  );

  const sendWire = useCallback((channel: RTCDataChannel, payload: MeshPayload | { hello: true }) => {
    if (channel.readyState !== "open") return;

    if ("hello" in payload) {
      channel.send(JSON.stringify({ kind: "hello", peerId } satisfies WireMessage));
      return;
    }

    const data = JSON.stringify(payload);
    if (data.length <= CHUNK_SIZE) {
      channel.send(JSON.stringify({ kind: "payload", data } satisfies WireMessage));
      return;
    }

    const transferId = crypto.randomUUID();
    const total = Math.ceil(data.length / CHUNK_SIZE);
    for (let index = 0; index < total; index += 1) {
      const chunk = data.slice(index * CHUNK_SIZE, (index + 1) * CHUNK_SIZE);
      channel.send(JSON.stringify({ kind: "chunk", transferId, index, total, data: chunk } satisfies WireMessage));
    }
  }, [peerId]);

  const setupDataChannel = useCallback(
    (channel: RTCDataChannel) => {
      channel.binaryType = "arraybuffer";
      channel.onopen = () => {
        rtcChannelsRef.current.add(channel);
        setConnectionState("conectado");
        sendWire(channel, { hello: true });
      };
      channel.onclose = () => {
        rtcChannelsRef.current.delete(channel);
        setConnectionState(rtcChannelsRef.current.size > 0 ? "conectado" : "sin pares");
      };
      channel.onerror = () => setConnectionState("error P2P");
      channel.onmessage = (event) => {
        if (typeof event.data === "string") handleWire(event.data);
      };
    },
    [handleWire, sendWire],
  );

  const createPeerConnection = useCallback(() => {
    const pc = new RTCPeerConnection({
      iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
    });

    pc.ondatachannel = (event) => setupDataChannel(event.channel);
    pc.onconnectionstatechange = () => {
      const state = pc.connectionState;
      if (state === "connected") setConnectionState("conectado");
      if (state === "connecting") setConnectionState("conectando");
      if (state === "failed" || state === "disconnected" || state === "closed") setConnectionState("sin pares");
    };

    return pc;
  }, [setupDataChannel]);

  useEffect(() => {
    if (!("BroadcastChannel" in window)) {
      return undefined;
    }

    const channel = new BroadcastChannel(LOCAL_CHANNEL_NAME);
    localChannelRef.current = channel;

    const announce = () => {
      channel.postMessage({ type: "hello", peerId, at: Date.now() } satisfies Envelope);
    };

    channel.onmessage = (event: MessageEvent<Envelope>) => {
      const message = event.data;
      if (!message || message.peerId === peerId) return;

      seenPeersRef.current.set(message.peerId, message.at);

      if (message.type === "payload") {
        handlePayload(message.payload);
      }
    };

    announce();
    const timer = window.setInterval(() => {
      announce();
      const now = Date.now();
      const activePeers = [...seenPeersRef.current.entries()]
        .filter(([, at]) => now - at < 12_000)
        .map(([id]) => id);
      setPeers(activePeers);
    }, 2500);

    return () => {
      window.clearInterval(timer);
      channel.close();
      localChannelRef.current = null;
    };
  }, [handlePayload, peerId]);

  const broadcast = useCallback(
    (payload: MeshPayload) => {
      localChannelRef.current?.postMessage({
        type: "payload",
        peerId,
        at: Date.now(),
        payload,
      } satisfies Envelope);

      rtcChannelsRef.current.forEach((channel) => sendWire(channel, payload));
    },
    [peerId, sendWire],
  );

  const createOffer = useCallback(async () => {
    ensureWebRtc();
    const pc = createPeerConnection();
    const channel = pc.createDataChannel(CHANNEL_NAME, { ordered: true });
    setupDataChannel(channel);
    pendingOfferRef.current = pc;

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    await waitForIceGathering(pc);
    return encodeSignal(pc.localDescription);
  }, [createPeerConnection, setupDataChannel]);

  const acceptOffer = useCallback(async (signal: string) => {
    ensureWebRtc();
    const description = decodeSignal(signal);
    const pc = createPeerConnection();
    await pc.setRemoteDescription(description);
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    await waitForIceGathering(pc);
    return encodeSignal(pc.localDescription);
  }, [createPeerConnection]);

  const completeAnswer = useCallback(async (signal: string) => {
    ensureWebRtc();
    const pc = pendingOfferRef.current;
    if (!pc) throw new Error("Primero crea una invitación P2P en este dispositivo.");
    const description = decodeSignal(signal);
    await pc.setRemoteDescription(description);
  }, []);

  return { peerId, peers, broadcast, createOffer, acceptOffer, completeAnswer, connectionState };
}

function ensureWebRtc() {
  if (!("RTCPeerConnection" in window)) {
    throw new Error("Este dispositivo/WebView no tiene WebRTC disponible.");
  }
}

function encodeSignal(description: RTCSessionDescription | RTCSessionDescriptionInit | null) {
  if (!description) throw new Error("No se pudo generar la señal P2P.");
  return btoa(unescape(encodeURIComponent(JSON.stringify(description))));
}

function decodeSignal(signal: string): RTCSessionDescriptionInit {
  try {
    const clean = signal.trim();
    const json = decodeURIComponent(escape(atob(clean)));
    const parsed = JSON.parse(json) as RTCSessionDescriptionInit;
    if (!parsed.type || !parsed.sdp) throw new Error("Formato incompleto");
    return parsed;
  } catch {
    throw new Error("El código P2P no es válido. Copia y pega el bloque completo.");
  }
}

function waitForIceGathering(pc: RTCPeerConnection) {
  if (pc.iceGatheringState === "complete") return Promise.resolve();

  return new Promise<void>((resolve) => {
    const finish = () => {
      pc.removeEventListener("icegatheringstatechange", listener);
      window.clearTimeout(timer);
      resolve();
    };
    const listener = () => {
      if (pc.iceGatheringState === "complete") finish();
    };
    const timer = window.setTimeout(finish, 5000);
    pc.addEventListener("icegatheringstatechange", listener);
  });
}
