# Salseo v5 — icono, login, ajustes y fondo de perfil

Cambios aplicados:

- Sustituido el icono anterior de tres líneas por un icono circular con fondo neutro: cuchara pequeña de madera con salsa de tomate.
- Actualizados los iconos web/PWA: `salseo-icon-192.png`, `salseo-icon-512.png` y `salseo-icon-1024.png`.
- Actualizados los iconos Android en las carpetas `mipmap-*` y el splash básico.
- Corregido el acceso para que la pantalla de login vuelva a mostrarse claramente al abrir esta versión.
- La pantalla de acceso queda en modo Login por defecto y permite cambiar a Registro.
- Los campos del login aparecen vacíos y con autocompletado desactivado.
- Eliminado de Ajustes el texto descriptivo innecesario junto a la biografía sobre emoticonos, negritas y cursivas. La validación interna se mantiene.
- El fondo de perfil por defecto deja de ser el gato negro y pasa a `default-forest-day.png`, una imagen de bosque de día.
- La foto de perfil por defecto se mantiene como gato real si el usuario no la cambia.

Comprobaciones realizadas:

```bash
npm run build
npx cap sync android
```

Ambas finalizan correctamente.
