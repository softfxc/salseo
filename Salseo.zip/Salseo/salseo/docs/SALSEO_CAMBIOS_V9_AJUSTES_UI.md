# Salseo v9 — correcciones solicitadas

## Cambios aplicados

- Registro sin contenedor visual con borde/sombra: la pantalla queda sobre fondo blanco limpio.
- Política de privacidad en registro convertida en hipervínculo a `https://github.com/softfxc/salseo`.
- Nuevo icono recortado desde el diseño de cuchara con salsa aportado, ampliado y exportado a 192, 512 y 1024 px, además de mipmaps Android.
- Sustituido el fondo generado del perfil por una fotografía real de bosque de día: `Sunlit path in the forest maritime forest habitat.jpg`, de U.S. Fish and Wildlife Service, dominio público en Wikimedia Commons.
- Menú de tres puntos de Inicio activado: permite limpiar búsqueda y recargar.
- Chats rediseñado: se elimina la conexión P2P y el descarte de usuarios de esa pantalla; se añade cabecera limpia, filtros visuales y estado vacío más cuidado.
- Conexión P2P movida a Ajustes.
- Notificaciones y Segundo plano quedan como interruptores independientes.
- Se eliminan los controles de descarte de usuarios desde Chats. La lógica de ignorar usuarios se conserva internamente para cuando se añada perfil público de usuario.
- `npm run build` y `npx cap sync android` ejecutados correctamente.

## Nota de compilación APK

El proyecto queda sincronizado para Android. En este entorno no se pudo ejecutar Gradle porque el wrapper intenta descargar `gradle-8.11.1-all.zip` desde `services.gradle.org` y no hay resolución DNS externa desde el contenedor.
