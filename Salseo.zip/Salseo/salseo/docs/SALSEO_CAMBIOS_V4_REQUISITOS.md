# SALSEO — V4 requisitos aplicados

Esta versión sustituye la lógica de relleno por una base orientada a la aplicación real descrita:

- Búsqueda externa sin recetas predefinidas.
- Scraping de blogs configurados en `src/data.ts`.
- Extracción de JSON-LD de recetas cuando la web lo ofrece: título, descripción, ingredientes, preparación, imagen, tiempos y raciones.
- Fallback HTML cuando no hay JSON-LD: intenta localizar bloques de ingredientes y preparación por encabezados.
- Resultados de YouTube embebidos con `youtube-nocookie.com`.
- Cada búsqueda positiva se guarda en `Perfil > Preparados recientemente`.
- Registro con usuario + contraseña y segundo paso PIN 2FA local mínimo de 16 caracteres.
- Login sin email y con los campos vacíos.
- Invitado como lector: puede leer y guardar favoritos, pero no comentar, subir fotos ni modificar el perfil.
- Perfil con fondo grande y foto de perfil visibles, ambos editables por usuarios registrados.
- Imágenes por defecto de gatos reales mediante Wikimedia Commons; no son imágenes generadas por IA.
- Biografía “Sobre mí” con máximo 2000 caracteres, sin emoticonos, con soporte básico de **negrita** y *cursiva*.
- Ajustes ES/EN/FR.
- Ajustes de notificaciones: al deshabilitar notificaciones también se deshabilita segundo plano.
- “Delete account” sustituido por “Cerrar sesión”, con aviso previo, limpiando datos locales de perfil, favoritos, posts, chat y preparados.
- “Borrar historial de búsqueda” no borra “Preparados recientemente”.
- Chats P2P con opción de descartar usuarios para no recibir su feed local.
- Icono nuevo: tres rasgos de color tomate rojo.
- Barra superior azul y enlace GitHub eliminados de la interfaz principal.
- Texto de favoritos vacío separado del texto de resultados de búsqueda.
- Fuente cambiada a una tipografía de sistema más legible.

## Límite técnico pendiente

La recepción P2P en segundo plano real en Android requiere un servicio/plugin nativo adicional de background task/notifications. En esta versión queda el ajuste y la lógica local, pero el sistema operativo puede pausar la WebView si la app está cerrada. Para producción habrá que integrar un plugin nativo específico o un relay/bootstrap mínimo.

## Comprobado

- `npm run build`
- `npx cap sync android`
