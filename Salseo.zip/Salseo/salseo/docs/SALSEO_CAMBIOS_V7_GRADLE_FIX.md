# Salseo v7 - Corrección de compilación Android

## Problema corregido

El archivo `android/capacitor.settings.gradle` estaba apuntando por error a una ruta local usada durante la generación previa:

```gradle
../../salseo_v5/node_modules/@capacitor/android/capacitor
```

Eso provocaba el error de Gradle:

```text
Could not resolve project :capacitor-android
No matching variant of project :capacitor-android was found
```

## Corrección

Ahora apunta a la ruta correcta dentro del proyecto actual:

```gradle
../node_modules/@capacitor/android/capacitor
```

## Forma recomendada de compilar en Windows

Desde la raíz del proyecto, ejecutar:

```bat
BUILD_APK_WINDOWS.bat
```

O manualmente:

```bat
cd C:\Users\Usuario\Desktop\Salseo
npm install
npm run build
npx cap sync android
cd android
.\gradlew.bat clean assembleDebug
```

La APK debug quedará en:

```text
android\app\build\outputs\apk\debug\app-debug.apk
```
