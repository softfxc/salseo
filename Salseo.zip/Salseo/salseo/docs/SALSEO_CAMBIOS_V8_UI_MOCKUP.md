# Salseo v8 — interfaz tipo mockup móvil

Cambios aplicados:

- Rediseño general para que la app se comporte como una aplicación móvil limpia, blanca, con acento rojo tomate.
- Login visible por defecto con icono circular de cuchara con salsa, título Salseo, usuario, contraseña, botón rojo y enlace de registro.
- Registro rediseñado con usuario, contraseña, PIN mínimo de 16 caracteres, aviso del PIN y aceptación de privacidad.
- Pantalla de verificación PIN independiente.
- Eliminada la barra superior de marca dentro de la app.
- Navegación inferior reducida a Inicio, Favoritos, Chats y Perfil, como en el mockup.
- Búsqueda rediseñada con cabecera “Buscar”, caja de búsqueda, pestañas Todo / Recetas / Vídeos / Blogs y tarjetas tipo lista.
- YouTube se muestra en una sección propia con tarjetas horizontales y miniatura/play.
- Perfil rediseñado con fondo grande de bosque de día, avatar visible y menú: Sobre mí, Preparados recientemente, Favoritos, Ajustes y Cerrar sesión.
- Añadida pantalla de edición de perfil con fondo, avatar, biografía y botones de cambio de imagen.
- Ajustes simplificados: idioma, notificaciones, segundo plano, borrar historial, acerca de y cerrar sesión. Sin textos descriptivos innecesarios.
- “Preparados recientemente” tiene pantalla propia.
- Se forzó almacenamiento v8 para evitar que una sesión antigua haga desaparecer el login.
- Build web comprobado: npm run build.
- Sync Android comprobado: npx cap sync android.

Nota: la generación de APK no se completó en este entorno porque Gradle no puede descargar desde services.gradle.org. En Windows/Android Studio con conexión debería compilar.
