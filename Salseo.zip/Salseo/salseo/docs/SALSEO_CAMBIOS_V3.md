# SALSEO v3 - búsqueda externa, registro y P2P

## Qué se ha corregido

- Se elimina cualquier enfoque de recetas precargadas como base de resultados.
- La búsqueda se apoya en fuentes externas configuradas en `src/data.ts`.
- `src/search.ts` usa HTTP nativo de Capacitor en Android (`CapacitorHttp`) para reducir bloqueos CORS y, como fallback, `fetch` en navegador.
- Se extraen resultados desde páginas de búsqueda de blogs sencillos, enlaces de artículos, JSON-LD de recetas/artículos y vídeos de YouTube.
- Los vídeos de YouTube se muestran dentro de la app con `youtube-nocookie.com/embed/...`.
- El registro/login local usa contraseña con PBKDF2 + salt.
- Los usuarios registrados pueden publicar/comentar y subir imágenes.
- Las imágenes locales subidas en posts se limitan a 5 MB.
- Los posts de usuarios normales quedan en estado `pending`.
- El moderador puede aprobar u ocultar posts pendientes desde Perfil > Moderación.
- Se añade P2P manual mediante WebRTC DataChannel: oferta/respuesta copiando códigos entre móviles.
- Los mensajes P2P se trocean en chunks para soportar posts con imágenes codificadas en base64.

## Limitaciones reales

- Sin servidor propio no existe registro global centralizado. Las identidades son locales y se sincronizan por P2P.
- WebRTC puede necesitar STUN para atravesar NAT. El proyecto usa un STUN público gratuito, no un servidor propio de la app.
- El scraping directo de webs depende de que cada blog no bloquee peticiones automatizadas. En Android funciona mejor que en navegador por el HTTP nativo de Capacitor.
- YouTube puede cambiar su HTML. El parser intenta leer `ytInitialData` y usa regex de fallback, pero sin API oficial no hay garantía absoluta.

## Comandos probados

```bash
npm run build
npx cap sync android
```

La generación de APK no se pudo completar en este entorno porque Gradle intenta descargar su distribución desde `services.gradle.org` y aquí no hay resolución externa para ese dominio.
