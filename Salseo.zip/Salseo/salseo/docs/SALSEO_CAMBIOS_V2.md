# SALSEO - Cambios V2

Esta versión elimina el enfoque de recetas predefinidas. La búsqueda se intenta resolver contra fuentes externas.

## Implementado

- `src/search.ts`: motor de búsqueda externa.
  - Busca en blogs sencillos configurados en `src/data.ts`.
  - Busca vídeos de YouTube y los convierte en embeds dentro de la app cuando puede extraer el `videoId`.
  - Genera sugerencias derivadas de lo que escribe el usuario, no de recetas fijas.
- `capacitor.config.ts`: activado `CapacitorHttp.enabled = true` para que en Android las peticiones externas usen HTTP nativo.
- `src/auth.ts`: registro/login local real.
  - Cuentas locales en `localStorage`.
  - Contraseña con PBKDF2 + salt.
  - La cuenta del correo definido como `moderatorEmail` se marca como `Creador / Moderador`.
- Posts/comentarios.
  - Un lector puede buscar, pero necesita cuenta registrada para comentar o subir fotos.
  - Fotos limitadas a menos de 5 MB.
  - Los posts de usuarios no moderadores quedan en estado `pending`.
  - El moderador puede aprobar u ocultar.
  - Desde una tarjeta de resultado se puede abrir un hilo/comentario sobre ese resultado.
- Sin recetas semilla ni resultados falsos.

## Limitación técnica honesta

Sin servidor propio ni API pagada, no existe una forma totalmente garantizada de scrapear cualquier web o YouTube desde navegador. En Android con Capacitor se ha activado HTTP nativo para reducir el problema de CORS, pero algunas webs pueden bloquear scraping, cambiar HTML o devolver contenido dinámico difícil de leer.

El P2P actual sigue siendo una base local de desarrollo mediante `BroadcastChannel`. Sirve para probar el flujo de posts, chat y moderación en la misma instancia/dispositivo, pero una red P2P real entre móviles necesita el siguiente paso técnico: WebRTC con señalización gratuita/manual, IPFS/libp2p, o un bootstrap público. Sin al menos un canal de descubrimiento/señalización, dos móviles no se encuentran solos en internet.

## Siguiente paso recomendado

Implementar P2P real con una de estas rutas:

1. WebRTC con intercambio manual por QR/código para no usar servidor.
2. IPFS/libp2p con nodos públicos gratuitos.
3. Relay/bootstrap comunitario opcional, sin servidor propio de SALSEO.

