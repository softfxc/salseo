# Salseo v6 — corrección de búsqueda y YouTube

Cambios aplicados:

- El texto de carga de búsqueda queda como `Cargando...`.
- Se elimina el mensaje negativo `No se pudo extraer la receta completa...`.
- Cuando una receta externa no trae ingredientes/preparación detectables, se muestra un texto neutro: `Abre la fuente para ver la receta completa.`.
- Los resultados de YouTube se colocan antes que los blogs para que sean visibles inmediatamente.
- La búsqueda de YouTube intenta primero leer resultados directos de YouTube.
- Si YouTube no devuelve IDs directos, se intenta localizar vídeos mediante búsqueda externa de enlaces de YouTube.
- Si tampoco hay IDs, se crea una tarjeta de YouTube embebida por búsqueda para que YouTube siga apareciendo dentro de la app.
- `npm run build` ejecutado correctamente.
- `npx cap sync android` ejecutado correctamente.
