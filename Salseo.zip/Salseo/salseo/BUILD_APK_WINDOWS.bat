@echo off
setlocal
cd /d "%~dp0"

echo.
echo ===============================
echo  SALSEO - Generar APK debug
echo ===============================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js no esta instalado o no esta en PATH.
  echo Instala Node.js LTS y vuelve a ejecutar este archivo.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm no esta disponible.
  pause
  exit /b 1
)

echo Instalando dependencias JavaScript...
call npm install
if errorlevel 1 goto :error

echo.
echo Compilando web...
call npm run build
if errorlevel 1 goto :error

echo.
echo Sincronizando Capacitor con Android...
call npx cap sync android
if errorlevel 1 goto :error

echo.
echo Generando APK debug...
cd android
call gradlew.bat clean assembleDebug
if errorlevel 1 goto :error

echo.
echo APK generada correctamente:
echo %CD%\app\build\outputs\apk\debug\app-debug.apk
echo.
pause
exit /b 0

:error
echo.
echo Ha fallado el proceso. Revisa el mensaje anterior.
pause
exit /b 1
