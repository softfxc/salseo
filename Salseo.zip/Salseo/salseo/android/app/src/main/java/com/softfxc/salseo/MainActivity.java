package com.softfxc.salseo;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
