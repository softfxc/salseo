import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.salseo.soft",
  appName: "Salseo",
  webDir: "dist",
  server: {
    androidScheme: "https",
    hostname: "salseo.local",
  },
  plugins: {
    CapacitorHttp: {
      enabled: true,
    },
  },
};

export default config;
