export type NavView = "buscar" | "chats" | "favoritos" | "posts" | "perfil" | "ajustes" | "preparados" | "editarPerfil" | "perfilVista" | "detalleReceta" | "moderacion";

export type Language = "es" | "en" | "fr";

export type DishKind = "egg" | "rice" | "bread" | "dessert" | "stew" | "salad" | "fish" | "meat" | "generic";

export type UserProfile = {
  username: string;
  alias: string;
  role: "Solo lector" | "Usuario registrado" | "Creador / Moderador";
  joinedAt: string;
  preferredLanguage: Language;
  avatarUrl?: string;
  backgroundUrl?: string;
  bio?: string;
};

export type RecipeResult = {
  id: string;
  title: string;
  tags: string[];
  summary: string;
  sourceLabel: string;
  sourceUrl: string;
  youtubeId: string;
  dish: DishKind;
  duration: string;
  level: string;
  author: string;
  origin: "importado";
  ingredients: string[];
  steps: string[];
  imageUrl?: string;
  yieldText?: string;
  prepTime?: string;
  cookTime?: string;
};

export type ExternalSource = {
  name: string;
  homeUrl: string;
  searchUrl: string;
};

export type CommunityPost = {
  id: string;
  author: string;
  handle: string;
  title: string;
  body: string;
  tags: string[];
  mediaUrl?: string;
  linkUrl?: string;
  createdAt: string;
  likes: number;
  replies: number;
  status: "approved" | "pending" | "hidden";
};

export type ChatMessage = {
  id: string;
  author: string;
  body: string;
  createdAt: string;
  mine?: boolean;
};

export type NotificationPrefs = {
  enabled: boolean;
  background: boolean;
};

export type MeshPayload =
  | { type: "chat"; message: ChatMessage }
  | { type: "post"; post: CommunityPost }
  | { type: "recipe"; recipe: RecipeResult }
  | { type: "moderation"; postId: string; status: CommunityPost["status"]; moderator: string };
